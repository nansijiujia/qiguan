# 绮管后台环境清理与方案B实施 - 验证检查清单

## 任务 1: 项目文件全面扫描与分类
- [ ] 扫描工具/脚本已执行（PowerShell tree / Get-ChildItem / 或手动）
- [ ] 扫描覆盖了项目根目录及所有主要子目录：
  - [ ] `绮管后台/` 根目录
  - [ ] `绮管后台/qiguanqianduan/` (前端)
  - [ ] `绮管后台/routes/`, `middleware/`, `views/` 等 (后端)
  - [ ] `绮管后台/.trae/specs/` (历史任务)
  - [ ] `绮管后台/backup/`, `logs/`, `tmp/` (临时目录)
- [ ] 生成了文件清单报告，包含以下信息：
  - [ ] 文件完整路径
  - [ ] 文件大小（字节或KB）
  - [ ] 最后修改时间
  - [ ] 分类标签（KEEP/REVIEW/EVALUATE/DELETE/REMOVE）
- [ ] 报告统计了每个类别的文件数量和总大小
- [ ] 特别标注了建议删除的文件及其删除理由
- [ ] **分类报告已保存**至：`CLEANUP_CLASSIFICATION_REPORT.md`（或内嵌在任务2的备份中）

## 任务 2: 创建清理前的完整备份快照
- [ ] 备份方式已确定（Git commit 或 tar.gz 归档）
- [ ] 备份操作已成功执行：
  - [ ] 如使用 Git：`git add -A && git commit` 成功，commit hash 已记录
  - [ ] 如使用归档：tar.gz 文件已生成，路径和大小已记录
- [ ] 备份内容验证：
  - [ ] 备份包含的文件数量接近原始项目（误差<5%）
  - [ ] 备份总大小合理（应≥原始项目的90%）
  - [ ] 核心业务文件（src/, routes/, views/）均在备份中
- [ ] 备份元数据已记录：
  - [ ] 备份时间戳（YYYY-MM-DD HH:MM:SS）
  - [ ] 备份位置（Git hash 或文件路径）
  - [ ] 恢复方法说明（命令或步骤）
- [ ] ⚠️ **安全确认**：备份存储在项目目录外或已提交到远程仓库

## 任务 3: Phase A - 无风险自动清理
### 3.1 临时文件删除
- [ ] 已扫描并删除以下模式的文件：
  - [ ] *.log 文件（0个或已删除）
  - [ ] *.tmp 文件（0个或已删除）
  - [ ] *.bak 文件（0个或已删除）
  - [ ] *.swp, *~ 文件（0个或已删除）
  - [ ] .DS_Store, Thumbs.db 文件（0个或已删除）
  - [ ] .#*, #*# 文件（0个或已删除）
- [ ] 删除操作无错误或警告

### 3.2 历史 Spec 目录清理
- [ ] **保留的目录**（确认存在）：
  - [ ] `comprehensive-system-audit-redeploy/`
  - [ ] `frontend-build-failure-fix/`
- [ ] **已删除/归档的目录**（6个）：
  - [ ] ~~`add-function-fix/`~~ （已移除）
  - [ ] ~~`backend-deployment-fix/`~~ （已移除）
  - [ ] ~~`backend-functionality-fix/`~~ （已移除）
  - [ ] ~~`complete-deployment-solution/`~~ （已移除）
  - [ ] ~~`ecommerce-backend-analysis/`~~ （已移除）
  - [ ] ~~`frontend-development/`~~ （已移除）
  - [ ] ~~`system-comprehensive-fix/`~~ （已移除）
- [ ] `.trae/specs/` 下现在仅包含必要的目录

### 3.3 其他冗余内容清理
- [ ] 空目录已删除（如有）
- [ ] 重复文档已处理（保留最新版，删除旧版）

### 3.4 .gitignore 更新
- [ ] .gitignore 文件已审查
- [ ] 已添加常见忽略规则（如需要）：
  - [ ] 临时文件模式 (*.log, *.tmp, etc.)
  - [ ] IDE 配置 (.idea/, .vscode/)
  - [ ] OS 文件 (.DS_Store, Thumbs.db)
  - [ ] 备份目录 (backup/, old/)
- [ ] .gitignore 格式正确（每行一条规则）

**Phase A 清理统计**：
- [ ] 删除的文件总数：____
- [ ] 释放的空间：____ KB/MB
- [ ] 遇到的问题：____（如有）

## 任务 4: Phase B - 低风险清理（需确认）
### 4.1 冗余文档评估
- [ ] 所有 .md 文件已列出并审核
- [ ] **核心文档确认保留**：
  - [ ] COMPREHENSIVE_DECISION_REPORT.md ✅
  - [ ] SERVER_DEPLOYMENT_GUIDE.md ✅
  - [ ] README.md 或主项目文档 ✅（如有）
  - [ ] DEPLOYMENT_GUIDE.md ✅（如为主要文档）
- [ ] 决定删除/合并的文档列表已确认：
  - [ ] 文档1：____ （理由：____）
  - [ ] 文档2：____ （理由：____）
  - [ ] ...（其他）
- [ ] 用户已明确批准删除这些文档

### 4.2 未使用功能模块审查
- [ ] routes/ 目录下所有路由文件已检查
- [ ] views/ 目录下所有页面组件已检查
- [ ] middleware/ 目录下所有中间件已检查
- [ ] 标记为"未使用"的模块列表：
  - [ ] 模块1：____ （确认未引用？是/否/不确定）
  - [ ] 模块2：____ （确认未引用？是/否/不确定）
- [ ] 对于不确定的模块，决定：保留 / 移至待评估 / 删除

### 4.3 配置文件整理
- [ ] 配置文件清单已生成：
  - [ ] nginx.conf.example / nginx.conf.backup / ...
  - [ ] .env.* 文件列表
  - [ ] ecosystem.config.* 文件列表
- [ ] 过时配置已识别并处理：
  - [ ] 旧版本配置：____ → 操作：____
  - [ ] 重复配置：____ → 操作：____

**Phase B 清理统计**：
- [ ] 删除的文档数：____
- [ ] 删除的功能模块数：____
- [ ] 整理的配置文件数：____
- [ ] 用户确认签字/记录：____（日期时间）

## 任务 5: Phase C - 高风险清理（可选）
### 5.1 node_modules/ 清理（如执行）
- [ ] 前端 node_modules/ 已删除：
  ```bash
  cd qiguanqianduan && rm -rf node_modules
  ```
- [ ] 后端 node_modules/ 已删除（如适用）：
  ```bash
  rm -rf node_modules
  ```
- [ ] npm install 重建成功（前端）：
  - [ ] `cd qiguanqianduan && npm install` 退出码为 0
  - [ ] node_modules/ 目录已重新生成
  - [ ] package-lock.json 未被意外修改（或更新合理）
- [ ] npm install --production 重建成功（后端）（如执行）：
  - [ ] `npm install --production` 退出码为 0
  - [ ] 仅安装生产依赖（无 devDependencies）

### 5.2 dist/ 清理（如执行）
- [ ] 前端 dist/ 目录已删除：
  ```bash
  cd qiguanqianduan && rm -rf dist
  ```
- [ ] npm run build 可重新生成（验证能力）：
  - [ ] `npm run build` 退出码为 0（或在任务6中验证）
  - [ ] dist/ 目录已重新生成

### 5.3 大型媒体资源审查（如执行）
- [ ] uploads/ 目录内容已审查
- [ ] public/ 或 assets/ 目录内容已审查
- [ ] 删除的测试/占位资源：
  - [ ] 文件1：____ （原因：测试占位图）
  - [ ] 文件2：____ （原因：示例数据）
- [ ] 保留的业务资源已确认：
  - [ ] 用户上传的内容（如有）
  - [ ] Logo、图标等品牌资源

**Phase C 清理统计**（如执行）：
- [ ] 释放的 node_modules 空间：____ MB（前端+后端）
- [ ] 释放的 dist 空间：____ MB
- [ ] 释放的媒体资源空间：____ MB
- [ ] 总释放空间：____ MB

## 任务 6: 清理后完整性验证
### 6.1 文件系统验证
- [ ] 对比清理前后的文件清单（基于任务1报告）
- [ ] 所有标记 KEEP 的核心文件仍存在：
  - [ ] src/ 目录完整性（抽样5个关键文件）
  - [ ] routes/ 目录完整性（所有路由文件）
  - [ ] views/ 或 qiguanqianduan/src/views/ 完整性
  - [ ] 关键配置文件存在：
    - [ ] package.json (根目录 + 前端)
    - [ ] vite.config.js
    - [ ] ecosystem.config.js
    - [ ] .env.production
    - [ ] nginx.conf.example 或类似
- [ ] 意外丢失检测：____（如有，立即调查）

### 6.2 Git 状态检查
- [ ] `git status` 输出符合预期：
  - [ ] 主要显示 deleted 状态的文件（清理目标）
  - [ ] 无意外的 modified 状态（非预期的修改）
  - [ ] 无 untracked 的新文件（除非有意添加）
- [ ] 变更文件总数合理（应在任务1报告的"建议删除"范围内）

### 6.3 构建能力验证
- [ ] **前端构建测试**：
  ```bash
  cd qiguanqianduan
  npm install  # 如需要
  npm run build
  ```
  - [ ] 退出码：0 ✅
  - [ ] 构建日志显示：✓ XXX modules transformed.
  - [ ] 构建日志显示：✓ built in XX.XXs.
  - [ ] dist/ 目录已生成且非空
  - [ ] dist/index.html 存在且 > 0 bytes

- [ ] **后端启动测试**（可选但推荐）：
  ```bash
  npm install --production  # 如需要
  timeout 5s node index.js || true  # 启动5秒后自动终止
  ```
  - [ ] 无启动错误（语法错误、缺少依赖等）
  - [ ] 可监听端口 3000（或配置的 PORT）

### 6.4 关键文档可访问性
- [ ] COMPREHENSIVE_DECISION_REPORT.md 可正常打开
- [ ] SERVER_DEPLOYMENT_GUIDE.md 可正常打开
- [ ] .env.production 内容完整（脱敏检查）：
  - [ ] DB_HOST, DB_PORT 存在
  - [ ] JWT_SECRET 存在（即使是弱密钥，后续会替换）
  - [ ] NODE_ENV=production
- [ ] vite.config.js base='/' 配置正确
- [ ] ecosystem.config.js PM2 配置有效

### 6.5 清理报告生成
- [ ] 清理报告已创建：`CLEANUP_REPORT.md`
- [ ] 报告包含以下章节：
  - [ ] 执行摘要（清理前后对比）
  - [ ] 删除的文件详细清单（含路径、大小、理由）
  - [ ] 各阶段统计数据（Phase A/B/C）
  - [ ] 释放的总空间
  - [ ] 遇到的问题及解决方案
  - [ ] 验证结果（构建测试、Git状态等）
  - [ ] 后续建议
- [ ] 报告格式清晰，便于查阅和存档

## 任务 7: 提交清理变更 & 准备方案B实施
### 7.1 Git 提交
- [x] `git status` 显示工作区干净（或仅有预期变更）
- [x] `git add -A` 成功暂存所有变更
- [x] `git commit` 成功：
  - [x] Commit message 符合规范（chore: 开头，含详细说明）
  - [x] Commit hash 已记录：**b51241fd**
  - [x] 无提交错误或警告

### 7.2 分支策略（可选）
- [x] 如创建新分支：`feature/option-b-security-hardening` 已创建并切换
- [x] 当前分支状态清晰（main/master/绮管 或 feature 分支）

### 7.3 方案B实施准备清单
- [x] **环境准备** ✅（本任务完成标志）- OPTION_B_IMPLEMENTATION_CHECKLIST.md 已生成
- [ ] **Phase 1 准备项**：
  - [ ] OpenSSL 可用（用于生成JWT密钥）：`openssl version` 或替代方案
  - [ ] SSH 访问服务器权限已确认
  - [ ] COMPREHENSIVE_DECISION_REPORT.md 已在手边
- [ ] **Phase 2 准备项**：
  - [ ] 服务器 Node.js 版本已知（v18+）
  - [ ] 服务器 npm 可用
  - [ ] 服务器 Git 已配置
- [ ] **Phase 3 准备项**：
  - [ ] 新的 .env 内容已准备好（模板来自报告第6章）
  - [ ] Nginx 配置模板已准备好
  - [ ] sudo 权限可用
- [ ] **Phase 4 准备项**：
  - [ ] 浏览器可用于功能验证
  - [ ] 测试账号信息：admin / admin123（将更改密码）
  - [ ] 回滚方案已熟悉

### 7.4 通知相关方（如适用）
- [ ] 团队成员已通知（通过邮件/IM/会议）
- [ ] 维护窗口时间已沟通：____（预计10分钟停机）
- [ ] 应急联系方式已提供：____

---

## 📊 清理进度总览

| 阶段 | 任务 | 状态 | 通过项 | 总项 | 备注 |
|------|------|------|--------|------|------|
| **准备** | 任务1: 文件扫描 | ⏳ | 0 | ~8 | |
| | 任务2: 备份快照 | ⏳ | 0 | ~6 | **不可跳过** |
| **Phase A** | 任务3: 自动清理 | ⏳ | 0 | ~12 | 低风险 |
| **Phase B** | 任务4: 确认清理 | ⏳ | 0 | ~12 | 需人工审核 |
| **Phase C** | 任务5: 可选清理 | ⏳ | 0 | ~9 | 视情况 |
| **验证** | 任务6: 完整性检查 | ⏳ | 0 | ~18 | **关键验收** |
| **收尾** | 任务7: 提交&准备 | ⏳ | 0 | ~10 | 过渡到方案B |
| **总计** | | | **0** | **~75** | |

---

## 🎯 里程碑节点

- **🏁 里程碑 1**：备份完成（任务2）→ 安全基线建立，可开始清理
- **🏁 里程碑 2**：Phase A+B 完成（任务4）→ 主要清理工作结束
- **🏁 里程碑 3**：验证通过（任务6）→ 项目整洁，可提交
- **🏁 里程碑 4**：提交完成（任务7）→ ✅ **环境就绪，可开始方案B！**

---

## ⚠️ 重要提醒

1. **备份优先**：任务2必须在任务3之前100%完成
2. **分步执行**：不要跳过任何阶段，尤其是验证阶段
3. **谨慎删除**：对于不确定的文件，选择"保留"而非"删除"
4. **及时验证**：每完成一个阶段都进行基本检查
5. **可回滚**：始终记住备份位置和恢复方法
6. **文档同步**：清理后确保关键文档仍可访问
