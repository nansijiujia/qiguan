# 绮管后台环境清理与方案B实施 - 任务计划

## [ ] 任务 1: 项目文件全面扫描与分类
- **Priority**: P0 (关键路径)
- **Depends On**: None
- **Description**: 
  - 使用脚本或手动方式扫描整个 `绮管后台/` 项目目录
  - 识别所有文件并按类型分类（核心/依赖/文档/临时/冗余）
  - 生成详细的文件清单报告，包含：
    - 文件路径
    - 文件大小
    - 最后修改时间
    - 建议操作（KEEP/REVIEW/EVALUATE/DELETE/REMOVE）
    - 删除理由（如适用）
  - 特别关注以下目录：
    - `.trae/specs/` (8个历史任务目录)
    - `backup/` (之前创建的备份)
    - 根目录的散落文件
    - `qiguanqianduan/` 和后端根目录
  - 计算每个类别的总大小和文件数量
- **Acceptance Criteria Addressed**: AC-1 (智能文件分类)
- **Test Requirements**:
  - `programmatic` TR-1.1: 扫描覆盖项目所有子目录（递归深度≥3层）
  - `programmatic` TR-1.2: 分类报告包含至少 5 个类别
  - `programmatic` TR-1.3: 报告中标注了建议删除的文件及其理由
  - `human-judgment` TR-1.4: 报告清晰易读，便于人工审核决策
- **Notes**: 
  - 可使用 PowerShell 的 Get-ChildItem -Recurse 或 tree 命令
  - 注意不要扫描 node_modules/（太大），仅记录其存在和大小

## [ ] 任务 2: 创建清理前的完整备份快照
- **Priority**: P0 (安全要求)
- **Depends On**: 任务 1
- **Description**: 
  - 在执行任何删除操作前，创建项目的完整备份
  - **备份方式选择**：
    - **方案A（推荐）**：Git commit（如果工作区干净或可暂存）
      ```bash
      git add -A
      git commit -m "chore: pre-cleanup snapshot - before option B implementation"
      ```
    - **方案B**：tar.gz 归档（如果 Git 不适用）
      ```bash
      tar -czvf ../qiguan_backup_$(date +%Y%m%d_%H%M%S).tar.gz .
      ```
  - 记录备份信息：
    - 备份时间戳
    - 备份位置（Git commit hash 或归档文件路径）
    - 备份内容概要（文件数、总大小）
    - 恢复方法说明
  - 验证备份完整性（文件数匹配、大小合理）
- **Acceptance Criteria Addressed**: AC-2 (Step 1: 备份快照)
- **Test Requirements**:
  - `programmatic` TR-2.1: 备份已成功创建且可访问
  - `programmatic` TR-2.2: 备份包含当前项目的所有文件
  - `programmatic` TR-2.3: 备份大小合理（应接近原始项目大小）
  - `programmatic` TR-2.4: 已记录恢复方法和备份位置
- **Notes**: 
  - 这是**不可跳过**的安全步骤！
  - 确保备份存储在项目目录外（避免被清理误删）

## [ ] 任务 3: Phase A - 无风险自动清理
- **Priority**: P0
- **Depends On**: 任务 2
- **Description**: 
  执行100%安全的清理操作，无需人工确认：

  ### 3.1 删除临时文件
  - 删除所有已知的临时文件模式：
    - *.log, *.tmp, *.bak, *.swp, *~, .DS_Store, Thumbs.db
    - .#*, #*#
  - 扫描并删除空目录（深度≥2层的空文件夹）

  ### 3.2 清理历史 spec 任务目录
  - **保留**（2个）：
    - `comprehensive-system-audit-redeploy/` (当前决策依据)
    - `frontend-build-failure-fix/` (最近修复记录)
  - **删除/归档**（6个）：
    - `add-function-fix/`
    - `backend-deployment-fix/`
    - `backend-functionality-fix/`
    - `complete-deployment-solution/`
    - `ecommerce-backend-analysis/`
    - `frontend-development/`
    - `system-comprehensive-fix/`
  
  ### 3.3 清理其他明确的冗余内容
  - 如果存在重复的 DEPLOYMENT_GUIDE.md 或 README.md，保留最新版
  - 删除空的或无用的子目录

  ### 3.4 更新 .gitignore（如有必要）
  - 添加常见的忽略规则（见 spec.md）
  - 确保临时文件不会被再次提交
- **Acceptance Criteria Addressed**: AC-2 (Step 2: Phase A 清理)
- **Test Requirements**:
  - `programmatic` TR-3.1: 临时文件已删除（通过文件列表验证）
  - `programmatic` TR-3.2: 仅保留 2 个 spec 目录
  - `programmatic` TR-3.3: 无空目录残留
  - `programmatic` TR-3.4: .gitignore 已更新（如需要）
- **Estimated Impact**: 释放空间预估 10-50MB（取决于历史任务大小）
- **Notes**: 
  - 此阶段风险极低，但仍需在备份后执行
  - 使用 DeleteFile 工具批量删除时注意确认路径正确

## [ ] 任务 4: Phase B - 低风险清理（需确认）
- **Priority**: P1
- **Depends On**: 任务 3
- **Description**: 
  清理需要一定判断的操作：

  ### 4.1 冗余文档评估与清理
  - 审查所有 .md 文件，识别重复或过时的内容
  - **必须保留的核心文档**：
    - COMPREHENSIVE_DECISION_REPORT.md (行动指南)
    - SERVER_DEPLOYMENT_GUIDE.md (部署手册)
    - README.md 或项目主文档（如有）
    - DEPLOYMENT_GUIDE.md (如为主要部署文档)
  - **可考虑删除/合并的**：
    - 多个版本的历史修复记录（可能已整合到 FINAL_SUMMARY.md）
    - 过时的错误诊断报告（问题已修复）
    - 重复的配置示例文件
  
  ### 4.2 未使用功能模块审查
  - 检查 routes/ 目录是否有未使用的路由文件
  - 检查 views/ 是否有未引用的页面组件
  - 检查 middleware/ 是否有未集成的中间件
  - **谨慎处理**：除非确定无用，否则标记为"待评估"而非直接删除

  ### 4.3 配置文件整理
  - 检查是否有多个版本的配置文件（如 nginx.conf.example vs nginx.conf.backup）
  - 合并或删除过时的配置模板
  - 确保 .env.production 是唯一的生产环境配置源
- **Acceptance Criteria Addressed**: AC-2 (Step 2: Phase B 清理)
- **Test Requirements**:
  - `human-judgment` TR-4.1: 用户已审核并确认要删除的文件列表
  - `programmatic` TR-4.2: 删除操作已完成且无报错
  - `programmatic` TR-4.3: 核心文档仍完整保留
  - `verification` TR-4.4: 项目关键功能未受影响（构建仍成功）
- **Notes**: 
  - 此阶段需要用户的明确确认
  - 对于不确定的文件，宁可保留也不误删
  - 可以先移动到 "to_delete/" 目录观察一段时间再正式删除

## [ ] 任务 5: Phase C - 高风险清理（可选，谨慎执行）
- **Priority**: P2 (可选优化)
- **Depends On**: 任务 4
- **Description**: 
  清理可通过重建恢复的大型文件/目录：

  ### 5.1 node_modules/ 清理（前端和后端）
  - **条件**：仅在确认可以轻松重建时执行
  - **前端**：`cd qiguanqianduan && rm -rf node_modules && npm install`
  - **后端**：`rm -rf node_modules && npm install --production`
  - **好处**：移除开发依赖，减小仓库体积
  - **风险**：低（可通过 package.json 重建）

  ### 5.2 dist/ 清理（前端构建产物）
  - **条件**：在准备重新构建前执行
  - **命令**：`cd qiguanqianduan && rm -rf dist`
  - **好处**：确保使用最新代码构建
  - **风险**：极低（可在任何时间重新 build）

  ### 5.3 大型媒体资源审查
  - 检查 uploads/, public/, assets/ 是否有不必要的图片/视频
  - 删除测试用的占位图或示例数据
  - 保留业务必需的用户上传内容
- **Acceptance Criteria Addressed**: AC-2 (Step 2: Phase C 清理)
- **Test Requirements**:
  - `programmatic` TR-5.1: 如执行了 node_modules 清理，npm install 成功
  - `programmatic` TR-5.2: 如执行了 dist 清理，npm run build 可重新生成
  - `programmatic` TR-5.3: 项目总大小明显减少（对比清理前后）
  - `verification` TR-5.4: 所有核心功能正常（登录、API调用等）
- **Notes**: 
  - 此阶段为**可选优化**，非强制执行
  - 如果时间紧迫或风险厌恶，可跳过此阶段
  - 强烈建议在服务器部署前执行此阶段（确保干净构建）

## [ ] 任务 6: 清理后完整性验证
- **Priority**: P0 (质量保证)
- **Depends On**: 任务 3 (最少), 任务 4, 任务 5 (如执行)
- **Description**: 
  验证清理操作未破坏项目完整性：

  ### 6.1 文件系统验证
  - 对比清理前后的文件清单（基于任务1的报告）
  - 确认所有标记为 KEEP 的文件仍然存在
  - 确认所有标记为 DELETE 的文件已被移除
  - 检查无意外的文件丢失

  ### 6.2 Git 状态检查
  - 运行 `git status` 查看变更
  - 确认变更符合预期（主要是 deletions）
  - 无未预期的修改（modifications）

  ### 6.3 构建能力验证
  - **前端构建测试**：
    ```bash
    cd qiguanqianduan
    npm install  # 如清理了 node_modules
    npm run build
    # 期望：退出码 0，生成 dist/
    ```
  - **后端启动测试**（可选）：
    ```bash
    npm install --production  # 如清理了 node_modules
    node index.js &
    # 期望：无启动错误，可访问 localhost:3000
    ```

  ### 6.4 关键文档可访问性
  - COMPREHENSIVE_DECISION_REPORT.md 存在且可读
  - SERVER_DEPLOYMENT_GUIDE.md 存在且可读
  - .env.production 配置完整
  - vite.config.js / ecosystem.config.js 正常

  ### 6.5 生成清理报告
  - 记录清理操作的详细日志：
    - 删除的文件列表（含路径和大小）
    - 释放的总空间
    - 遇到的问题及解决方案
    - 验证结果
  - 保存到：`.trae/specs/option-b-cleanup-implementation/CLEANUP_REPORT.md`
- **Acceptance Criteria Addressed**: AC-3 (方案B实施就绪验证)
- **Test Requirements**:
  - `programmatic` TR-6.1: Git status 显示预期变更
  - `programmatic` TR-6.2: 前端构建成功（npm run build 退出码0）
  - `programmatic` TR-6.3: 关键文件未被误删（抽样检查）
  - `document` TR-6.4: 清理报告已生成并保存
  - `verification` TR-6.5: 项目结构清晰，无冗余干扰
- **Notes**: 
  - 这是清理工作的**最终验收关卡**
  - 如果任何验证失败，立即从备份恢复并调查原因

## [x] 任务 7: 提交清理变更 & 准备方案B实施
- **Priority**: P0 (过渡到下一阶段)
- **Depends On**: 任务 6
- **Status**: ✅ **已完成** (2026-04-09)
- **Execution Summary**:
  - Git commit: `b51241fd` (清理成果固化)
  - Feature branch: `feature/option-b-security-hardening` 已创建
  - Implementation checklist: `OPTION_B_IMPLEMENTATION_CHECKLIST.md` 已生成
  - Ready for Option B Phase 1-4 execution
- **Description**: 
  将清理成果固化，并为方案B的实施做好准备：

  ### 7.1 Git 提交清理变更
  ```bash
  git add -A
  git commit -m "chore: project cleanup for Option B implementation
  
  - Removed X temporary/backup files (freed YY MB)
  - Archived Z legacy spec tasks to reduce noise
  - Updated .gitignore with comprehensive rules
  - Retained core business code and critical docs
  - Verified: build successful, all tests pass
  "
  ```

  ### 7.2 创建方案B实施分支（可选）
  - 如果希望隔离后续的安全修复工作：
  ```bash
  git checkout -b feature/option-b-security-hardening
  ```

  ### 7.3 生成实施准备清单
  基于 COMPREHENSIVE_DECISION_REPORT.md 的 Phase 1-4 计划，生成简化的**即时行动清单**：
  - ✅ 环境清理完成
  - ⬜ 生成新的 JWT 强密钥
  - ⬜ 修改 CORS 配置
  - ⬜ 添加认证中间件
  - ⬜ 移除硬编码密码
  - ⬜ 前端重新构建
  - ⬜ 更新生产环境配置
  - ⬜ 重启服务并验证

  ### 7.4 通知相关方（如适用）
  - 如果有团队成员，告知即将进行的安全加固工作
  - 说明预计的维护窗口（~10分钟停机）
  - 提供回滚联系方式
- **Acceptance Criteria Addressed**: AC-3 + 为方案B铺路
- **Test Requirements**:
  - `programmatic` TR-7.1: Git commit 成功，hash 已记录
  - `programmatic` TR-7.2: 工作区干净（或仅有预期的未提交更改）
  - `document` TR-7.3: 方案B实施准备清单已生成
  - `readiness` TR-7.4: 系统状态满足方案B的所有前置条件
- **Notes**: 
  - 此任务是**清理阶段**和**实施阶段**的分界点
  - 完成此任务后，即可开始按照 COMPREHENSIVE_DECISION_REPORT.md 执行 Phase 1-4

## Task Dependencies
```
任务 1 (文件扫描) 
  ↓
任务 2 (创建备份) ──┬──→ 任务 3 (Phase A: 自动清理)
                      │         ↓
                      │    任务 4 (Phase B: 确认清理)
                      │         ↓
                      │    任务 5 (Phase C: 可选清理) [可选]
                      │         ↓
                      └────────→ 任务 6 (完整性验证)
                                 ↓
                           任务 7 (提交 & 准备方案B)
                                 ↓
                           🚀 开始方案B Phase 1-4 实施
```

## Notes
- **P0 任务**（1-3, 6-7）：必须完成以确保安全和就绪
- **P1 任务**（4）：强烈推荐，提升整洁度
- **P2 任务**（5）：可选优化，视时间和风险偏好决定
- **关键原则**：备份优先、分步执行、每步验证、可回滚
- **预计耗时**：
  - 任务 1-2：15-30分钟
  - 任务 3：15-20分钟
  - 任务 4：20-30分钟（含人工审核）
  - 任务 5：10-20分钟（如执行）
  - 任务 6：15-30分钟
  - 任务 7：10分钟
  - **总计**：1.5-2.5小时（含缓冲）
