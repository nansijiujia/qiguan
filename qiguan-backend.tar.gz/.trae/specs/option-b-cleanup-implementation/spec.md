# 绮管后台环境清理与方案B实施 Spec

## Why
基于综合诊断报告（发现59个问题，安全评分42/100），已确定选择**选项B（部分重部署+关键修复）**方案。在正式实施前，必须先进行系统性的环境清理工作，以确保：
1. 代码库整洁，仅保留项目必需文件
2. 移除冗余、过时或无关的文档/配置
3. 消除潜在的冲突和混淆
4. 为后续的安全加固和重部署建立干净的基线

## What Changes
- **代码库清理**：识别并删除不相关的源码、配置、依赖
- **文档精简**：移除冗余/过时的文档，保留核心运维文档
- **环境标准化**：统一目录结构、命名规范、配置管理
- **方案B实施准备**：为4阶段执行计划建立清晰的起点

### 清理范围

#### 需要审查和可能删除的内容：
1. **冗余的 spec 历史目录**（.trae/specs/ 下多个旧任务）
2. **未使用的功能模块或路由**
3. **过时的配置文件**（如旧的 cloudbaserc.json 已删除，但可能有残留引用）
4. **重复的部署脚本或文档**
5. **开发阶段的临时文件**（.log, .tmp, backup 等）
6. **node_modules 中的开发依赖**（生产环境不需要）
7. **无用的测试数据或示例文件**

#### 必须保留的核心内容：
1. **业务代码**：前端（qiguanqianduan/src/）+ 后端（routes/, middleware/, db_*.js）
2. **关键配置**：package.json, vite.config.js, ecosystem.config.js, .env.production, nginx.conf.example
3. **核心文档**：
   - COMPREHENSIVE_DECISION_REPORT.md（行动指南）
   - SERVER_DEPLOYMENT_GUIDE.md（部署手册）
   - README.md 或 DEPLOYMENT_GUIDE.md（项目说明）
4. **构建产物模板**：dist/ 目录结构示例（或确保可重新生成）

## Impact
- Affected specs: comprehensive-system-audit-redeploy (已完成诊断)
- Affected code:
  - 整个 `绮管后台/` 项目根目录及子目录
  - `.trae/specs/` 下的历史任务目录
  - `backup/`, `logs/`, `tmp/` 等临时目录
  - 可能存在的 `.gitignore` 未覆盖的文件

## ADDED Requirements

### Requirement: 智能文件分类与识别
系统 SHALL 自动扫描项目目录，将所有文件分类为：

#### Scenario: 文件分类规则
- **WHEN** 扫描 `绮管后台/` 及其子目录
- **THEN** 将文件分为以下类别：
  - 🟢 **核心业务文件** (KEEP)：src/, routes/, views/, components/, config files
  - 🟡 **构建/依赖文件** (REVIEW)：package.json, node_modules/, dist/, lock files
  - 🔵 **文档资料** (EVALUATE)：.md 文件, README, CHANGELOG, docs/
  - 🟠 **临时/备份文件** (DELETE)：.log, .tmp, .bak, backup/, *.swp, .DS_Store
  - 🔴 **无关/冗余文件** (REMOVE)：旧的 spec 任务目录, 重复文档, 未使用的功能模块

#### Scenario: 决策辅助输出
- **WHEN** 分类完成
- **THEN** 生成分类报告，包含：
  - 每个类别的文件数量和总大小
  - 每个建议删除的文件及其理由
  - 需要人工确认的高风险项（如 node_modules/）
  - 预计释放的空间

### Requirement: 安全清理执行流程
系统 SHALL 提供标准化的清理步骤：

#### Step 1: 备份快照
- **BEFORE** 任何删除操作
- **THEN** 创建完整的项目快照（Git commit 或 tar.gz 归档）
- **THEN** 记录快照位置和内容清单

#### Step 2: 分阶段清理
- **PHASE A** - 无风险清理（100%自动）：
  - 删除临时文件 (.log, .tmp, .bak, .swp, .DS_Store)
  - 删除空的目录
  - 清理重复的 spec 历史任务（仅保留最新的 comprehensive-system-audit-redeploy 和 frontend-build-failure-fix）
  
- **PHASE B** - 低风险清理（需确认）：
  - 删除冗余的文档（保留最新版本）
  - 清理未使用的功能模块（需确认不影响现有功能）
  - 移除过时的配置文件
  
- **PHASE C** - 高风险清理（谨慎执行）：
  - 清理 node_modules/（可通过 npm install 重建）
  - 清理 dist/（可通过 npm run build 重建）
  - 大型二进制文件或媒体资源

#### Step 3: 验证与回滚
- **AFTER** 清理完成
- **THEN** 执行完整性检查：
  - Git status 显示预期的变更
  - 核心文件未被误删（通过文件列表比对）
  - 项目仍可正常构建（npm run build 成功）
- **IF** 发现问题
- **THEN** 从快照恢复

### Requirement: 方案B实施就绪验证
清理完成后，系统 SHALL 验证是否满足方案B的前置条件：

#### Scenario: 实施就绪检查
- **WHEN** 清理工作全部完成
- **THEN** 确认以下条件满足：
  - [ ] 项目目录结构清晰，无冗余文件干扰
  - [ ] 所有必要的配置文件存在且格式正确
  - [ ] Git 工作区干净（或仅有预期的修改）
  - [ ] 本地构建成功（npm run build 退出码0）
  - [ ] 关键文档（COMPREHENSIVE_DECISION_REPORT.md）可访问
  - [ ] 备份快照已保存并可恢复

## MODIFIED Requirements

### Requirement: Git 仓库状态管理
原有的 Git 推送流程 SHALL 在清理后重新评估：

#### Scenario: 清理后的提交策略
- **WHEN** 清理工作完成
- **THEN** 创建专门的清理提交：
  ```
  chore: 项目环境清理 - 移除冗余文件和历史任务，为方案B实施做准备
  
  - 删除 X 个临时/备份文件（释放 YY MB 空间）
  - 归档 Z 个历史 spec 任务到 archive/
  - 更新 .gitignore 规则
  - 保留核心业务代码和关键文档不变
  ```

### Requirement: .gitignore 优化
根据清理结果更新 .gitignore 规则：

#### Scenario: 新增忽略规则
- **IF** 清理过程中发现某些文件不应纳入版本控制
- **THEN** 将其添加到 .gitignore：
  ```gitignore
  # 临时文件
  *.log
  *.tmp
  *.bak
  *.swp
  .DS_Store
  Thumbs.db
  
  # 备份目录
  backup/
  old/
  archive/
  
  # IDE 配置
  .idea/
  .vscode/
  *.sublime-workspace
  
  # 环境特定
  .env.local
  .env.*.local
  ```

## REMOVED Requirements

### Requirement: CloudBase 相关残留（已在之前任务中处理）
**Reason**: cloudbaserc.json 已从前端目录删除，无需再次处理
**Status**: ✅ 已确认干净

### Requirement: 多余的 spec 历史任务目录
**Reason**: .trae/specs/ 下有 8 个历史任务目录，大部分已完成且不再需要
**Migration**: 
1. 仅保留最新的 2 个相关任务：
   - `comprehensive-system-audit-redeploy/`（当前决策依据）
   - `frontend-build-failure-fix/`（最近的修复记录）
2. 其余 6 个归档或删除：
   - add-function-fix/
   - backend-deployment-fix/
   - backend-functionality-fix/
   - complete-deployment-solution/
   - ecommerce-backend-analysis/
   - frontend-development/
   - system-comprehensive-fix/
