# 🚀 方案B实施准备清单

**项目名称**: 绮管后台（Qiguan Admin System）
**准备日期**: 2026-04-09
**当前分支**: `feature/option-b-security-hardening`
**基础Commit**: `b51241fd` (清理完成)
**备份快照**: `52f281adf8cef064db4d3202511af4cc829d2431` (清理前)

---

## ✅ 第一部分：环境清理完成确认

### 清理成果总览

| 指标 | 清理前 | 清理后 | 改善 |
|------|--------|--------|------|
| **总文件数** | ~163 | **112** | **-31.3% ⬇️** |
| **Specs目录数** | 9 | **3** | **-66.7% ⬇️** |
| **MD文档数** | ~27 | **20** | **-25.9% ⬇️** |
| **脚本文件数** | ~16 | **14** | **-12.5% ⬇️** |
| **.gitignore规则数** | 9 | **28** | **+211% ⬆️** |

### 已删除内容清单

#### Phase A：历史任务目录（7个）
- ❌ `.trae/specs/backend-api-unified-error-handling/`
- ❌ `.trae/specs/ci-cd-pipeline-optimization/`
- ❌ `.trae/specs/database-schema-design-and-migration/`
- ❌ `.trae/specs/frontend-backend-integration-testing/`
- ❌ `.trae/specs/performance-optimization-audit/`
- ❌ `.trae/specs/security-hardening-implementation/`
- ❌ `backup/cloudbase_20260409/`

#### Phase B：冗余文档和脚本（15个）
- ❌ `FIXES_AND_DEPLOYMENT_GUIDE.md` (与DEPLOYMENT_GUIDE.md重复)
- ❌ `auto_push.bat` / `auto_push.sh` (过时脚本)
- ❌ `docs/CI_CD_ARCHITECTURE.md` (CI/CD已定型)
- ❌ `docs/TEST_REPORT.md` (测试报告过时)
- ❌ `fix_all_issues.sh` (一次性修复脚本)

### 验证结果

✅ **核心文件完整性**: 25/25 检查通过 (100%)
✅ **前端构建测试**: 退出码0, 耗时6.83s, 2260 modules
✅ **Git工作区**: 干净，无意外变更
✅ **关键文档保留**:
  - `DEPLOYMENT_GUIDE.md` - 部署指南
  - `COMPREHENSIVE_DECISION_REPORT.md` - 技术决策
  - `SERVER_DEPLOYMENT_GUIDE.md` - 服务器配置

---

## 📋 第二部分：方案B实施计划（4阶段）

### 🎯 目标概述

根据 [COMPREHENSIVE_DECISION_REPORT.md](../comprehensive-system-audit-redeploy/COMPREHENSIVE_DECISION_REPORT.md) 的建议，方案B将执行以下关键修复：

**预计总耗时**: ~70分钟（含验证）
**风险等级**: 中等（有完整回滚预案）
**停机时间**: ~10分钟（Phase 3重启服务期间）

---

### 🔴 Phase 1: 紧急安全修复（30分钟）

#### 1.1 生成强JWT密钥
```bash
# 在本地或服务器上执行
openssl rand -base64 64
# 输出示例: aB3xK9mP2qR7vL5wN8jF4hG6tY1uI0oE3zX5cV8bN2mQ4pL6kJ8hG0fD1sA3w...
```

**目标文件**:
- `e:\1\绮管后台\.env.production` (第30行 JWT_SECRET)
- `e:\1\绮管后台\middleware/auth.js` (第3行 jwt secret)

**当前问题**: 
- 弱密钥: `qiguan-production-secret-key-2026-change-me` (可预测)
- 硬编码在多个位置

**修复操作**:
1. 使用OpenSSL生成64字节随机密钥
2. 更新`.env.production`中的`JWT_SECRET`
3. 更新`middleware/auth.js`引用（如硬编码）
4. 验证JWT签发和验证正常

---

#### 1.2 修复CORS配置
**目标文件**: `e:\1\绮管后台\index.js` (第46行)

**当前问题**:
```javascript
cors({
  origin: '*',  // ❌ 危险：允许任何域名
  credentials: true
})
```

**修复为**:
```javascript
cors({
  origin: ['https://qimengzhiyue.cn', 'http://localhost:5173'],  // ✅ 仅允许生产+开发域名
  credentials: true,
  optionsSuccessStatus: 200
})
```

**验证方法**:
- 浏览器访问 https://qimengzhiyue.cn/dashboard → 应正常加载API数据
- 从其他域名尝试调用API → 应被CORS策略阻止

---

#### 1.3 添加认证中间件到未保护的路由

**需要添加auth中间件的路由**:
1. `routes/dashboard.js` - 仪表盘数据
2. `routes/products.js` - 产品CRUD
3. `routes/categories.js` - 分类管理
4. `routes/orders.js` - 订单管理
5. `routes/cart.js` - 购物车操作
6. `routes/users.js` - 用户管理

**修复示例** (以dashboard.js为例):
```javascript
// 文件顶部添加
const authMiddleware = require('../middleware/auth');

// 在路由定义前添加
router.use(authMiddleware.verifyToken);  // 所有dashboard路由都需要认证

// 或者对特定路由添加
router.get('/stats', authMiddleware.verifyToken, dashboardController.getStats);
```

**验证方法**:
- 未登录状态下访问 `/api/dashboard/stats` → 返回401 Unauthorized
- 登录后访问 → 正常返回数据

---

#### 1.4 移除硬编码的管理员密码
**目标文件**: `e:\1\绮管后台\qiguanqianduan\src\views\Login.vue` (第62-65行)

**当前问题**:
```javascript
// Login.vue 中的登录逻辑可能包含硬编码凭据
if (username === 'admin' && password === 'admin123') { ... }
```

**修复方案**:
1. 删除所有硬编码的用户名/密码检查
2. 完全依赖后端API认证 (`/api/auth/login`)
3. 前端仅负责收集凭据和显示错误信息

**验证方法**:
- 尝试使用 admin/admin123 登录 → 应调用后端API验证
- 使用错误密码 → 显示后端返回的错误消息

---

### 🟡 Phase 2: 前端重新构建（15分钟）

#### 2.1 服务器端代码同步
```bash
# SSH到服务器
ssh root@101.34.39.231

# 进入项目目录
cd /www/wwwroot/qimengzhiyue.cn  # 或实际路径

# 拉取最新代码（包含清理后的代码）
git pull origin feature/option-b-security-hardening
# 或
git pull origin master  # 如果已合并
```

#### 2.2 清理旧构建产物
```bash
# 进入前端目录
cd qiguanqianduan

# 删除旧的构建缓存和产物
rm -rf node_modules/.vite
rm -rf dist

# 重新安装依赖（确保一致性）
npm install
```

#### 2.3 执行生产构建
```bash
# 构建前端
npm run build

# 验证构建结果
ls -la dist/
# 期望输出：
# index.html (637 bytes)
# assets/ (19 files: 7 CSS + 11 JS + 1 HTML)
# 总大小约 2.71 MB
```

**预期结果**:
- ✅ 退出码0
- ✅ 无编译错误或警告
- ✅ dist/目录包含完整的静态资源

---

### 🟢 Phase 3: 配置更新与服务重启（10分钟）

#### 3.1 更新生产环境变量
**目标文件**: 服务器上的 `.env.production`

**需要更新的变量**:
```env
# 新的JWT强密钥（从Phase 1.1获取）
JWT_SECRET=<新生成的64字节随机字符串>

# CORS允许的域名（从Phase 1.2确定）
CORS_ORIGINS=https://qimengzhiyue.cn,http://localhost:5173
```

#### 3.2 应用标准Nginx配置
**目标文件**: `/etc/nginx/conf.d/qiguan.conf` (服务器)

**参考模板**: [SERVER_DEPLOYMENT_GUIDE.md](../frontend-build-failure-fix/SERVER_DEPLOYMENT_GUIDE.md) 第12章

**关键配置项**:
```nginx
server {
    listen 443 ssl http2;
    server_name qimengzhiyue.cn;

    # SSL证书路径（Let's Encrypt）
    ssl_certificate /etc/letsencrypt/live/qimengzhiyue.cn/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/qimengzhiyue.cn/privkey.pem;

    # 前端静态文件
    location / {
        root /www/wwwroot/qimengzhiyue.cn/qiguanqianduan/dist;
        try_files $uri $uri/ /index.html;
    }

    # API代理
    location /api/ {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

**验证配置语法**:
```bash
sudo nginx -t
# 期望输出: nginx: configuration file /etc/nginx/nginx.conf test is successful
```

#### 3.3 重启后端服务（PM2）
```bash
# 重启Node.js后端
pm2 restart all

# 或指定应用
pm2 restart qiguan-backend  # 根据ecosystem.config.js中的应用名

# 查看状态
pm2 status
pm2 logs --lines 50  # 检查启动日志
```

#### 3.4 重启Nginx
```bash
# 测试配置无误后重启
sudo systemctl reload nginx
# 或
sudo systemctl restart nginx

# 验证运行状态
sudo systemctl status nginx
```

**⚠️ 停机窗口**: 此步骤期间网站将不可用约10-30秒

---

### 🔵 Phase 4: 功能验证与安全测试（15分钟）

#### 4.1 基础连接性测试
```bash
# 测试HTTPS访问
curl -I https://qimengzhiyue.cn
# 期望: HTTP/2 200

# 测试API健康检查
curl https://qimengzhiyue.cn/api/health
# 期望: {"status":"ok","timestamp":"..."}
```

#### 4.2 登录功能验证
**测试步骤**:
1. 打开浏览器访问 https://qimengzhiyue.cn
2. 点击"登录"或自动跳转到登录页
3. 输入凭据：`admin` / `admin123`（首次使用）
4. **⚠️ 重要**: 登录成功后立即修改默认密码！

**预期结果**:
- ✅ 登录页面正常显示
- ✅ 输入正确凭据后跳转到Dashboard
- ✅ Dashboard数据显示正常（图表、统计数字）
- ✅ JWT Token已存储（localStorage或Cookie）

#### 4.3 API认证测试
```bash
# 测试未认证访问（应返回401）
curl https://qimengzhiyue.cn/api/dashboard/stats
# 期望: 401 Unauthorized 或 {"error":"No token provided"}

# 测试认证后访问（使用从浏览器复制的Token）
curl -H "Authorization: Bearer <YOUR_JWT_TOKEN>" https://qimengzhiyue.cn/api/dashboard/stats
# 期望: 200 OK + JSON数据
```

#### 4.4 安全头检查
```bash
# 检查安全响应头
curl -I https://qimengzhiyue.cn/api/health

# 期望看到以下头（至少部分）:
# X-Content-Type-Options: nosniff
# X-Frame-Options: DENY or SAMEORIGIN
# X-XSS-Protection: 1; mode=block
# Strict-Transport-Security: max-age=31536000; includeSubDomains
```

#### 4.5 功能完整性测试（浏览器手动测试）

**必测页面**:
- [ ] **Dashboard** - 数据图表、统计卡片、最近订单列表
- [ ] **Products** - 产品列表、搜索、添加/编辑/删除产品
- [ ] **Categories** - 分类CRUD操作
- [ ] **Orders** - 订单列表、状态筛选、详情查看
- [ ] **Users** - 用户列表、角色管理
- [ ] **Cart** - 购物车功能（如适用）

**必测API端点**:
- [ ] `POST /api/auth/login` - 登录认证
- [ ] `GET /api/dashboard/*` - 仪表盘数据（需Token）
- [ ] `GET/POST/PUT/DELETE /api/products` - 产品管理（需Token）
- [ ] `GET/POST/PUT/DELETE /api/categories` - 分类管理（需Token）
- [ ] `GET /api/orders` - 订单查询（需Token）

#### 4.6 性能基准测试（可选）
```bash
# 首页加载时间
time curl -s https://qimengzhiyue.cn > /dev/null
# 期望: < 2秒（首次加载含资源下载）

# API响应时间
time curl -s https://qimengzhiyue.cn/api/health > /dev/null
# 期望: < 200ms
```

---

## 📊 第三部分：实施检查清单

### Phase 1 准备项
- [ ] OpenSSL工具可用（本地或服务器）：`openssl version`
- [ ] 已读取COMPREHENSIVE_DECISION_REPORT.md第5-8章
- [ ] 明确所有需要修改的文件路径
- [ ] 准备好文本编辑器（VS Code / Vim / Nano）

### Phase 2 准备项
- [ ] SSH访问权限：`ssh root@101.34.39.231`
- [ ] 服务器Git已配置：`git config --list`
- [ ] 服务器Node.js版本 ≥ 18.x：`node --version`
- [ ] 服务器npm可用：`npm --version`

### Phase 3 准备项
- [ ] 新的.env.production内容已准备好
- [ ] Nginx配置模板已审核
- [ ] sudo权限可用（重启Nginx/PM2需要）
- [ ] PM2进程管理器已安装：`pm2 list`

### Phase 4 准备项
- [ ] 浏览器可用于功能测试（Chrome/Firefox/Edge）
- [ ] 测试账号信息：admin / admin123（将立即修改）
- [ ] Postman或类似API测试工具（可选但推荐）
- [ ] 回滚命令已熟悉：
  ```bash
  # 服务器端回滚
  git reset --hard HEAD~1
  pm2 restart all
  sudo systemctl reload nginx
  
  # 本地回滚
  git checkout master
  git reset --hard b51241fd  # 回到清理完成状态
  ```

---

## 🔄 第四部分：回滚预案

### 场景A：Phase 1-2失败（本地修改错误）
```bash
# 丢弃本地修改，回到清理完成状态
git checkout .
git clean -fd
# 或更彻底
git reset --hard b51241fd
```

### 场景B：Phase 3失败（服务器配置错误导致无法访问）
```bash
# SSH到服务器
ssh root@101.34.39.231

# 回滚到上一个稳定版本
cd /www/wwwroot/qimengzhiyue.cn
git log --oneline -5  # 查看历史
git reset --hard HEAD~1  # 回退一次提交

# 重启服务
pm2 restart all
sudo systemctl reload nginx

# 验证恢复
curl -I https://qimengzhiyue.cn
```

### 场景C：Phase 4发现问题（功能异常但可访问）
```bash
# 选项1: 快速热修复（推荐）
# 直接在服务器上修改问题文件，然后重启PM2

# 选项2: 完整回滚
# 同场景B的操作流程
```

### 场景D：灾难性故障（完全无法SSH或服务崩溃）
联系云服务商技术支持，说明：
- 最后一次成功操作的时间点
- 当前错误现象
- 期望回滚到的版本（commit hash: b51241fd 或 52f281ad）

---

## 📞 第五部分：联系方式和支持

### 内部支持
- **项目负责人**: [您的名字]
- **技术决策依据**: COMPREHENSIVE_DECISION_REPORT.md
- **部署指南**: SERVER_DEPLOYMENT_GUIDE.md + DEPLOYMENT_GUIDE.md

### 外部支持
- **云服务器提供商**: 腾讯云控制台
- **数据库服务**: TDSQL-C MySQL 控制台（10.0.0.16:3306）
- **域名/DNS**: 域名注册商管理面板

### 紧急回滚命令速查
```bash
# 一键回滚到清理后状态（最安全）
git reset --hard b51241fd && pm2 restart all && sudo systemctl reload nginx

# 一键回滚到清理前状态（如果清理有问题）
git reset --hard 52f281adf8cef064db4d3202511af4cc829d2431 && pm2 restart all && sudo systemctl reload nginx
```

---

## ✨ 第六部分：后续优化建议（非本次范围）

### 高优先级（建议下次迭代处理）
1. **数据库迁移** - 将TDSQL-C迁移到专用实例（当前共享实例可能有性能限制）
2. **监控告警** - 集成Sentry（错误追踪）+ Prometheus（指标监控）
3. **CI/CD流水线** - 自动化测试→构建→部署（GitHub Actions/GitLab CI）
4. **日志集中化** - ELK Stack或云厂商日志服务

### 中优先级（1-2周内）
1. **密码策略强制** - 用户首次登录必须修改默认密码
2. **API限流** - 引入rate-limiting中间件防止暴力破解
3. **审计日志** - 记录关键操作（登录、删除、权限变更）
4. **备份自动化** - 定期数据库备份 + 前端dist归档

### 低优先级（长期规划）
1. **微服务拆分** - 将单体应用拆分为用户/订单/商品等服务
2. **容器化部署** - Docker + Kubernetes编排
3. **多环境隔离** - dev/staging/prod完整环境链
4. **性能优化** - Redis缓存、CDN加速、图片压缩

---

## 📝 实施日志

| 时间戳 | 操作 | 操作人 | 结果 | 备注 |
|--------|------|--------|------|------|
| 2026-04-09 XX:XX | 环境清理完成 | AI Assistant | ✅ 成功 | Commit: b51241fd |
| | Phase 1 开始: JWT密钥更新 | | | |
| | Phase 1 完成: CORS修复 | | | |
| | Phase 1 完成: Auth中间件添加 | | | |
| | Phase 1 完成: 移除硬编码密码 | | | |
| | Phase 2 开始: 服务器代码同步 | | | |
| | Phase 2 完成: 前端重新构建 | | | |
| | Phase 3 开始: .env更新 | | | |
| | Phase 3 完成: Nginx配置应用 | | | |
| | Phase 3 完成: 服务重启 | | | |
| | Phase 4 开始: 功能验证 | | | |
| | Phase 4 完成: 安全测试 | | | |
| | **🎉 方案B实施完成** | | | |

---

## 🎯 总结

### ✅ 当前状态
- **环境清理**: 100%完成，项目整洁度提升31.3%
- **代码质量**: 构建验证通过，核心文件完整性100%
- **Git状态**: 干净的工作区，在feature分支上
- **文档完备**: 实施计划、回滚预案、检查清单齐全

### 🚀 下一步行动
**立即开始执行 Phase 1: 紧急安全修复**

按照本清单第二部分的详细步骤，依次完成：
1. 生成新的JWT强密钥
2. 修复CORS配置
3. 添加认证中间件
4. 移除硬编码密码

每个子步骤完成后，在本文件的"实施日志"表格中记录进度。

---

**文档版本**: 1.0
**最后更新**: 2026-04-09
**维护者**: AI Assistant (Trae IDE)
**审批状态**: ✅ 待开始实施
