# 修复登录故障并全面增强后台系统 - 验证清单

## Phase 1: 紧急修复登录问题 (P0 - Critical)

### Task 1.1: 诊断登录失败根因
- [x] **1.1.1** 后端服务器运行状态和日志检查完成，无致命错误
- [x] **1.1.2** 数据库连接测试通过，管理员账户存在且有效（username, role=admin, status=active）
- [x] **1.1.3** JWT_SECRET配置正确（长度≥32字符），token生成/验证正常
- [x] **1.1.4** 登录API端点 `POST /api/v1/auth/login` 返回正确响应：
  - 正确凭据 → 200 + `{success:true, data:{token, user}}`
  - 错误密码 → 401 + `{success:false, error:{code:'INVALID_CREDENTIALS'}}`
  - 缺少字段 → 400 + 字段验证错误
- [x] **1.1.5** CORS配置正确，前端域名 `https://qimengzhiyue.cn` 在允许列表中，无跨域错误
- [x] **1.1.6** 前端Login.vue组件请求链路正常：表单提交→axios请求→响应处理→token存储→路由跳转

### Task 1.2: 实施登录修复方案
- [x] **1.2.1** 根据诊断结果修复了核心问题（认证逻辑bug：字段名不匹配+密码哈希格式错误）
- [x] **1.2.2** 登录错误提示友好化，用户能看到明确的错误原因（网络错误/凭证错误/服务器错误/403禁用）
- [ ] **1.2.3** 登录功能单元测试全部通过 (tests/test_login.js)
  - ✅ 正确凭据返回200 + token
  - ✅ 错误密码返回401 + 错误消息
  - ✅ 缺少字段返回400 + 验证错误
  - ✅ 封禁账户返回403 + 封禁提示
  - ✅ 空用户名返回400 + 必填字段提示
- [x] **1.2.4** 本地构建成功 (`npm run build` exit code 0)，本地登录流程完整可用
- [ ] **1.2.5** 生产部署成功：
  - Git push/pull 无误
  - 前端重新构建成功（如有改动）
  - PM2重启成功 (`pm2 restart all`)
  - Nginx缓存已清除
  - HTTP状态码200，无控制台报错
- [ ] **1.2.6** 生产环境登录验收通过：
  - 浏览器访问生产后台地址正常加载
  - 输入管理员凭据提交后跳转到Dashboard
  - 左侧菜单完整显示，各页面可正常访问
  - 退出登录后再登录仍然正常
  - 不同浏览器测试通过 (Chrome/Firefox/Edge)

---

## Phase 2: 全面系统审查与优化 (P1 - High)

### Task 2.1: 后端代码质量审计
- [ ] **2.1.1** 所有路由文件 (routes/*.js) 都有完善的try-catch错误处理
- [ ] **2.1.2** 所有SQL查询使用参数化绑定 (?占位符)，无字符串拼接风险
- [ ] **2.1.3** middleware/auth.js权限验证严格，敏感接口都有认证保护
- [ ] **2.1.4** API响应格式100%统一：
  - 成功: `{success:true, data:{...}}`
  - 错误: `{success:false, error:{code, message}}`
  - 分页: `{success:true, data:{list:[], pagination:{total, page, pageSize}}}`

### Task 2.2: 服务器配置优化
- [ ] **2.2.1** Nginx配置已审查并优化：
  - 反向代理配置正确 (proxy_pass)
  - Gzip压缩已启用
  - 安全头已设置 (X-Frame-Options等)
  - 请求大小限制合理
  - 超时设置适当
- [ ] **2.2.2** PM2配置已优化：
  - 实例数量 ≥ 2 (production) 或 max
  - 内存限制已配置
  - 自动重启策略启用
  - 日志轮转配置完善
- [ ] **2.2.3** 环境变量安全审计通过：
  - DB_PASSWORD为强密码
  - JWT_SECRET长度≥32且随机
  - .gitignore排除.env文件
  - 代码中无硬编码密钥
- [ ] **2.2.4** 日志系统完善：
  - PM2日志轮转配置生效
  - 关键业务逻辑有结构化日志
  - 日志级别设置合理 (prod: warn, dev: debug)

### Task 2.3: 数据库健康检查与优化
- [ ] **2.3.1** 所有必需数据表存在且结构正确：
  - ✅ users, products, categories, orders, order_items
  - ✅ cart, favorites, footprints, coupons, user_addresses
  - ✅ banners, homepage_config (新增)
- [ ] **2.3.2** 关键索引已创建并有效：
  - users(username), users(email) - UNIQUE
  - products(category_id, status) - INDEX
  - orders(user_id, status, created_at) - COMPOSITE INDEX
  - cart(user_id, product_id) - UNIQUE COMPOSITE
  - EXPLAIN分析显示关键查询使用索引，无全表扫描
- [ ] **2.3.3** 初始数据完整性验证通过：
  - 管理员账户存在 (role='admin', status='active')
  - 分类数据 > 0 条
  - 商品数据 > 0 条 (status='active')
  - 如缺失则已从init_data.sql导入
- [ ] **2.3.4** 连接池配置优化：
  - connectionLimit根据并发调整 (5-50)
  - acquireTimeout/connectTimeout = 60000ms
  - keepAliveInitialDelay = 0 (连接保活)
  - 高负载下连接池稳定，无泄漏

---

## Phase 3: 核心功能拓展 (P2 - Medium)

### Task 3.1: 🛒 购物车管理系统
#### Backend:
- [ ] **3.1.1** `routes/cart_admin.js` 创建完成，API接口实现：
  - `GET /api/v1/admin/carts` - 支持分页、筛选 (userId, dateRange, itemCountRange, status)
  - `GET /api/v1/admin/carts/stats` - 统计数据 (总数、商品数、总金额、废弃率、趋势)
  - `DELETE /api/v1/admin/carts/:id` - 删除单个购物车
  - `DELETE /api/v1/admin/carts/expired` - 批量清理过期购物车 (>30天未更新)
  - 权限: verifyToken + requireRole('admin')
  - Postman/curl测试全部通过

- [ ] **3.1.2** 路由已在index.js注册，访问不返回404

#### Frontend:
- [ ] **3.1.3** `CartAdmin.vue` 页面组件创建完成：
  - 顶部统计卡片显示: 总购物车数 | 总商品数 | 总价值 | 废弃率
  - 数据表格(el-table)列完整: 用户ID/昵称 | 商品数量 | 总金额 | 最后更新 | 操作
  - 分页功能正常 (el-pagination)
  - 筛选功能: 按用户、日期范围筛选
  - 操作按钮: "清理过期购物车" (确认弹窗) | "导出数据"
  - ECharts图表: 创建趋势折线图 + 商品数量分布柱状图
  - UI风格与Products.vue/Orders.vue一致

- [ ] **3.1.4** 路由和菜单配置完成：
  - router/index.js添加 `/cart-admin` 路由
  - Sidebar.vue添加 "购物车管理" 菜单项
  - 点击可导航到页面

---

### Task 3.2: 🎫 优惠券管理系统
#### Database:
- [ ] **3.2.1** 数据表创建成功：
  - coupons表 (id, name, code, type, value, min_order_amount, stock, per_user_limit, used_count, start_time, end_time, status, description, timestamps)
  - user_coupons表 (id, user_id, coupon_id, status, order_id, received_at, used_at, 外键约束, 唯一索引)
  - 可插入测试数据验证

#### Backend:
- [ ] **3.2.2** `routes/coupons.js` CRUD API完整：
  - `GET /api/v1/coupons` - 列表 (分页+筛选: status, type, dateRange, keyword)
  - `POST /api/v1/coupons` - 创建 (校验必填、时间合理性、库存>0)
  - `GET /api/v1/coupons/:id` - 详情
  - `PUT /api/v1/coupons/:id` - 更新
  - `DELETE /api/v1/coupons/:id` - 删除 (软删除/inactive)
  - `GET /api/v1/coupons/:id/stats` - 使用统计 (领取数、使用数、使用率、领券用户)
  - `GET /api/v1/coupons/stats/overview` - 全局统计 (总数、活跃、今日领取/使用)

#### Frontend:
- [ ] **3.2.3** `Coupons.vue` 页面功能完整：
  - 优惠券列表表格: 名称 | 优惠码 | 类型 | 优惠值 | 库存/已用 | 有效期 | 状态标签 | 操作
  - 新建/编辑弹窗(el-dialog): 表单字段齐全 (名称、优惠码、类型、优惠值、最低消费、库存、每人限领、有效期、说明)
  - 表单验证严格 (必填、数值范围、时间逻辑)
  - 统计面板: 顶部卡片(总数|活跃|今日领取|今日使用) + 使用率饼图 + 领取趋势图

- [ ] **3.2.4** 路由 `/coupons` 和侧边栏菜单 "优惠券管理" 配置完成

---

### Task 3.3: 📢 内容管理系统（CMS）
#### Database:
- [ ] **3.3.1** 内容管理表创建成功：
  - banners表 (title, image_url, link_url, link_type, position, time_range, status, clicks)
  - homepage_config表 (config_key UNIQUE, config_value JSON, description)
  - 初始配置数据插入 (recommended_products, hot_products, promotion_banner, announcement)

#### Backend:
- [ ] **3.3.2** Content API增强完成：
  - Banner CRUD: GET/POST/PUT/DELETE + reorder
  - 首页配置: GET config / PUT config / preview
  - 图片上传集成 (multer中间件, ./uploads/banners/)
  - 返回可访问URL

#### Frontend:
- [ ] **3.3.3** `ContentManage.vue` 子模块完整：
  - Banner管理: el-upload图片上传 + 拖拽排序 + 手机预览 + 启用/禁用开关
  - 推荐商品配置: 商品搜索选择器 + 已选列表(拖拽排序) + 保存
  - 热门商品配置: 同上
  - 公告编辑器: 富文本编辑器(wangeditor/tinymce) + 实时保存草稿 + 发布/撤回

- [ ] **3.3.4** 路由 `/content-manage` 和菜单 "内容管理" 配置完成

---

### Task 3.4: 📊 增强版仪表盘
#### Backend:
- [ ] **3.4.1** Dashboard API扩展完成 (routes/dashboard.js)：
  - 新增cartStats (总购物车、废弃率、平均商品数、趋势)
  - 新增favoriteStats (收藏总数、Top10商品、趋势)
  - 新增couponStats (活跃券、今日领取/使用、使用率)
  - 新增recentOrders (最近10条订单详情)
  - 新增userGrowth (今日/周新用户、增长率)
  - 新增realtimeMetrics (在线用户、近1小时订单、今日收入)
  - 使用缓存优化性能，响应时间<500ms

#### Frontend:
- [ ] **3.4.2** Dashboard.vue升级完成：
  - 新增统计卡片行: 购物车转化率 | 收藏总数 | 活跃优惠券 | 在线用户
  - ECharts图表区域:
    - 收入趋势图 (双轴: 订单量+销售额, 30天)
    - 商品收藏排行 (横向柱状图, Top 10)
    - 用户增长曲线 (面积图, 7天/30天切换)
    - 订单状态分布 (环形图)
  - 实时动态区: 最近订单自动滚动列表 + 快捷操作按钮
  - 视觉美观，数据实时更新流畅

---

## Phase 4: 高级功能拓展 (P3 - Low Priority)

### Task 4.1: ❤️ 收藏与足迹管理
- [ ] **4.1.1** 收藏管理功能完成：
  - 后端 `favorites_admin.js`: 列表(按商品/用户筛选) + 统计 + 删除
  - 前端 `Favorites.vue`: 热门排行 + 行为分析 + 趋势图表
  - 可查看和分析收藏数据

- [ ] **4.1.2** 足迹管理功能完成：
  - 后端 `footprints_admin.js`: 列表 + 热门页面 + 用户路径分析
  - 前端 `Footprints.vue`: 页面热度地图 + 活跃时段 + 跳出率/停留时长
  - 可追踪用户浏览行为

---

### Task 4.2: 📍 地址管理与物流配置
- [ ] **4.2.1** 地址管理功能完成：
  - 后端 `address_admin.js`: 地址库查看 + 地区统计分析
  - 前端 `AddressBook.vue`: 地区分布(可选地图) + 区域销量热力图
  - 可查看配送地址分布

- [ ] **4.2.2** 物流管理功能完成：
  - 后端 `logistics.js`: 物流公司CRUD + 运费模板 + 对接快递API
  - 前端 `Logistics.vue`: 公司列表 + 运费模板可视化 + 成本报表
  - 可配置物流选项和运费规则

---

### Task 4.3: 🔍 搜索与客服管理
- [ ] **4.3.1** 搜索关键词管理完成：
  - 后端 `search_admin.js`: 热门词列表 + 推荐/编辑/删除 + 黑名单
  - 前端 `SearchManage.vue`: 排行榜(词频/转化率) + 推荐词配置 + 敏感词过滤
  - 可管理和优化搜索体验

- [ ] **4.3.2** 客服与售后工具完成：
  - 后端 `service_admin.js`: FAQ管理(CRUD+分类) + 售后工单(状态流转) + 详情回复
  - 前端 `CustomerService.vue`: FAQ富文本编辑器 + 工单Kanban看板 + 统计
  - 可管理客服知识和售后工单

---

## Phase 5: 系统优化与加固 (P4 - Future)

### Task 5.1: 性能优化
- [ ] **5.1.1** 数据库查询优化：
  - EXPLAIN分析慢查询，优化复杂SQL
  - 添加复合索引提升查询性能
  - (可选) 实施读写分离

- [ ] **5.1.2** API响应缓存：
  - Redis/内存缓存实施 (dashboard、热门商品)
  - 合理TTL设置
  - 写入时主动清除缓存策略

- [ ] **5.1.3** 前端性能优化：
  - 所有路由懒加载完成
  - 组件级代码分割
  - 图片懒加载和压缩
  - CDN加速静态资源

---

### Task 5.2: 安全加固
- [ ] **5.2.1** 操作审计日志：
  - audit_logs表创建完成
  - 记录关键操作 (登录、增删改查、配置变更)
  - 包含: 操作人、时间、IP、类型、前后数据
  - 审计日志查看界面 (只读)

- [ ] **5.2.2** 权限细化 (RBAC)：
  - 角色定义: 超管、运营、客服、财务
  - 菜单和按钮级别权限控制
  - 数据权限 (按角色/部门过滤)

- [ ] **5.2.3** 数据脱敏：
  - 手机号脱敏: 138****1234
  - 身份证脱敏: 110***********1234
  - 地址脱敏: 北京市朝阳区***路**号
  - 日志中不含明文密码和token

---

### Task 5.3: 监控与告警
- [ ] **5.3.1** 应用监控：
  - Prometheus/Grafana 或轻量metrics接口
  - 监控指标: QPS、响应时间、错误率、资源使用率

- [ ] **5.3.2** 告警通知：
  - 阈值设置: 错误率>5%, 响应>2s, 内存>80%
  - 通知渠道: 企业微信/钉钉/邮件
  - 告警升级策略

- [ ] **5.3.3** 备份策略：
  - 数据库每日自动备份 (mysqldump)
  - 保留最近30天备份
  - 备份完整性校验
  - (可选) 定期恢复演练

---

## 综合验收标准

### Critical (必须满足):
- [ ] **C1**: 登录功能完全恢复，成功率 > 99.9%，支持多浏览器
- [ ] **C2**: 现有功能零回归 (products, categories, orders, users, dashboard原功能正常)
- [ ] **C3**: 数据库连接稳定，有重连机制，无连接泄漏
- [ ] **C4**: 所有新功能遵循统一代码规范和API格式

### Important (应该满足):
- [ ] **I1**: 至少3个新管理模块完全可用 (推荐: CartAdmin, Coupons, ContentManage)
- [ ] **I2**: 增强版Dashboard展示全面运营数据 (≥8个统计卡片, ≥4个图表)
- [ ] **I3**: API响应时间达标 (读<500ms, 写<1000ms p95)
- [ ] **I4**: 错误处理友好，每个操作都有清晰的用户反馈

### Nice to Have (最好满足):
- [ ] **N1**: 全部10个计划功能模块实现 (Phase 3 + Phase 4)
- [ ] **N2**: 高级分析和报表功能 (用户行为分析、销售预测等)
- [ ] **N3**: 实时监控仪表盘 (在线用户、实时订单流)
- [ ] **N4**: 自动化运维 (备份、监控、告警、自愈)

---

## 回归测试检查清单

### 基础功能回归 (每次修改后必测):
- [ ] **RT1**: 登录 → Dashboard → 各页面导航流畅
- [ ] **RT2**: 商品管理: 添加 → 列表显示 → 编辑 → 更新 → 删除 → 列表刷新
- [ ] **RT3**: 分类管理: 添加 → 列表显示 → 编辑 → 更新 → 删除
- [ ] **RT4**: 用户管理: 列表加载 → 角色变更 → 启用/禁用
- [ ] **RT5**: 订单管理: 列表加载 → 详情查看 → 状态变更
- [ ] **RT6**: Dashboard统计数据准确 (总数、金额、趋势)

### 新功能验收 (Phase 3完成后测试):
- [ ] **NF1**: 购物车管理: 统计卡片正确 → 表格数据加载 → 筛选/分页 → 清理过期 → 导出
- [ ] **NF2**: 优惠券管理: 创建 → 列表 → 编辑 → 删除 → 统计查看
- [ ] **NF3**: 内容管理: 上传Banner → 排序 → 配置推荐 → 编辑公告 → 发布
- [ ] **NF4**: 增强Dashboard: 新卡片显示 → 图表渲染 → 实时数据更新

### 性能测试 (可选):
- [ ] **PT1**: 并发100用户，API P95响应时间 < 1000ms
- [ ] **PT2**: 数据库查询无全表扫描 (EXPLAIN验证)
- [ ] **PT3**: 前端首屏加载时间 < 3s (3G网络)
- [ ] **PT4**: 内存使用稳定，无明显泄漏 (持续运行24h)

### 安全测试 (推荐):
- [ ] **ST1**: SQL注入测试 (所有输入框尝试 ' OR 1=1 --)
- [ ] **ST2**: XSS攻击测试 (输入 <script>alert('xss')</script>)
- [ ] **ST3**: 未授权访问测试 (直接访问需要认证的API)
- [ ] **ST4**: 权限越权测试 (普通用户尝试admin操作)

---

## 最终交付物清单

### 文档类:
- [ ] **D1**: 《登录问题诊断报告》 (根因分析+解决方案)
- [ ] **D2**: 《系统审计报告》 (代码质量+服务器+数据库)
- [ ] **D3**: 《功能拓展说明文档》 (新增模块的使用手册)
- [ ] **D4**: 《部署更新文档》 (生产环境变更记录)
- [ ] **D5**: 《API接口文档更新》 (Swagger/OpenAPI)

### 代码类:
- [ ] **CD1**: 后端新增路由文件 (cart_admin, coupons, favorites_admin, footprints_admin, address_admin, logistics, search_admin, service_admin)
- [ ] **CD2**: 前端新增Vue组件 (CartAdmin, Coupons, ContentManage, Favorites, Footprints, AddressBook, Logistics, SearchManage, CustomerService, Dashboard升级版)
- [ ] **CD3**: 数据库迁移脚本 (新建表的SQL)
- [ ] **CD4**: 单元测试和集成测试代码

### 配置类:
- [ ] **CF1**: Nginx配置更新 (如需)
- [ ] **CF2**: PM2 ecosystem.config.js更新
- [ ] **CF3**: .env.production环境变量更新 (如需)
- [ ] **CF4**: 路由配置和菜单配置更新

---

## 验收签名

### Phase 1 完成:
- 开发者签字: _______________ 日期: _______
- 测试者签字: _______________ 日期: _______
- 用户验收: _______________ 日期: _______

### Phase 2 完成:
- 开发者签字: _______________ 日期: _______
- 测试者签字: _______________ 日期: _______

### Phase 3 完成:
- 开发者签字: _______________ 日期: _______
- 测试者签字: _______________ 日期: _______
- 用户验收: _______________ 日期: _______

### Phase 4 完成 (可选):
- 开发者签字: _______________ 日期: _______
- 测试者签字: _______________ 日期: _______

### Phase 5 完成 (可选):
- 开发者签字: _______________ 日期: _______
- 运维签字: _______________ 日期: _______

### 项目最终验收:
- 项目负责人: _______________ 日期: _______
- 用户代表: _______________ 日期: _______
- 最终结论: □ 通过  □ 有条件通过  □ 不通过
- 备注: _________________________________
