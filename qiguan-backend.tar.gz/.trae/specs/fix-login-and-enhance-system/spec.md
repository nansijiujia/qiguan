# 修复登录故障并全面增强后台系统 Spec

## Why
用户报告无法登录后台管理系统，需要紧急修复认证功能。同时，对比小程序已有功能发现后台系统存在大量功能缺失，需要进行全面的功能拓展和系统优化，确保后台能够完整支撑小程序电商平台的运营需求。

## What Changes

### 🔴 紧急修复 (P0)
- **诊断并修复登录失败问题**
  - 检查数据库连接状态和用户表数据完整性
  - 验证JWT认证流程的正确性
  - 测试前后端API通信链路
  - 确保管理员账户可用且密码正确
  - 修复CORS跨域配置问题（如有）
  - 验证环境变量配置正确性

### 🟡 全面审查与修复 (P1)
- **后端代码质量审查**
  - 检查所有路由的错误处理机制
  - 验证数据库操作的SQL注入防护
  - 审计中间件的安全性
  - 检查API响应格式的一致性
  
- **服务器配置优化**
  - Nginx配置审查与优化
  - PM2进程管理配置检查
  - 环境变量安全性审计
  - 日志配置完善
  
- **数据库健康检查**
  - 表结构完整性验证
  - 索引优化
  - 初始数据完整性检查
  - 连接池配置优化

### 🟢 功能拓展 (P2) - 基于小程序功能对比
根据小程序`app.json`和`utils/api.js`分析，需新增以下后台功能：

#### 新增管理模块：
1. **🛒 购物车管理**
   - 购物车列表查看（支持筛选、搜索）
   - 购物车数据分析（ abandoned cart 统计）
   - 批量清理异常数据

2. **❤️ 收藏管理**
   - 用户收藏数据统计
   - 热门收藏商品排行
   - 收藏趋势分析

3. **👣 浏览足迹管理**
   - 用户行为轨迹分析
   - 热门页面访问统计
   - 用户活跃度报表

4. **🎫 优惠券管理**
   - 优惠券CRUD操作
   - 优惠券发放记录
   - 使用率统计分析
   - 过期自动清理

5. **📍 地址管理**
   - 用户地址库查看
   - 区域分布统计
   - 异常地址标记

6. **📢 内容管理（CMS）**
   - Banner图片管理（轮播图配置）
   - 首页推荐商品配置
   - 促销活动管理
   - 公告/通知发布

7. **🔍 搜索优化**
   - 热门搜索词管理
   - 搜索词黑名单
   - SEO关键词配置

8. **🚚 物流管理**
   - 物流公司配置
   - 运费模板管理
   - 物流跟踪接口对接

9. **💬 客服与售后**
   - FAQ管理
   - 售后工单处理
   - 客服聊天记录查看（如有）

10. **📊 增强Dashboard**
    - 新增：购物车转化率
    - 新增：收藏/足迹统计卡片
    - 新增：优惠券使用情况
    - 新增：实时订单监控
    - 新增：用户增长趋势图

### 🔵 系统稳定性增强 (P3)
- **错误监控**
  - 全局错误日志收集
  - 关键指标告警配置
  - 性能监控面板

- **性能优化**
  - API响应时间优化
  - 数据库查询优化
  - 静态资源缓存策略
  - 接口限流配置

- **安全加固**
  - 敏感数据脱敏显示
  - 操作日志审计
  - 权限细化控制
  - 定期备份机制

## Impact

### Affected specs:
- `add-data-not-displaying` (已完成的数据显示修复)
- `comprehensive-system-audit-redeploy` (之前的全面审计)

### Affected code:
**核心文件（需修改）**:
- `qiguanqianduan/src/views/Login.vue` - 登录组件（可能需要调整）
- `routes/auth.js` - 认证路由（核心修复点）
- `middleware/auth.js` - JWT中间件（验证逻辑）
- `db_mysql.js` - 数据库连接（连接诊断）
- `.env.production` - 环境变量配置
- `index.js` - 主服务器文件（CORS等配置）
- `nginx.conf.v2` - Nginx配置（如需调整）

**新增文件（功能拓展）**:
- `routes/cart_admin.js` - 购物车管理API
- `routes/favorites.js` - 收藏管理API
- `routes/footprints.js` - 足迹管理API
- `routes/coupons.js` - 优惠券管理API
- `routes/content.js` - 内容管理API（已存在，需增强）
- `routes/address.js` - 地址管理API
- `routes/logistics.js` - 物流管理API
- `routes/search_admin.js` - 搜索管理API
- `routes/service.js` - 客服售后API

**前端新增组件**:
- `qiguanqianduan/src/views/CartAdmin.vue`
- `qiguanqianduan/src/views/Favorites.vue`
- `qiguanqianduan/src/views/Footprints.vue`
- `qiguanqianduan/src/views/Coupons.vue`
- `qiguanqianduan/src/views/ContentManage.vue`
- `qiguanqianduan/src/views/AddressBook.vue`
- `qiguanqianduan/src/views/Logistics.vue`
- `qiguanqianduan/src/views/SearchManage.vue`
- `qiguanqianduan/src/views/CustomerService.vue`

## ADDED Requirements

### Requirement: 登录功能恢复
The system SHALL provide a working authentication mechanism that allows administrators to successfully log in to the backend management system.

#### Scenario: Successful admin login
- **GIVEN** the backend server is running and database is connected
- **WHEN** an administrator submits valid credentials (username + password)
- **THEN** the system SHALL return a valid JWT token and user information
- **AND** the frontend SHALL store the token and redirect to dashboard
- **AND** all subsequent API requests SHALL include the authentication token

#### Scenario: Login error handling
- **GIVEN** the login form is submitted with invalid credentials
- **WHEN** the username or password is incorrect
- **THEN** the system SHALL return a clear error message (401 status)
- **AND** the frontend SHALL display "用户名或密码错误" to the user

### Requirement: 数据库连接健康检查
The system SHALL maintain a stable connection to the MySQL/TDSQL-C database and automatically handle reconnection on failures.

#### Scenario: Database connectivity verification
- **WHEN** the server starts or after a connection failure
- **THEN** the system SHALL attempt to reconnect with configured retry logic
- **AND** log connection status for monitoring purposes

### Requirement: 购物车管理功能
The system SHALL provide administrative interfaces for viewing and managing shopping cart data.

#### Scenario: View cart analytics
- **GIVEN** an authenticated administrator accesses the cart management page
- **WHEN** the page loads
- **THEN** the system SHALL display cart statistics (total carts, items, conversion rate)
- **AND** provide filtering options by date range, user, and status

### Requirement: 优惠券管理功能
The system SHALL provide full CRUD operations for coupon management.

#### Scenario: Create new coupon
- **GIVEN** an administrator wants to create a promotional coupon
- **WHEN** they fill in coupon details (name, discount, validity period, usage limit)
- **AND** submit the form
- **THEN** the system SHALL create the coupon and make it available to users

### Requirement: 内容管理系统（CMS）
The system SHALL allow administrators to manage homepage content including banners, recommendations, and promotions.

#### Scenario: Update homepage banner
- **GIVEN** an administrator accesses the content management section
- **WHEN** they upload a new banner image and configure display order
- **AND** save the changes
- **THEN** the homepage SHALL immediately reflect the updated banner for all users

### Requirement: 增强版仪表盘
The system SHALL provide a comprehensive dashboard with real-time metrics covering all e-commerce operations.

#### Scenario: Dashboard displays complete overview
- **GIVEN** an administrator logs into the system
- **WHEN** they navigate to the dashboard
- **THEN** the system SHALL display:
  - Total revenue, orders, users, products counts
  - Cart conversion rate and abandonment rate
  - Top favorite products ranking
  - Active coupons and usage statistics
  - Recent orders timeline with status indicators
  - User growth trend chart (7-day/30-day)

## MODIFIED Requirements

### Requirement: 错误处理统一性
All API endpoints SHALL return consistent error responses following the format:
```json
{
  "success": false,
  "error": {
    "code": "ERROR_CODE",
    "message": "Human-readable error message"
  }
}
```
**Modification**: Enhance existing error handling to include detailed logging, stack traces (in development mode), and correlation IDs for debugging.

### Requirement: API响应性能
All API endpoints SHALL respond within acceptable time limits:
- Read operations: < 500ms (p95)
- Write operations: < 1000ms (p95)
- Search operations: < 2000ms (p95)
**Modification**: Add query optimization, indexing strategy, and caching layer where appropriate.

## REMOVED Requirements
None - This is purely additive enhancement with critical bug fixes.

---

## Implementation Strategy

### Phase 1: Emergency Fix (0-2 hours)
**Focus**: Restore login functionality immediately
1. Diagnose root cause of login failure
2. Test database connectivity
3. Verify user credentials in database
4. Fix identified issues
5. Deploy and verify login works
6. Document fix for future reference

### Phase 2: System Audit & Stabilization (2-4 hours)
**Focus**: Ensure system stability before adding features
1. Complete code review of all routes
2. Database health check and optimization
3. Server configuration audit
4. Security vulnerability scan
5. Performance baseline measurement
6. Fix any discovered issues

### Phase 3: Core Feature Expansion (4-8 hours)
**Focus**: Implement highest-priority missing features
1. Shopping cart administration
2. Coupon management system
3. Content management (banners/homepage)
4. Enhanced dashboard with new metrics
5. User behavior analytics (favorites, footprints)

### Phase 4: Advanced Features (8-12 hours)
**Focus**: Complete remaining feature gaps
1. Address book management
2. Logistics configuration
3. Search keyword management
4. Customer service tools
5. Comprehensive reporting

### Phase 5: Optimization & Hardening (12-16 hours)
**Focus**: Production readiness
1. Performance optimization
2. Error monitoring setup
3. Security hardening
4. Load testing
5. Documentation completion
6. Backup/recovery procedures

---

## Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|------------|--------|------------|
| Database connection failure during fix | Medium | High | Implement fallback mechanism, thorough testing |
| Breaking existing functionality | Low | High | Comprehensive regression testing |
| Feature scope creep | Medium | Medium | Strict adherence to spec, phased delivery |
| Performance degradation | Low | Medium | Baseline measurement, optimize incrementally |
| Security vulnerabilities introduced | Low | High | Code review, security scanning |

---

## Success Criteria

### Critical (Must Have):
- [ ] Login functionality fully restored and tested
- [ ] No regressions in existing features (products, categories, orders, users, dashboard)
- [ ] Database connection stable with proper error handling
- [ ] All new features follow established code patterns and conventions

### Important (Should Have):
- [ ] At least 3 new management modules fully functional (cart, coupons, content)
- [ ] Enhanced dashboard displaying comprehensive metrics
- [ ] Response times meet performance requirements
- [ ] Proper error handling and user feedback in all new features

### Nice to Have (Could Have):
- [ ] All 10 planned feature modules implemented
- [ ] Advanced analytics and reporting
- [ ] Real-time monitoring dashboard
- [ ] Automated backup system

---

## Testing Strategy

### Unit Testing:
- All new API endpoints with various input scenarios
- Authentication middleware edge cases
- Database operation validation
- Utility function correctness

### Integration Testing:
- Frontend-backend communication flows
- Authentication lifecycle (login → token → API calls → logout)
- CRUD operations end-to-end
- Error propagation and handling

### User Acceptance Testing:
- Administrator workflow for each new feature
- Mobile responsiveness (if applicable)
- Cross-browser compatibility
- Accessibility compliance

### Performance Testing:
- Load testing with simulated concurrent users
- Database query performance profiling
- Memory usage monitoring under load

---

## Rollback Plan

If critical issues arise during deployment:
1. Immediately revert to last known good commit
2. Restore database from pre-deployment backup
3. Notify stakeholders of rollback
4. Conduct post-mortem analysis
5. Implement fixes in separate branch
6. Re-deploy after thorough testing

**Current known good state**: Commit `6b8682fc` (data display fix deployment)
