# 修复登录故障并全面增强后台系统 - 任务清单

## Phase 1: 紧急修复登录问题 (P0 - Critical)

### Task 1.1: 诊断登录失败根因
- [x] **1.1.1** 检查后端服务器运行状态和日志
  - 执行命令: `pm2 logs qiguan-backend --lines 50`
  - 查看是否有认证相关的错误信息
  - 检查数据库连接错误
  - **验证标准**: 确认服务器正常运行，无致命错误

- [x] **1.1.2** 测试数据库连接和用户表数据
  - 创建测试脚本连接MySQL数据库
  - 执行查询: `SELECT id, username, role, status FROM users LIMIT 10`
  - 验证管理员账户存在且状态为 'active'
  - 检查密码哈希是否正确存储
  - **验证标准**: 数据库可连接，管理员账户存在且有效

- [x] **1.1.3** 验证JWT配置和环境变量
  - 读取 `.env.production` 中的 `JWT_SECRET` 配置
  - 确认密钥长度 ≥ 32字符
  - 测试JWT token生成和验证流程
  - **验证标准**: JWT配置正确，token可正常生成和验证

- [x] **1.1.4** 测试登录API端点
  - 使用curl或Postman直接调用 `POST /api/v1/auth/login`
  - 发送测试凭据: `{"username": "admin", "password": "<known_password>"}`
  - 分析响应状态码和响应体
  - 对比期望响应格式与实际响应
  - **验证标准**: API返回200和有效的token，或明确的错误信息

- [x] **1.1.5** 检查CORS配置和前端请求链路
  - 确认前端域名在CORS允许列表中 (`https://qimengzhiyue.cn`)
  - 检查浏览器开发者工具Network标签页的请求/响应
  - 验证OPTIONS预检请求是否通过
  - 确认Authorization头正确传递
  - **验证标准**: 无CORS错误，请求正常到达后端

- [x] **1.1.6** 分析前端Login.vue组件行为
  - 在浏览器控制台查看登录请求详情
  - 检查axios拦截器的请求/响应处理
  - 验证localStorage token存储逻辑
  - 确认路由跳转是否触发
  - **验证标准**: 前端正确发送请求并处理响应

**Deliverable**: 《登录问题诊断报告》包含：
- ✅ 根因分析：**数据库字段名不匹配 (password vs password_hash) + 密码哈希格式错误 (SHA256 vs bcrypt)**
- 问题截图/日志证据：已记录在修复日志中
- 修复建议方案：兼容两种字段名 + 使用正确的bcrypt哈希
- 影响范围评估：仅影响登录功能，无其他模块受影响

---

### Task 1.2: 实施登录修复方案
- [x] **1.2.1** 根据诊断结果修复核心问题
  - **问题类型**: 认证逻辑问题 (数据库字段名不匹配 + 密码哈希格式错误)
  - ✅ 已修复routes/auth.js中的bug - 兼容password/password_hash字段
  - ✅ 调整bcrypt密码比对逻辑 - 增加防御性检查
  - ✅ 优化错误消息返回 - 提供更清晰的错误日志
  - ✅ 修复database/init_data.sql - 使用正确的bcrypt哈希值
  - **验证标准**: bcrypt.compare测试通过 ✅

- [x] **1.2.2** 增强登录错误提示友好性
  - ✅ 区分不同错误类型（网络错误、凭证错误、服务器错误、403禁用）
  - ✅ 为每种错误提供中文用户友好提示
  - ✅ 记录详细错误日志到控制台（包含时间戳和完整error对象）
  - **验证标准**: 用户能看到清晰的错误原因

- [ ] **1.2.3** 添加登录功能单元测试
  - 创建 `tests/test_login.js` 测试文件
  - 测试用例:
    - 正确凭据 → 返回200 + token
    - 错误密码 → 返回401 + 错误消息
    - 缺少字段 → 返回400 + 字段验证错误
    - 封禁账户 → 返回403 + 封禁提示
    - 空用户名 → 返回400 + 必填字段提示
  - **验证标准**: 所有测试用例通过

- [x] **1.2.4** 本地构建与功能验证
  - ✅ 执行 `npm run build` (前端修改后)
  - 构建结果: 2260 modules, built in 7.02s, exit code 0
  - ✅ bcrypt密码匹配测试通过 (admin123 → true)
  - **验证标准**: 本地环境构建成功

- [ ] **1.2.5** 部署到生产服务器
  - 提交代码变更到Git仓库
  - 推送到远程服务器
  - 服务器端执行 `git pull`
  - 重新构建前端 (如有改动)
  - 重启PM2服务: `pm2 restart all`
  - 清除Nginx缓存: `rm -rf /var/cache/nginx/*`
  - **验证标准**: 生产环境HTTP 200，无报错日志

- [ ] **1.2.6** 生产环境登录验收测试
  - 使用浏览器访问生产后台地址
  - 输入管理员凭据提交登录 (username: admin, password: admin123)
  - 验证跳转到Dashboard页面
  - 检查左侧菜单和各功能模块可访问
  - 测试退出登录再重新登录
  - **验证标准**: 生产环境登录成功率100%，用户体验流畅

**Deliverable**: 
- 修复后的代码文件列表及变更说明
- 生产部署确认报告
- 登录测试通过截图

---

## Phase 2: 全面系统审查与优化 (P1 - High)

### Task 2.1: 后端代码质量审计
- [ ] **2.1.1** 审查所有路由文件的错误处理
  - 检查文件: routes/*.js (auth, products, categories, orders, users, cart, content, search, health)
  - 验证每个路由都有try-catch块
  - 确认错误响应格式统一 (success:false + error对象)
  - 检查是否有未处理的Promise rejection
  - **验证标准**: 所有路由都有完善的错误处理，无裸露的异步操作

- [ ] **2.1.2** SQL注入安全检查
  - 审计所有SQL查询语句
  - 确认使用参数化查询 (? 占位符)
  - 检查是否有字符串拼接SQL的情况
  - 验证输入数据的类型和范围校验
  - **验证标准**: 零SQL注入风险点，所有查询使用参数绑定

- [ ] **2.1.3** 中间件安全性审查
  - 检查middleware/auth.js的token验证逻辑
  - 验证requireRole权限控制是否严格
  - 确认敏感接口都有认证保护
  - 检查optionalAuth的使用场景是否合理
  - **验证标准**: 无未授权访问风险，权限控制粒度合适

- [ ] **2.1.4** API响应格式一致性检查
  - 抽样检查10个API端点的响应结构
  - 统一成功响应格式: `{success:true, data:{...}}`
  - 统一错误响应格式: `{success:false, error:{code, message}}`
  - 分页响应格式: `{success:true, data:{list:[], pagination:{total, page, pageSize}}}`
  - **验证标准**: 100%符合统一响应规范

---

### Task 2.2: 服务器配置优化
- [ ] **2.2.1** Nginx配置审查与调优
  - 读取当前Nginx配置文件 (qiguan.conf.v2)
  - 检查以下项目:
    - 反向代理配置正确性 (proxy_pass指向后端端口)
    - 静态资源缓存策略合理性
    - Gzip压缩是否启用
    - 安全头设置 (X-Frame-Options, X-Content-Type-Options等)
    - 请求大小限制 (client_max_body_size)
    - 超时设置 (proxy_read_timeout等)
  - 如有问题则更新配置
  - **验证标准**: Nginx配置符合生产最佳实践

- [ ] **2.2.2** PM2进程管理优化
  - 检查ecosystem.config.js配置
  - 验证以下设置:
    - 实例数量 (建议 production: max 或 2)
    - 内存限制 (memory_limit)
    - 自动重启策略 (autorestart: true)
    - 日志配置 (合并日志、最大大小、保留数量)
  - 更新配置以提升稳定性和性能
  - **验证标准**: PM2配置支持高可用和自动恢复

- [ ] **2.2.3** 环境变量安全审计
  - 检查.env.production敏感信息:
    - DB_PASSWORD 是否为强密码
    - JWT_SECRET 是否足够长且随机
    - 是否有硬编码的密钥或密码
  - 验证.gitignore是否排除.env文件
  - 检查代码中是否有泄露环境变量的地方
  - **验证标准**: 无敏感信息泄露风险

- [ ] **2.2.4** 日志系统完善
  - 配置PM2日志轮转 (log_date_format, error_file, out_file)
  - 在关键业务逻辑添加结构化日志
  - 设置日志级别 (production: warn, development: debug)
  - 添加请求ID用于追踪
  - **验证标准**: 可通过日志快速定位问题和性能瓶颈

---

### Task 2.3: 数据库健康检查与优化
- [ ] **2.3.1** 表结构完整性验证
  - 连接MySQL数据库执行: `SHOW TABLES;`
  - 检查必需表是否存在:
    - users ✓
    - products ✓
    - categories ✓
    - orders ✓
    - order_items ✓
    - cart ✓
    - favorites ✓
    - footprints ✓
    - coupons ✓
    - user_addresses ✓
    - banners/homepage_content (如不存在需创建)
  - 对比database/mysql_init.sql确认结构一致
  - **验证标准**: 所有必需表存在且结构正确

- [ ] **2.3.2** 索引优化分析
  - 执行 `SHOW INDEX FROM <table>` 检查关键表的索引
  - 重点检查:
    - users(username), users(email) - 唯一索引
    - products(category_id, status) - 普通索引
    - orders(user_id, status, created_at) - 复合索引
    - cart(user_id, product_id) - 唯一复合索引
  - 使用EXPLAIN分析慢查询
  - 添加缺失的关键索引
  - **验证标准**: 关键查询使用索引，无全表扫描

- [ ] **2.3.3** 初始数据完整性检查
  - 验证管理员账户:
      ```sql
      SELECT * FROM users WHERE role = 'admin' LIMIT 5;
      ```
  - 检查分类数据是否存在:
      ```sql
      SELECT COUNT(*) FROM categories;
      ```
  - 检查商品数据:
      ```sql
      SELECT COUNT(*) FROM products WHERE status = 'active';
      ```
  - 如果关键数据缺失，从database/init_data.sql导入
  - **验证标准**: 系统有足够的初始数据进行演示和测试

- [ ] **2.3.4** 连接池配置优化
  - 当前配置: connectionLimit=10
  - 根据并发需求调整:
    - 低流量 (<100并发): 5-10
    - 中流量 (100-500): 10-20
    - 高流量 (>500): 20-50
  - 设置合理的超时时间:
    - acquireTimeout: 60000ms (获取连接超时)
    - connectTimeout: 60000ms (连接超时)
  - 启用连接保活: `keepAliveInitialDelay: 0`
  - **验证标准**: 连接池在高负载下稳定，无连接泄漏

---

## Phase 3: 核心功能拓展 (P2 - Medium)

### Task 3.1: 🛒 购物车管理系统

#### Backend Implementation:
- [ ] **3.1.1** 创建购物车管理API路由
  - 新建文件: `routes/cart_admin.js`
  - 实现接口:
    - `GET /api/v1/admin/carts` - 获取购物车列表（分页、筛选）
      - 支持筛选条件: userId, dateRange, itemCountRange, status
      - 返回字段: cart_id, user_info, product_count, total_price, updated_at
    - `GET /api/v1/admin/carts/stats` - 获取购物车统计数据
      - 总购物车数、总商品数、总金额、平均商品数
      - 按日期统计趋势（7天/30天）
      - 废弃购物车率（>7天未更新）
    - `DELETE /api/v1/admin/carts/:id` - 删除异常购物车
    - `DELETE /api/v1/admin/carts/expired` - 批量清理过期购物车（>30天未更新）
  - 权限要求: verifyToken + requireRole('admin')
  - **验证标准**: API可通过Postman/curl测试，返回正确数据

- [ ] **3.1.2** 注册路由到主应用
  - 在index.js的routes数组中添加:
    ```javascript
    { path: '/admin/carts', module: './routes/cart_admin', middleware: [verifyToken, requireRole('admin')] }
    ```
  - **验证标准**: 路由注册成功，访问不返回404

#### Frontend Implementation:
- [ ] **3.1.3** 创建购物车管理页面组件
  - 新建文件: `qiguanqianduan/src/views/CartAdmin.vue`
  - 页面功能:
    - 顶部统计卡片: 总购物车数 | 总商品数 | 总价值 | 废弃率
    - 数据表格 (el-table):
      - 列: 用户ID/昵称 | 商品数量 | 总金额 | 最后更新时间 | 操作(查看/删除)
      - 支持分页 (el-pagination)
      - 支持按用户、日期范围筛选
    - 操作按钮:
      - "清理过期购物车" - 弹窗确认后批量删除
      - "导出数据" - 导出CSV/Excel
    - 图表展示 (ECharts):
      - 购物车创建趋势折线图（近7天/30天）
      - 商品数量分布柱状图
  - UI风格: 与现有Products.vue、Orders.vue保持一致
  - **验证标准**: 页面渲染正常，数据加载正确，交互流畅

- [ ] **3.1.4** 添加路由和菜单入口
  - 在 `src/router/index.js` 添加路由:
    ```javascript
    {
      path: '/cart-admin',
      name: 'CartAdmin',
      component: () => import('@/views/CartAdmin.vue'),
      meta: { title: '购物车管理', requiresAuth: true }
    }
    ```
  - 在 `src/layout/Sidebar.vue` 添加菜单项:
    ```vue
    <el-menu-item index="/cart-admin">
      <i><Cart /></i>
      <span>购物车管理</span>
    </el-menu-item>
    ```
  - **验证标准**: 侧边栏显示菜单项，点击可导航到页面

---

### Task 3.2: 🎫 优惠券管理系统

#### Database Schema:
- [ ] **3.2.1** 创建优惠券相关数据表（如不存在）
  ```sql
  CREATE TABLE IF NOT EXISTS coupons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL COMMENT '优惠券名称',
    code VARCHAR(50) NOT NULL UNIQUE COMMENT '优惠码',
    type ENUM('fixed', 'percent') NOT NULL DEFAULT 'fixed' COMMENT '固定金额/百分比',
    value DECIMAL(10,2) NOT NULL COMMENT '优惠值',
    min_order_amount DECIMAL(10,2) DEFAULT 0 COMMENT '最低订单金额',
    max_discount DECIMAL(10,2) DEFAULT NULL COMMENT '最大折扣金额(仅percent类型)',
    stock INT NOT NULL DEFAULT 0 COMMENT '发放总量',
    per_user_limit INT DEFAULT 1 COMMENT '每人限领数量',
    used_count INT DEFAULT 0 COMMENT '已使用数量',
    start_time DATETIME NOT NULL COMMENT '开始时间',
    end_time DATETIME NOT NULL COMMENT '结束时间',
    status ENUM('active', 'inactive', 'expired') DEFAULT 'active' COMMENT '状态',
    description TEXT COMMENT '使用说明',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_code (code),
    INDEX idx_time (start_time, end_time)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优惠券表';

  CREATE TABLE IF NOT EXISTS user_coupons (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    coupon_id INT NOT NULL,
    status ENUM('unused', 'used', 'expired') DEFAULT 'unused',
    order_id INT DEFAULT NULL COMMENT '使用的订单ID',
    received_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    used_at TIMESTAMP DEFAULT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (coupon_id) REFERENCES coupons(id),
    UNIQUE KEY unique_user_coupon (user_id, coupon_id),
    INDEX idx_user_status (user_id, status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户优惠券关联表';
  ```
  - **验证标准**: 表创建成功，可插入测试数据

#### Backend Implementation:
- [ ] **3.2.2** 创建优惠券管理API
  - 新建文件: `routes/coupons.js`
  - 实现完整的CRUD接口:
    - `GET /api/v1/coupons` - 优惠券列表（分页、筛选）
      - 筛选: status, type, dateRange, keyword(name/code)
    - `POST /api/v1/coupons` - 创建优惠券
      - 校验: 必填字段、时间合理性、库存>0
    - `GET /api/v1/coupons/:id` - 优惠券详情
    - `PUT /api/v1/coupons/:id` - 更新优惠券
    - `DELETE /api/v1/coupons/:id` - 删除优惠券（软删除或标记inactive）
    - `GET /api/v1/coupons/:id/stats` - 使用统计
      - 已领取数、已使用数、使用率、领券用户列表
    - `GET /api/v1/coupons/stats/overview` - 全局统计
      - 总优惠券数、活跃数、今日领取/使用数
  - 权限: 管理接口需要admin角色
  - **验证标准**: CRUD操作完整可用，数据校验严格

#### Frontend Implementation:
- [ ] **3.2.3** 创建优惠券管理页面
  - 新建文件: `qiguanqianduan/src/views/Coupons.vue`
  - 功能模块:
    - **优惠券列表** (el-table):
      - 列: 名称 | 优惠码 | 类型 | 优惠值 | 库存/已用 | 有效期 | 状态 | 操作
      - 状态标签: active(绿色), inactive(灰色), expired(红色)
      - 操作: 编辑 | 查看 | 删除 | 统计
    - **新建/编辑弹窗** (el-dialog):
      - 表单字段: 名称、优惠码(自动生成)、类型(单选)、优惠值、最低消费、库存、每人限领、有效期(日期选择器)、说明
      - 表单验证: 必填、数值范围、时间逻辑
    - **统计面板**:
      - 顶部卡片: 总数 | 活跃 | 今日领取 | 今日使用
      - 使用率饼图/环形图
      - 领取趋势折线图
  - **验证标准**: 可完成优惠券的完整生命周期管理

- [ ] **3.2.4** 注册路由和菜单
  - 添加路由: `/coupons`
  - 添加侧边栏菜单: "优惠券管理"
  - **验证标准**: 导航正常，页面可访问

---

### Task 3.3: 📢 内容管理系统（CMS）

#### Database Enhancement:
- [ ] **3.3.1** 创建内容管理相关表
  ```sql
  CREATE TABLE IF NOT EXISTS banners (
    id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(200) COMMENT '标题',
    image_url VARCHAR(500) NOT NULL COMMENT '图片URL',
    link_url VARCHAR(500) COMMENT '点击跳转链接',
    link_type ENUM('product', 'category', 'url', 'none') DEFAULT 'none',
    position INT DEFAULT 0 COMMENT '排序位置(越小越前)',
    start_time DATETIME COMMENT '开始展示时间',
    end_time DATETIME COMMENT '结束展示时间',
    status ENUM('active', 'inactive') DEFAULT 'active',
    clicks INT DEFAULT 0 COMMENT '点击次数',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_position (position),
    INDEX idx_status (status)
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='首页轮播图表';

  CREATE TABLE IF NOT EXISTS homepage_config (
    id INT PRIMARY KEY AUTO_INCREMENT,
    config_key VARCHAR(100) NOT NULL UNIQUE COMMENT '配置键',
    config_value TEXT COMMENT '配置值(JSON)',
    description VARCHAR(500) COMMENT '配置说明',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='首页配置表';

  INSERT IGNORE INTO homepage_config (config_key, config_value, description) VALUES
  ('recommended_products', '[]', '推荐商品ID列表'),
  ('hot_products', '[]', '热门商品ID列表'),
  ('promotion_banner', '{}', '促销活动配置'),
  ('announcement', '', '公告内容');
  ```
  - **验证标准**: 表创建成功，初始配置数据已插入

#### Backend Implementation:
- [ ] **3.3.2** 增强内容管理API (基于现有routes/content.js)
  - Banner管理:
    - `GET /api/v1/content/banners` - 获取Banner列表
    - `POST /api/v1/content/banners` - 上传Banner图片+配置
    - `PUT /api/v1/content/banners/:id` - 更新Banner
    - `DELETE /api/v1/content/banners/:id` - 删除Banner
    - `PUT /api/v1/content/banners/reorder` - 调整顺序
  - 首页配置:
    - `GET /api/v1/content/homepage/config` - 获取所有配置
    - `PUT /api/v1/content/homepage/config` - 批量更新配置
    - `GET /api/v1/content/homepage/preview` - 预览效果
  - 文件上传集成:
    - 使用multer中间件处理图片上传
    - 存储路径: ./uploads/banners/
    - 返回可访问的URL
  - **验证标准**: API支持图片上传和配置管理

#### Frontend Implementation:
- [ ] **3.3.3** 创建内容管理页面
  - 新建文件: `qiguanqianduan/src/views/ContentManage.vue`
  - 子模块:
    - **Banner管理**:
      - 图片上传组件 (el-upload)
      - 拖拽排序 (vuedraggable或自定义)
      - 预览模式（模拟手机屏幕）
      - 启用/禁用开关
    - **推荐商品配置**:
      - 商品搜索选择器
      - 已选商品列表（可拖拽排序）
      - 保存配置
    - **热门商品配置**:
      - 同上
    - **公告编辑器**:
      - 富文本编辑器 (wangeditor/tinymce)
      - 实时保存草稿
      - 发布/撤回功能
  - **验证标准**: 可视化操作流畅，配置实时生效

- [ ] **3.3.4** 注册路由和菜单
  - 路由: `/content-manage`
  - 菜单: "内容管理" (可能需要子菜单: Banner/推荐/公告)
  - **验证标准**: 菜单项可见且可导航

---

### Task 3.4: 📊 增强版仪表盘

#### Backend Enhancement:
- [ ] **3.4.1** 扩展Dashboard统计数据API
  - 修改: `routes/dashboard.js`
  - 新增统计指标:
    ```json
    {
      "cartStats": {
        "totalCarts": 1250,
        "abandonedRate": "68.5%",
        "avgItemsPerCart": 3.2,
        "cartTrend": [...] // 近7天趋势
      },
      "favoriteStats": {
        "totalFavorites": 8900,
        "topFavoritedProducts": [...], // Top 10
        "favoriteTrend": [...]
      },
      "couponStats": {
        "activeCoupons": 12,
        "todayReceived": 156,
        "todayUsed": 89,
        "usageRate": "57.1%"
      },
      "recentOrders": [...], // 最近10条订单（含用户头像、商品缩略图）
      "userGrowth": {
        "newUsersToday": 23,
        "newUsersWeek": 145,
        "growthRate": "+12.5%"
      },
      "realtimeMetrics": {
        "onlineUsers": 34,
        "ordersLastHour": 8,
        "revenueToday": 15800.00
      }
    }
    ```
  - 优化查询性能: 使用缓存 (内存缓存/Redis)
  - **验证标准**: API响应时间<500ms，数据准确

#### Frontend Enhancement:
- [ ] **3.4.2** 升级Dashboard.vue组件
  - 新增统计卡片行 (el-row + el-col):
    - 购物车转化率 (68.5% ↓ vs 昨日)
    - 收藏总数 (8,900 ↑ 12%)
    - 活跃优惠券 (12张)
    - 在线用户 (34人)
  - 新增图表区域 (ECharts):
    - **收入趋势图** (双轴: 订单量+销售额, 近30天)
    - **商品收藏排行** (横向柱状图, Top 10)
    - **用户增长曲线** (面积图, 近7天/30天切换)
    - **订单状态分布** (环形图: 待付款/待发货/待收货/已完成/取消)
  - 新增实时动态区:
    - 最近订单列表 (自动滚动, 显示用户、商品、金额、时间)
    - 快捷操作按钮: "查看订单" "管理商品" "查看用户"
  - **验证标准**: 视觉美观，数据实时，交互流畅

---

## Phase 4: 高级功能拓展 (P3 - Low Priority)

### Task 4.1: ❤️ 收藏与足迹管理
- [ ] **4.1.1** 创建收藏管理API和页面
  - 后端: `routes/favorites_admin.js`
    - `GET /admin/favorites` - 收藏列表（支持按商品/用户筛选）
    - `GET /admin/favorites/stats` - 收藏统计分析
    - `DELETE /admin/favorites/:id` - 删除异常收藏
  - 前端: `Favorites.vue`
    - 热门收藏商品排行
    - 用户收藏行为分析
    - 收藏趋势图表
  - **验证标准**: 可查看和分析收藏数据

- [ ] **4.1.2** 创建足迹管理API和页面
  - 后端: `routes/footprints_admin.js`
    - `GET /admin/footprints` - 浏览足迹列表
    - `GET /admin/footprints/hot-pages` - 热门页面统计
    - `GET /admin/footprints/user-journey` - 用户行为路径分析
  - 前端: `Footprints.vue`
    - 页面访问热度地图
    - 用户活跃时段分析
    - 跳出率/停留时长统计
  - **验证标准**: 可追踪用户浏览行为

---

### Task 4.2: 📍 地址管理与物流配置
- [ ] **4.2.1** 地址管理功能
  - 后端: `routes/address_admin.js`
    - `GET /admin/addresses` - 用户地址库
    - 按地区统计分析
  - 前端: `AddressBook.vue`
    - 地址分布地图 (可选, 使用百度/高德地图API)
    - 区域销量热力图
  - **验证标准**: 可查看用户配送地址分布

- [ ] **4.2.2** 物流管理功能
  - 后端: `routes/logistics.js`
    - 物流公司CRUD
    - 运费模板管理 (按地区/重量阶梯定价)
    - 物流跟踪接口对接 (快递100/快递鸟)
  - 前端: `Logistics.vue`
    - 物流公司列表管理
    - 运费模板可视化配置
    - 物流成本报表
  - **验证标准**: 可配置物流选项和运费规则

---

### Task 4.3: 🔍 搜索与客服管理
- [ ] **4.3.1** 搜索关键词管理
  - 后端: `routes/search_admin.js`
    - `GET /admin/search/keywords` - 热门搜索词列表
    - `POST /admin/search/keywords` - 添加推荐搜索词
    - `PUT /admin/search/keywords/:id` - 编辑
    - `DELETE /admin/search/keywords/:id` - 删除
    - 黑名单管理 (屏蔽违规词)
  - 前端: `SearchManage.vue`
    - 关键词排行榜 (词频、搜索次数、转化率)
    - 推荐词配置
    - 敏感词过滤设置
  - **验证标准**: 可管理和优化搜索体验

- [ ] **4.3.2** 客服与售后工具
  - 后端: `routes/service_admin.js`
    - FAQ管理 (CRUD + 分类 + 排序)
    - 售后工单列表 (状态流转: 待处理→处理中→已完成→已关闭)
    - 工单详情和回复记录
  - 前端: `CustomerService.vue`
    - FAQ编辑器 (富文本)
    - 工单看板 (Kanban视图, 按状态分组)
    - 工单统计 (处理时长、满意度)
  - **验证标准**: 可管理客服知识和售后工单

---

## Phase 5: 系统优化与加固 (P4 - Future)

### Task 5.1: 性能优化
- [ ] **5.1.1** 数据库查询优化
  - 添加EXPLAIN分析慢查询日志
  - 优化复杂查询 (JOIN、子查询)
  - 添加适当的复合索引
  - 实施读写分离 (如适用)

- [ ] **5.1.2** API响应缓存
  - 实施Redis/内存缓存 (dashboard统计数据、热门商品等)
  - 设置合理的TTL (Time To Live)
  - 缓存失效策略 (写入时主动清除)

- [ ] **5.1.3** 前端性能优化
  - 路由懒加载 (已完成部分)
  - 组件级代码分割
  - 图片懒加载和压缩
  - CDN加速静态资源

---

### Task 5.2: 安全加固
- [ ] **5.2.1** 操作审计日志
  - 创建audit_logs表
  - 记录关键操作: 登录、增删改查、配置变更
  - 包含: 操作人、时间、IP、操作类型、前后数据
  - 审计日志查看界面 (只读, 不可删除)

- [ ] **5.2.2** 权限细化
  - 实现RBAC (Role-Based Access Control)
  - 角色: 超级管理员、运营、客服、财务
  - 菜单和按钮级别的权限控制
  - 数据权限 (只能查看自己负责的数据)

- [ ] **5.2.3** 数据脱敏
  - 手机号: 138****1234
  - 身份证: 110***********1234
  - 地址: 北京市朝阳区***路**号
  - 日志中不记录明文密码和token

---

### Task 5.3: 监控与告警
- [ ] **5.3.1** 应用监控
  - 集成Prometheus + Grafana (可选)
  - 或轻量级方案: 自定义metrics接口
  - 监控指标: QPS、响应时间、错误率、内存/CPU使用率

- [ ] **5.3.2** 告警通知
  - 关键阈值: 错误率>5%, 响应时间>2s, 内存>80%
  - 通知渠道: 企业微信/钉钉/邮件
  - 告警升级策略 (5min未处理→升级通知上级)

- [ ] **5.3.3** 备份策略
  - 数据库每日自动备份 (mysqldump)
  - 保留最近30天的备份
  - 备份完整性校验
  - 定期恢复演练 (可选)

---

## Task Dependencies

```
Phase 1 (紧急修复)
├─ Task 1.1: 诊断问题 ──────────────┐
│   (并行子任务 1.1.1~1.1.6)       │
└───────────────────────────────────┘
         ↓
├─ Task 1.2: 实施修复 ──────────────┐
   (依赖 1.1 的诊断结果)            │
   (串行: 1.2.1→1.2.2→...→1.2.6) │
└───────────────────────────────────┘
         ↓
Phase 2 (系统审查) ← 可与Phase 1部分并行
├─ Task 2.1: 代码审计
├─ Task 2.2: 服务器优化
└─ Task 2.3: 数据库优化
         ↓
Phase 3 (核心功能) ← 依赖 Phase 1+2 完成
├─ Task 3.1: 购物车管理 (独立)
├─ Task 3.2: 优惠券管理 (独立)
├─ Task 3.3: CMS内容管理 (独立)
└─ Task 3.4: 增强Dashboard (依赖3.1~3.3的数据)
         ↓
Phase 4 (高级功能) ← 可与Phase 3部分并行
├─ Task 4.1: 收藏/足迹
├─ Task 4.2: 地址/物流
└─ Task 4.3: 搜索/客服
         ↓
Phase 5 (优化加固) ← 最后执行
├─ Task 5.1: 性能优化
├─ Task 5.2: 安全加固
└─ Task 5.3: 监控告警
```

---

## Parallel Execution Opportunities

**高度并行 (可同时进行)**:
- ✅ Phase 1的所有诊断子任务 (1.1.1~1.1.6)
- ✅ Phase 2的三个任务 (2.1, 2.2, 2.3)
- ✅ Phase 3的前四个功能模块 (3.1, 3.2, 3.3, 3.4)
- ✅ Phase 4的三个功能组 (4.1, 4.2, 4.3)

**中度并行 (有少量依赖)**:
- ⚠️ Task 3.4 (增强Dashboard) 应在 3.1~3.3 之后，以便整合其数据
- ⚠️ Task 5.x (优化加固) 必须在所有功能完成后

**建议执行顺序**:
1. 先完成 Phase 1 (登录修复) - 最高优先级
2. 并行启动 Phase 2 (系统审查) 和 Phase 3 的准备工作
3. Phase 3 各模块可分配给不同的开发者并行实现
4. Phase 4 按需实施，优先级较低的功能可延后
5. Phase 5 在系统稳定后再考虑

---

## Estimated Effort

| Phase | Tasks | Complexity | Est. Time |
|-------|-------|------------|-----------|
| Phase 1: Login Fix | 2 tasks (12 subtasks) | High (diagnosis) | 2-4 hours |
| Phase 2: System Audit | 3 tasks (12 subtasks) | Medium | 3-5 hours |
| Phase 3: Core Features | 4 tasks (16 subtasks) | High | 8-16 hours |
| Phase 4: Advanced | 3 tasks (6 subtasks) | Medium-High | 6-12 hours |
| Phase 5: Optimization | 3 tasks (9 subtasks) | Medium | 4-8 hours |
| **Total** | **17 tasks (55 subtasks)** | - **| **23-45 hours** |

---

## Notes

### Critical Path:
**Phase 1 (Task 1.1 → 1.2)** 是整个项目的关键路径，必须最先完成。

### Risk Mitigation:
- 每个Phase完成后进行回归测试，确保不引入新问题
- 保持Git分支整洁，每个功能一个feature branch
- 定期备份生产数据库（每次重大变更前）

### Quality Gates:
- **Gate 1** (after Phase 1): 登录功能100%可用
- **Gate 2** (after Phase 2): 无已知的高危和中危问题
- **Gate 3** (after Phase 3): 至少4个新功能模块上线并可演示
- **Gate 4** (after Phase 4): 小程序90%以上的功能有对应的后台管理能力
- **Gate 5** (after Phase 5): 系统达到生产级质量标准

### Success Metrics:
- 登录成功率 > 99.9%
- API平均响应时间 < 300ms
- 系统可用性 > 99.5%
- 用户满意度 (NPS) > 7/10
