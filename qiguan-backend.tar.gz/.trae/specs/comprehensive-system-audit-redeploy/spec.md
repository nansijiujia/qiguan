# 绮管后台系统全面检查、修复与重新部署 Spec

## Why
当前后台系统虽然已能访问（HTTP 200），但仍需进行全面诊断以确保：
1. 所有功能模块正常运行（登录、仪表盘、CRUD操作等）
2. 前后端API通信无错误
3. 数据库连接稳定
4. 系统性能达标
5. 安全配置到位
若发现无法修复的严重问题，需执行完整的重新部署流程。

## What Changes
- **全面系统健康检查**：前端页面、后端API、数据库、Nginx配置、PM2进程状态
- **问题识别与分类**：功能性错误、性能瓶颈、配置缺陷、安全隐患
- **条件性重新部署**：仅在必要时执行环境清理+完整重部署
- **部署文档化**：生成可重复执行的标准化部署流程
- **功能验证测试**：覆盖所有核心业务场景

## Impact
- Affected specs: frontend-build-failure-fix (已完成), system-comprehensive-fix (历史)
- Affected code:
  - 整个 `绮管后台/` 项目（前端+后端）
  - 服务器环境 `/var/www/qiguan/`
  - Nginx 配置 `/etc/nginx/conf.d/qiguan.conf`
  - PM2 进程管理配置
  - MySQL/TDSQL-C 数据库连接

## ADDED Requirements

### Requirement: 系统健康全面诊断
系统 SHALL 对以下所有组件进行自动化或手动健康检查：

#### Scenario: 前端页面访问测试
- **WHEN** 用户访问 https://qimengzhiyue.cn/dashboard
- **THEN** 页面应在3秒内完全加载，无JavaScript错误
- **THEN** 所有静态资源（JS/CSS/图片）加载成功（HTTP 200/304）

#### Scenario: 后端API可用性测试
- **WHEN** 调用 /api/v1/health 健康检查接口
- **THEN** 返回 JSON 格式响应，包含 status, uptime, timestamp 字段
- **THEN** 响应时间 < 500ms

#### Scenario: 核心功能完整性验证
- **WHEN** 用户完成登录操作（admin/admin123）
- **THEN** 应成功跳转到仪表盘页面
- **THEN** 仪表盘应显示统计数据（商品数、订单数、营收、用户数）
- **THEN** 图表组件正常渲染（销售趋势图、热门商品TOP5）

### Requirement: 问题严重度评估与决策机制
系统 SHALL 根据诊断结果自动判断是否需要重新部署：

#### Scenario: 轻微问题（无需重部署）
- **IF** 仅存在非关键性的UI显示问题或性能优化空间
- **THEN** 记录问题并计划后续优化，不触发重部署

#### Scenario: 中等问题（可选重部署）
- **IF** 存在部分功能异常但系统仍可基本使用
- **THEN** 提供修复选项给用户决定是否重部署

#### Scenario: 严重问题（必须重部署）
- **IF** 出现以下任一情况：
  - 系统完全无法访问（502/503/504错误）
  - 数据库连接失败
  - 关键业务流程断裂（如无法登录）
  - 安全漏洞暴露
- **THEN** 自动触发完整的环境清理和重新部署流程

### Requirement: 标准化重新部署流程
当需要重新部署时，系统 SHALL 执行以下标准流程：

#### Step 1: 环境备份与清理
- 备份当前运行的配置和数据
- 停止所有相关服务（PM2, Nginx）
- 清理旧代码和构建产物（保留备份）

#### Step 2: 代码同步与依赖安装
- 从Git仓库拉取最新代码到指定分支（绮管）
- 安装后端依赖（npm install --production）
- 安装前端依赖并构建（cd qiguanqianduan && npm install && npm run build）

#### Step 3: 配置文件生成与验证
- 生成/更新 .env 生产环境配置
- 生成/更新 Nginx 配置文件
- 测试 Nginx 配置语法（nginx -t）

#### Step 4: 服务启动与健康检查
- 启动后端服务（pm2 start/restart）
- 重载 Nginx 配置
- 执行健康检查确认服务就绪

#### Step 5: 功能验证与监控
- 验证前端页面可访问
- 测试核心业务流程
- 检查日志无错误输出
- 设置监控告警（如有）

### Requirement: 部署过程完整文档化
系统 SHALL 生成详细的部署执行记录：

#### Scenario: 部署日志生成
- **WHEN** 执行任何部署操作
- **THEN** 记录每个步骤的开始时间、执行命令、输出结果、耗时
- **THEN** 记录遇到的问题及解决方案
- **THEN** 最终生成部署报告，包含：
  - 部署时间戳
  - Git提交哈希值
  - 环境信息（Node.js版本、Nginx版本等）
  - 部署结果（成功/失败）
  - 后续建议

## MODIFIED Requirements

### Requirement: Git 推送流程优化
原有的 Git 推送流程 SHALL 支持多分支策略：

#### Scenario: 分支推送适配
- **WHEN** 本地分支为 master 但需要推送到远程 绮管 分支
- **THEN** 使用 `git push origin master:绮管` 格式
- **THEN** 或先切换到本地 绮管 分支再推送
- **THEN** 文档中明确说明正确的推送命令格式

### Requirement: SSH认证方式说明
系统 SHALL 明确SSH连接的认证方式：

#### Scenario: 密码认证 vs 密钥认证
- **WHEN** 用户需要SSH连接服务器
- **THEN** 文档中提供两种方式的示例：
  - 密码方式：`ssh root@101.34.39.231` （交互式输入密码）
  - 密钥方式：`ssh -i ~/.ssh/id_rsa root@101.34.39.231` （免密登录）
- **THEN** 说明当前服务器支持的认证方式（根据截图：支持密码和公钥）

## REMOVED Requirements

### Requirement: CloudBase 静态托管依赖（已在之前任务中移除）
**Reason**: 已在 frontend-build-failure-fix 任务中完成删除和评估
**Status**: ✅ 已完成，cloudbaserc.json 已从前端目录移除
