# 绮管后台系统全面检查、修复与重新部署 - 验证检查清单

## 任务 1: 系统当前状态快照与健康检查
- [ ] 记录系统基本信息：
  - [ ] 服务器IP和操作系统版本：`uname -a`
  - [ ] Node.js版本：`node --version`（期望：v18.x+）
  - [ ] npm版本：`npm --version`
  - [ ] Nginx版本：`nginx -v`
  - [ ] PM2版本：`pm2 --version`
  - [ ] Git版本：`git --version`
- [ ] 前端可访问性验证：
  - [ ] `curl -I https://qimengzhiyue.cn/` 返回 HTTP 200 ✅ (已知)
  - [ ] `curl -I https://qimengzhiyue.cn/dashboard` 返回 HTTP 200 ✅ (已知)
  - [ ] 页面内容长度 > 0（非空页面）
- [ ] 后端API健康检查：
  - [ ] `curl http://localhost:3000/api/v1/health` 返回 JSON 响应
  - [ ] 响应包含 status 字段且值为 "ok"
  - [ ] 响应时间 < 1000ms
- [ ] PM2进程状态检查：
  - [ ] `pm2 list` 显示 qiguan-backend 进程存在
  - [ ] 进程状态为 online（非 errored/stopped）
  - [ ] 进程重启次数 < 10（非频繁重启）
  - [ ] 内存使用 < 500MB（正常范围）
- [ ] Nginx服务状态检查：
  - [ ] `systemctl status nginx` 显示 active (running)
  - [ ] `sudo nginx -t` 配置语法正确
  - [ ] 监听端口：80（HTTP）和 443（HTTPS）正常
- [ ] 数据库连接检查：
  - [ ] 可成功连接到 MySQL 10.0.0.16:3306
  - [ ] 数据库 qmzyxcx 存在且可访问
  - [ ] 核心表存在：products, categories, users, orders 等
- [ ] 关键日志收集：
  - [ ] PM2最近50行日志无严重错误：`pm2 logs --lines 50 --err`
  - [ ] Nginx错误日志最近20行无新错误：`tail -20 /var/log/nginx/error.log`
  - [ ] 系统日志无异常：`journalctl -u nginx --since "1 hour ago" | grep -i error`

## 任务 2: 前端功能完整性测试
- [ ] 登录页面测试：
  - [ ] 访问 /login 或根路径自动重定向到登录页
  - [ ] 用户名和密码输入框正常显示
  - [ ] 登录按钮可点击
  - [ ] 输入 admin/admin123 后可成功登录
  - [ ] 登录后跳转到仪表盘页面
- [ ] 仪表盘页面测试：
  - [ ] 统计卡片显示（总商品数、订单数、营收、用户数）
  - [ ] 销售趋势图表渲染正常（ECharts）
  - [ ] 热门商品TOP5图表显示
  - [ ] 最近订单表格数据加载
  - [ ] 时间筛选按钮可交互（7天/30天/90天）
- [ ] 商品管理页面测试：
  - [ ] 页面加载成功，商品列表显示
  - [ ] 搜索功能可用
  - [ ] 新增商品弹窗可打开
  - [ ] 编辑和删除按钮可见
- [ ] 分类管理页面测试：
  - [ ] 分类树形结构展示正确
  - [ ] 添加/编辑分类功能正常
- [ ] 用户管理页面测试：
  - [ ] 用户列表加载
  - [ ] 用户状态切换（启用/禁用）
- [ ] 订单管理页面测试：
  - [ ] 订单列表展示
  - [ ] 订单详情查看
  - [ ] 状态筛选功能
- [ ] 导航和路由测试：
  - [ ] 侧边栏菜单可点击切换
  - [ ] 面包屑导航显示正确
  - [ ] 浏览器前进/后退按钮正常工作
  - [ ] 刷新页面后保持当前路由状态
- [ ] 浏览器控制台检查：
  - [ ] 无 JavaScript 错误（红色信息）
  - [ ] 无未捕获的 Promise rejection
  - [ ] 无资源加载失败（404/500）

## 任务 3: 后端API全面测试
- [ ] 健康检查 API：
  - [ ] GET /api/v1/health → 200 OK + JSON body
  - [ ] 响应包含 status, uptime, timestamp 字段
- [ ] 用户认证 API：
  - [ ] POST /api/v1/auth/login → 成功返回 token（使用正确的账号密码）
  - [ ] POST /api/v1/auth/login → 失败返回 401（使用错误的密码）
  - [ ] POST /api/v1/auth/register → 成功创建用户（如开启注册）
- [ ] 仪表盘 API：
  - [ ] GET /api/v1/dashboard/overview → 返回统计数据
  - [ ] 数据结构包含 totalProducts, totalOrders, totalRevenue, totalUsers
- [ ] 商品管理 API：
  - [ ] GET /api/v1/products → 返回商品列表（分页）
  - [ ] GET /api/v1/products/:id → 返回单个商品详情
  - [ ] POST /api/v1/products → 创建商品成功（需认证token）
  - [ ] PUT /api/v1/products/:id → 更新商品成功
  - [ ] DELETE /api/v1/products/:id → 删除商品成功（软删除）
- [ ] 分类管理 API：
  - [ ] GET /api/v1/categories → 返回分类树
  - [ ] POST /api/v1/categories → 创建分类成功
  - [ ] PUT /api/v1/categories/:id → 更新分类成功
  - [ ] DELETE /api/v1/categories/:id → 删除分类成功
- [ ] 用户管理 API：
  - [ ] GET /api/v1/users → 返回用户列表
  - [ ] PUT /api/v1/users/:id/status → 更新用户状态成功
- [ ] 订单管理 API：
  - [ ] GET /api/v1/orders → 返回订单列表
  - [ ] GET /api/v1/orders/:id → 返回订单详情
- [ ] 错误处理验证：
  - [ ] 未认证访问受保护接口 → 401 Unauthorized
  - [ ] 访问不存在的资源 → 404 Not Found
  - [ ] 参数验证失败 → 400 Bad Request + 错误详情
  - [ ] 服务器内部错误 → 500 Internal Server Error（如有，检查日志）
- [ ] 性能基准测试：
  - [ ] 简单查询响应时间 < 100ms
  - [ ] 列表查询响应时间 < 500ms
  - [ ] 并发请求处理稳定（10并发无错误）

## 任务 4: 数据库连接与操作验证
- [ ] 连接基本测试：
  - [ ] 使用 mysql 命令或 Node.js 脚本成功连接
  - [ ] 连接参数正确：host=10.0.0.16, port=3306, user=QMZYXCX
  - [ ] 选择数据库 qmzyxcx 成功
- [ ] 表结构完整性：
  - [ ] products 表存在且有正确的字段
  - [ ] categories 表存在且有正确的字段
  - [ ] users 表存在且有正确的字段（含密码哈希字段）
  - [ ] orders 表存在且有正确的字段
  - [ ] order_items 表存在（如有）
  - [ ] 其他必要的关联表存在
- [ ] 数据操作测试：
  - [ ] SELECT 查询：能读取现有数据（如 SELECT COUNT(*) FROM products）
  - [ ] INSERT 插入：能插入新记录（测试表或实际业务表）
  - [ ] UPDATE 更新：能修改记录
  - [ ] DELETE 删除：能删除记录（注意使用软删除或测试数据）
- [ ] 连接池配置：
  - [ ] 连接池最大连接数 >= 5
  - [ ] 连接超时设置合理（> 5000ms）
  - [ ] 空闲连接回收机制正常
- [ ] 数据完整性和一致性：
  - [ ] 外键关系正确建立（如有）
  - [ ] 索引存在于关键字段（id, status, created_at等）
  - [ ] 字符集为 utf8mb4（支持完整Unicode）
  - [ ] 时区设置正确（+08:00 或 Asia/Shanghai）

## 任务 5: 性能与安全审计
### 性能指标
- [ ] **前端性能**：
  - [ ] 首次内容绘制(FCP) < 1.5s
  - [ ] 最大内容绘制(LCP) < 2.5s
  - [ ] 首次输入延迟(FID) < 100ms
  - [ ] 累积布局偏移(CLS) < 0.1
  - [ ] 总页面加载时间 < 3s（在服务器本地测试）
- [ ] **后端性能**：
  - [ ] API平均响应时间 < 300ms
  - [ ] API P95响应时间 < 800ms
  - [ ] API P99响应时间 < 1500ms
  - [ ] 数据库查询平均时间 < 50ms
- [ ] **资源优化**：
  - [ ] JS文件已压缩（gzip后 < 原始大小的30%）
  - [ ] CSS文件已压缩
  - [ ] 图片已优化（使用适当格式和尺寸）
  - [ ] 启用了浏览器缓存（Cache-Control头）
  - [ ] 启用了Gzip压缩（Content-Encoding: gzip）
- [ ] **服务端资源**：
  - [ ] PM2进程内存使用 < 512MB
  - [ ] PM2进程CPU使用率 < 80%（空闲时 < 10%）
  - [ ] 系统负载（load average）< CPU核心数 * 2
  - [ ] 磁盘使用率 < 90%
  - [ ] 可用内存 > 512MB

### 安全检查项
- [ ] **传输安全**：
  - [ ] HTTPS 已启用且强制跳转（HTTP→HTTPS）
  - [ ] SSL/TLS证书有效且未过期
  - [ ] 协议版本 >= TLSv1.2（推荐TLSv1.3）
  - [ ] 弱密码套件已禁用
- [ ] **认证与授权**：
  - [ ] JWT密钥强度足够（>= 32字符）
  - [ ] Token过期时间合理（建议24h内）
  - [ ] 密码存储使用bcrypt/scrypt/argon2（非明文或MD5）
  - [ ] 登录失败有次数限制（防暴力破解）
  - [ ] 敏感操作需要二次确认或权限验证
- [ ] **输入验证**：
  - [ ] SQL注入防护（参数化查询）
  - [ ] XSS防护（输出转义、CSP策略）
  - [ ] CSRF保护（Token验证）
  - [ ] 文件上传类型白名单
  - [ ] 文件上传大小限制
  - [ ] 输入长度限制
- [ ] **安全头设置**：
  - [ ] X-Frame-Options: DENY 或 SAMEORIGIN
  - [ ] X-Content-Type-Options: nosniff
  - [ ] X-XSS-Protection: 1; mode=block
  - [ ] Strict-Transport-Security: max-age=31536000; includeSubDomains
  - [ ] Content-Security-Policy 策略（可选但推荐）
  - [ ] Referrer-Policy: strict-origin-when-cross-origin
- [ ] **敏感信息保护**：
  - [ ] .env 文件不在Git仓库中（.gitignore包含）
  - [ ] 无硬编码的密码或密钥在代码中
  - [ ] 错误消息不泄露堆栈信息（生产环境）
  - [ ] 日志不记录敏感信息（密码、token等）
- [ ] **其他安全措施**：
  - [ ] Rate limiting（API速率限制）已启用
  - [ ] CORS配置严格（不使用 * 通配符，指定允许的域名）
  - [ ] 管理后台需要认证才能访问
  - [ ] 定期备份机制（数据库和重要文件）

## 任务 6: 问题汇总与严重度评估
- [ ] **问题清单生成**：
  - [ ] 所有发现的问题已记录并编号
  - [ ] 每个问题都有清晰的描述和复现步骤
  - [ ] 问题已按类别分组（功能性/性能/安全/配置）
- [ ] **严重度分级**：
  - [ ] 🔴 严重问题（Critical）已识别并列出
    - [ ] 每个严重问题的影响范围分析完成
    - [ ] 修复紧急程度评估完成
  - [ ] 🟠 主要问题（Major）已识别并列出
  - [ ] 🟡 次要问题（Minor）已识别并列出
  - [ ] 🔵 建议改进（Suggestion）已识别并列出
- [ ] **决策依据准备**：
  - [ ] 当前系统的可用性评估（百分比）
  - [ ] 用户体验影响分析
  - [ ] 业务风险等级评定
  - [ ] 修复成本 vs 重部署成本对比
- [ ] **决策文档**：
  - [ ] 生成了明确的决策建议（选项A/B/C）
  - [ ] 决策理由充分且有数据支持
  - [ ] 提供了各选项的风险和收益分析
  - [ ] 推荐方案明确标注

## 任务 7: 条件性重新部署执行（如果需要）
### Step 7.1: 环境备份
- [ ] 创建备份目录：`/var/www/backups/pre-redeploy_YYYYMMDD_HHMMSS/`
- [ ] 备份 .env 文件到备份目录
- [ ] 备份 Nginx 配置文件到备份目录
- [ ] 备份 PM2 配置到备份目录
- [ ] （可选）备份数据库：mysqldump > backup.sql
- [ ] （可选）备份 uploads 目录
- [ ] 生成备份清单文件（列出所有备份内容和位置）
- [ ] 验证备份文件完整性（大小 > 0）

### Step 7.2: 服务停止与环境清理
- [ ] PM2 进程已停止：`pm2 stop all` 或 `pm2 delete all`
- [ ] Nginx 服务已停止：`sudo systemctl stop nginx`
- [ ] 旧构建产物已清理：`rm -rf qiguanqianduan/dist`
- [ ] Vite 缓存已清理：`rm -rf qiguanqianduan/node_modules/.vite`
- [ ] （可选）旧日志已归档或清理
- [ ] 验证关键文件未被误删（index.js, package.json等）

### Step 7.3: 代码同步与依赖安装
- [ ] Git 远程分支信息已更新：`git fetch origin`
- [ ] 代码已拉取到最新版本：`git reset --hard origin/绮管` 或 `git pull`
- [ ] 当前 Git 提交哈希已记录：`git rev-parse HEAD`
- [ ] 后端依赖安装成功：`npm install --production` 无 error
- [ ] 进入前端目录：`cd qiguanqianduan`
- [ ] 前端依赖安装成功：`npm install` 无 error
- [ ] **前端构建成功**：`npm run build` 退出码为 0 ⭐ 关键！
- [ ] 构建产物已生成：`ls dist/index.html` 存在且大小 > 0
- [ ] 构建日志显示：✓ XXX modules transformed., ✓ built in XX.XXs.

### Step 7.4: 配置文件生成与验证
- [ ] .env 生产环境配置已创建/更新：
  - [ ] DB_HOST, DB_PORT, DB_USER, DB_PASSWORD, DB_NAME 正确
  - [ ] JWT_SECRET 强度足够（>= 32字符）
  - [ ] NODE_ENV=production
  - [ ] PORT=3000
- [ ] Nginx 配置文件已创建/更新（/etc/nginx/conf.d/qiguan.conf）：
  - [ ] 监听 80 和 443 端口
  - [ ] SSL证书路径正确
  - [ ] /api/ location 正确代理到 localhost:3000
  - [ ] proxy_set_header 配置标准
  - [ ] 静态文件 root 指向 qiguanqianduan/dist
  - [ ] try_files 配置正确（支持 Vue Router history模式）
- [ ] **Nginx 配置测试通过**：`sudo nginx -t` 输出 syntax is ok ⭐ 关键！
- [ ] （可选）PM2 ecosystem.config.js 已验证

### Step 7.5: 服务启动与健康检查
- [ ] 后端服务启动：`pm2 start index.js --name qiguan-backend` 或 `pm2 restart`
- [ ] PM2 进程保存：`pm2 save`
- [ ] 等待 5 秒让服务初始化
- [ ] Nginx 服务启动：`sudo systemctl start nginx`
- [ ] PM2 进程状态检查：
  - [ ] `pm2 list` 显示 qiguan-backend 状态为 online
  - [ ] `pm2 logs --lines 20` 无启动错误
- [ ] 本地健康检查：
  - [ ] `curl http://localhost:3000/api/v1/health` 返回 200 OK
- [ ] 外部访问检查：
  - [ ] `curl -I https://qimengzhiyue.cn/dashboard` 返回 HTTP 200
  - [ ] `curl -I https://qimengzhiyue.cn/` 返回 HTTP 200（可能301重定向到HTTPS）

### Step 7.6: 功能回归验证（简化版）
- [ ] 浏览器访问 dashboard 页面正常显示
- [ ] 登录功能可用（admin/admin123）
- [ ] 仪表盘统计数据加载（非全0或undefined）
- [ ] 至少一个 CRUD 操作正常（如查看商品列表）
- [ ] 无明显的 JavaScript 错误
- [ ] 无 API 404/500 错误（Network面板检查）

## 任务 8: 部署文档生成与知识沉淀
- [ ] **部署执行报告**：
  - [ ] 包含完整的执行时间线
  - [ ] 记录每个步骤的操作命令和输出
  - [ ] 记录遇到的问题及解决方案
  - [ ] 最终结果明确（成功/部分成功/失败）
  - [ ] 包含系统最终状态快照
- [ ] **标准化部署文档**：
  - [ ] 快速部署指南（一页纸，核心步骤）
  - [ ] 详细部署手册（包含解释和故障排查）
  - [ ] 首次部署特殊说明（环境初始化）
  - [ ] 命令示例可直接复制粘贴
- [ ] **运维补充章节**：
  - [ ] 日常监控命令速查表
  - [ ] 常见问题FAQ（基于本次诊断发现的问题）
  - [ ] 日志查看和分析方法说明
  - [ ] 性能调优建议清单
  - [ ] 安全加固检查表
- [ ] **回滚方案文档**：
  - [ ] 快速回滚步骤（<5分钟恢复）
  - [ ] 回滚到特定Git版本的命令
  - [ ] 数据库回滚注意事项
  - [ ] 回滚验证检查项
- [ ] **经验教训总结**：
  - [ ] 本次诊断发现的主要问题清单
  - [ ] 问题的根本原因分析
  - [ ] 预防措施和建议
  - [ ] 团队协作改进建议（如适用）
  - [ ] 后续优化方向建议

---

## 📊 总体进度追踪

| 任务 | 状态 | 优先级 | 通过项 | 总项 | 通过率 |
|------|------|--------|--------|------|--------|
| 1. 系统快照 | ⏳ 待执行 | P0 | 0 | ~35 | 0% |
| 2. 前端测试 | ⏳ 待执行 | P0 | 0 | ~25 | 0% |
| 3. 后端API测试 | ⏳ 待执行 | P0 | 0 | ~30 | 0% |
| 4. 数据库验证 | ⏳ 待执行 | P0 | 0 | ~20 | 0% |
| 5. 性能安全审计 | ⏳ 待执行 | P1 | 0 | ~45 | 0% |
| 6. 问题评估决策 | ⏳ 待执行 | P0 | 0 | ~15 | 0% |
| 7. 条件性重部署 | ⏳ 待执行 | P0* | 0 | ~35 | 0% |
| 8. 文档生成 | ⏳ 待执行 | P1 | 0 | ~20 | 0% |
| **总计** | | | **0** | **~225** | **0%** |

*任务7为条件性执行，取决于任务6的决策结果

---

## 🎯 里程碑节点

- **里程碑 1**：诊断阶段完成（任务1-5）→ 进入决策阶段
- **里程碑 2**：决策确定（任务6）→ 明确后续行动方向
- **里程碑 3**：部署完成（任务7，如执行）→ 系统重新上线
- **里程碑 4**：全部完成（任务8）→ 交付完整文档和报告

---

## ⚠️ 关键注意事项

1. **SSH访问权限**：确保拥有服务器的root或sudo权限
2. **数据安全**：任何删除或修改操作前务必备份
3. **服务中断**：重部署过程会导致短暂的服务不可用（预计5-10分钟）
4. **回滚准备**：始终准备好回滚方案以防部署失败
5. **监控告警**：部署完成后密切监控系统状态至少30分钟
6. **通知相关方**：如影响用户，提前通知维护窗口时间
