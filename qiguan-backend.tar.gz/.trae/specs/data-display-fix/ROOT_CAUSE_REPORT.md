# 🔍 根因诊断报告 (ROOT_CAUSE_REPORT)

**项目名称**: 绮管后台（Qiguan Admin System）
**报告日期**: 2026-04-09 11:52 (UTC+8)
**诊断人**: AI Assistant (Trae IDE)
**Spec版本**: data-display-fix

---

## 📋 执行摘要

### 核心发现
**根本原因**: 方案B安全加固中更换JWT密钥导致所有旧Token失效，前端未正确处理401错误导致数据显示为空。

### 影响范围
- **受影响页面**: Products(商品管理)、Categories(分类管理)、Users(用户管理)、Orders(订单管理)、Dashboard(仪表盘)
- **不受影响页面**: Login(登录页)、Health Check(健康检查)
- **影响程度**: 中等（需用户重新登录，无数据丢失）

### 解决方案优先级
- **P0 (立即)**: 引导用户清除浏览器缓存/重新登录
- **P0 (代码)**: 优化前端401错误处理，自动跳转登录页
- **P1 (短期)**: 添加种子数据初始化脚本（防止数据库为空）

---

## 🔬 详细诊断过程

### Phase 1: API端点测试

#### Test 1.1: 无Token直接访问后端
```bash
curl http://127.0.0.1:3000/api/v1/products
```
**结果**:
```json
{
  "status": 401,
  "body": {
    "success": false,
    "error": {
      "code": "UNAUTHORIZED",
      "message": "Invalid or missing authentication token"
    }
  }
}
```
**结论**: ✅ 认证中间件正常工作，正确拒绝未授权请求

#### Test 1.2: 通过Nginx代理访问
```bash
curl https://qimengzhiyue.cn/api/v1/products
```
**结果**: 同样返回401
**结论**: ✅ Nginx代理配置正确，不修改状态码

#### Test 1.3: 登录API测试
```javascript
// Node.js HTTP客户端发送POST请求
{
  username: 'admin',
  password: 'admin123'
}
```
**结果**:
```json
{
  "status": 200,
  "body": {
    "success": true,
    "data": {
      "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
      "user": {
        "id": 1,
        "username": "admin",
        "email": "admin@qiguan.com",
        "role": "admin",
        "avatar": null
      }
    }
  }
}
```
**结论**: ✅ 登录功能正常，成功签发新JWT Token

#### Test 1.4: 使用新Token访问受保护API
```javascript
// 使用Test 1.3获得的Token
Authorization: Bearer eyJhbGciOiJIUzI1NiIs...
```

**Products API** (`GET /api/v1/products`):
```json
{
  "status": 200,
  "body": {
    "success": true,
    "data": {
      "list": [
        {"id": 6, "name": "123", "price": 0.04, ...},
        {"id": 1, "name": "智能手机 Pro Max", "price": 6999, ...},
        // ... 共6条记录
      ],
      "pagination": { "total": 6, ... }
    }
  }
}
```

**Categories API** (`GET /api/v1/categories`):
```json
{
  "status": 200,
  "body": {
    "success": true,
    "data": {
      "list": [
        {"id": 1, "name": "电子产品", ...},
        {"id": 2, "name": "服装鞋帽", ...},
        // ... 共10个分类
      ]
    }
  }
}
```
**结论**: ✅ **数据库有数据！API完全正常！**

---

### Phase 2: 前端代码分析

#### 2.1 axios拦截器检查
**文件**: `qiguanqianduan/src/utils/request.js`

**当前行为**:
```javascript
// response拦截器
if (response.data.success === false) {
  const errorMsg = response.data.error?.message || response.data.error || '未知错误'
  ElMessage.error(errorMsg)  // ← 仅显示错误消息
}
```

**问题**:
- ❌ 未区分401和其他错误类型
- ❌ 401时不清除localStorage中的旧Token
- ❌ 401时不自动跳转到/login页面
- ❌ 导致用户看到"获取商品列表失败"但不知道原因

#### 2.2 Products.vue fetchData逻辑
**文件**: `qiguanqianduan/src/views/Products.vue` (L242-259)

```javascript
const fetchData = async () => {
  loading.value = true
  try {
    const res = await productApi.getProducts(params)
    if (res.data?.data) {
      tableData.value = res.data.data.list || []
      pagination.total = res.data.data.pagination?.total || 0
    }
  } catch (error) {
    ElMessage.error('获取商品列表失败')  // ← 401时会触发此错误提示
  } finally {
    loading.value = false
  }
}
```

**问题链路**:
```
axios.get('/api/v1/products') 
→ 后端返回401 + {success:false, error:{message:"Invalid or missing..."}}
→ request.js拦截器: ElMessage.error("Invalid or missing...")
→ 抛出异常（因为success===false）
→ Products.vue catch: ElMessage.error("获取商品列表失败")
→ tableData保持空数组[]
→ 页面显示 "No Data, Total: 0"
```

#### 2.3 Login.vue 登录逻辑
**文件**: `qiguanqianduan/src/views/Login.vue` (L62-75)

```javascript
const handleLogin = async () => {
  try {
    const res = await authApi.login(form)  // POST /api/v1/auth/login
    
    if (res.data?.token) {
      localStorage.setItem('token', res.data.token)
      localStorage.setItem('user', JSON.stringify(res.data.user))
      
      ElMessage.success('登录成功')
      router.push('/dashboard')  // 跳转到仪表盘
    }
  } catch (error) {
    ElMessage.error(error.response?.data?.error?.message || '登录失败')
  }
}
```

**当前状态**: 
- ✅ 登录逻辑本身正确（已在服务器验证成功）
- ⚠️ 但如果用户不主动重新登录，旧Token会一直存在localStorage中

---

### Phase 3: 数据库状态检查

#### 3.1 连接状态
- **主机**: 10.0.0.16:3306 (TDSQL-C MySQL兼容实例)
- **数据库**: qmzyxcx
- **连接方式**: 连接池 (mysql2/promise)
- **状态**: ✅ 正常（PM2日志无连接错误）

#### 3.2 数据表统计
| 表名 | 记录数 | 最后更新时间 |
|------|--------|--------------|
| **products** | **6条** | 2026-04-09 11:37:52 |
| **categories** | **10个** | 2026-04-09 11:38:13 |
| **users** | 至少1个(admin) | - |
| orders | 待确认 | - |

**关键发现**: 
- ✅ 数据库**不为空**！已有用户添加的商品和分类数据
- ✅ CRUD操作正常（用户之前可以正常添加数据）
- ⚠️ 如果全新部署，可能没有初始数据（需要种子数据脚本）

---

### Phase 4: JWT Token有效性验证

#### 4.1 密钥对比
| 项目 | 旧值 (方案B前) | 新值 (方案B后) |
|------|---------------|---------------|
| JWT_SECRET | `qiguan-production-secret-key-2026-change-me` | `dy/QDLXKFdtuUdPI8Z4/w2fOrL/dIMvEGGzOvRlpk+fMIkLow849X2m2lx3mxygvWMYnJFt2qZ9EfCpxPGmxrA==` |
| 强度 | 弱 (可预测) | 强 (64字节随机) |

#### 4.2 Token验证测试
- **旧Token格式**: `eyJhbGciOiJIUzI1NiIs...` (用旧密钥签名)
- **新Token格式**: `eyJhbGciOiJIUzI1NiIs...` (用新密钥签名)

**测试结果**:
- ❌ 旧Token → verifyToken() 失败 → 返回401
- ✅ 新Token → verifyToken() 成功 → 解码出userId, username, role
- ✅ 新Token可正常访问所有受保护API

---

## 🎯 根因确认

### 主要原因 (Primary Cause): **JWT密钥轮换导致的Token失效**

**时间线**:
```
T=0  用户登录系统 → 获得Token_A (用旧密钥签署) → 存储到localStorage
T+1h 方案B实施 → 更换JWT_SECRET → 重启PM2服务
T+2h 用户刷新页面 → 前端使用Token_A请求API
T+2h 后端用新密钥验证Token_A → 失败 → 返回401
T+2h 前端收到401 → 显示错误 → 数据为空
```

### 次要原因 (Secondary Causes):

1. **前端401处理不完善**
   - 未自动清除无效Token
   - 未强制跳转登录页
   - 错误提示不够明确（应提示"请重新登录"而非"获取失败"）

2. **用户无感知**
   - 没有任何UI提示告知用户Token已过期
   - 用户误以为系统故障或数据丢失

3. **浏览器缓存**
   - 可能缓存了旧的静态资源（dist文件）
   - localStorage中的旧数据未被清理

---

## 📊 影响评估

### 功能影响矩阵

| 功能模块 | 受影响？ | 严重程度 | 恢复方法 |
|----------|---------|---------|----------|
| **登录页** | ❌ 不受影响 | - | 正常使用 |
| **商品列表** | ✅ 受影响 | 高 | 重新登录 |
| **分类列表** | ✅ 受影响 | 高 | 重新登录 |
| **用户管理** | ✅ 受影响 | 高 | 重新登录 |
| **订单管理** | ✅ 受影响 | 高 | 重新登录 |
| **仪表盘** | ✅ 受影响 | 高 | 重新登录 |
| **搜索功能** | ✅ 受影响 | 中 | 重新登录 |
| **购物车** | ✅ 受影响 | 中 | 重新登录 |
| **健康检查** | ❌ 不受影响 | - | 正常使用 |

### 数据完整性评估
- ✅ **无数据丢失** - 所有数据仍保存在数据库中
- ✅ **无结构损坏** - 数据库表结构完整
- ✅ **可完全恢复** - 重新登录即可访问所有数据

---

## 💡 修复建议

### 方案A: 紧急修复（立即执行，5分钟）

#### A.1 前端401处理增强
**文件**: `qiguanqianduan/src/utils/request.js`

```javascript
// 在response拦截器中添加：
if (response.status === 401 || 
    (response.data && response.data.error?.code === 'UNAUTHORIZED')) {
  
  // 清除无效凭证
  localStorage.removeItem('token')
  localStorage.removeItem('user')
  
  // 提示用户
  ElMessage.warning('登录已过期，请重新登录')
  
  // 延迟跳转（让用户看到提示）
  setTimeout(() => {
    window.location.href = '/login'  // 或 router.push('/login')
  }, 1500)
  
  return Promise.reject(new Error('Unauthorized'))
}
```

#### A.2 引导用户重新登录
在所有页面顶部添加检测：
```javascript
// App.vue 或路由守卫
if (!localStorage.getItem('token')) {
  router.push('/login')
}
```

### 方案B: 完整修复（推荐，30分钟）

#### B.1 axios拦截器全面升级
- 区分401/403/404/500等不同错误
- 401: 清除Token → 跳转登录
- 403: 显示"权限不足"
- 404: 显示"请求不存在"
- 500: 显示"服务器错误，请联系管理员"

#### B.2 登录页增强
- 自动检测并提示"您的会话已过期"
- 支持"记住我"选项（延长Token有效期）
- 登录成功后重定向回原页面

#### B.3 种子数据脚本（防患未然）
创建 `scripts/init_seed_data.sql`：
```sql
-- 确保至少有一个admin账号
INSERT IGNORE INTO users (username, email, password, role, status) 
VALUES ('admin', 'admin@qimengzhiyue.cn', '$2a$10$...', 'admin', 'active');

-- 示例分类
INSERT IGNORE INTO categories (name, description) VALUES
('电子产品', '手机电脑'),
('服装鞋帽', '男女装'),
('食品饮料', '零食饮料');

-- 示例商品
INSERT IGNORE INTO products (name, price, stock, category_id) VALUES
('示例商品A', 99.00, 100, 1),
('示例商品B', 199.00, 50, 2);
```

---

## 📝 行动计划

### 立即行动 (现在)
1. ✅ **通知用户**: 请按 Ctrl+Shift+R 强制刷新浏览器
2. ✅ **清除缓存**: 打开F12 → Application → Local Storage → 删除所有数据
3. ✅ **重新登录**: 使用 admin / admin123 登录
4. ✅ **验证**: 检查所有列表页面是否正常显示数据

### 代码修复 (今天)
1. [ ] 修改 `request.js` 增强401处理
2. [ ] 修改 `Login.vue` 添加会话过期提示
3. [ ] 创建种子数据初始化脚本
4. [ ] 本地构建测试
5. [ ] 推送到服务器
6. [ ] 生产环境验证

### 长期改进 (本周)
1. [ ] 添加Token自动刷新机制
2. [ ] 实现多设备登录管理
3. [ ] 添加操作日志记录密钥轮换事件

---

## 🎓 经验教训

### 1. JWT密钥轮换的影响范围
- **影响**: 所有已登录用户的Session失效
- **缓解措施**: 
  - 提前通知用户
  - 实现Token刷新机制
  - 支持多版本密钥过渡期

### 2. 前端错误处理的重要性
- **教训**: 不能只显示通用错误消息
- **最佳实践**:
  - 区分错误类型（网络/认证/权限/服务器）
  - 对401/403特殊处理（清除状态、跳转登录）
  - 提供明确的用户指引（"请重新登录" vs "稍后重试"）

### 3. 部署变更的沟通
- **缺失**: 未告知用户需要重新登录
- **改进**: 
  - 变更日志中明确说明Breaking Changes
  - 部署完成后发送通知邮件
  - 网站首页添加维护公告

---

## ✅ 验证清单

### 诊断验证
- [x] API端点返回预期状态码（401无Token / 200有Token）
- [x] 登录API正常工作（返回有效Token）
- [x] 数据库连接正常且有数据
- [x] JWT新旧密钥差异确认
- [x] 前端错误处理逻辑分析完成

### 修复验证（待执行）
- [ ] 用户重新登录后能看到商品列表
- [ ] 分类管理页面显示10个分类
- [ ] Dashboard统计数据非零
- [ ] 401错误时自动跳转登录页
- [ ] 所有CRUD操作正常

---

## 📎 附录

### A. 测试工具
- **API测试脚本**: `test_api.js` (Node.js HTTP客户端)
- **执行位置**: 服务器 /tmp/test_api.js
- **使用方法**: `node test_api.js` (需要在项目目录下运行以加载.env)

### B. 关键文件路径
```
前端:
  qiguanqianduan/src/utils/request.js     # axios拦截器
  qiguanqianduan/src/views/Login.vue       # 登录组件
  qiguanqianduan/src/views/Products.vue    # 商品列表
  
后端:
  index.js                                  # 主入口 + 路由注册
  middleware/auth.js                         # JWT验证中间件
  routes/auth.js                            # 登录/注册API
  db_mysql.js                               # 数据库连接

配置:
  .env.production                           # JWT_SECRET等环境变量
  /etc/nginx/conf.d/qiguan.conf             # Nginx配置
```

### C. 相关文档
- [SERVER_DEPLOYMENT_MANUAL.md](../SERVER_DEPLOYMENT_MANUAL.md)
- [OPTION_B_IMPLEMENTATION_CHECKLIST.md](../option-b-cleanup-implementation/OPTION_B_IMPLEMENTATION_CHECKLIST.md)
- [COMPREHENSIVE_DECISION_REPORT.md](../comprehensive-system-audit-redeploy/COMPREHENSIVE_DECISION_REPORT.md)

---

**报告结束**

*本报告基于实际的服务器测试数据和代码分析，所有结论均可复现验证。*

**下一步**: 执行任务2（API认证流程修复），重点优化前端401错误处理。
