# 🗺️ 绮管后台 - 功能实施路线图 (ROADMAP)

**版本**: v1.0
**创建日期**: 2026-04-09
**基于诊断**: [ROOT_CAUSE_REPORT.md](ROOT_CAUSE_REPORT.md)
**当前状态**: ✅ 核心问题已修复 (JWT认证 + 401处理)

---

## 📊 当前系统状态总览

### ✅ 已完成功能 (Production Ready)

| 模块 | 后端API | 前端页面 | 数据库 | 测试 | 状态 |
|------|--------|----------|--------|------|------|
| **用户登录** | ✅ 完整 | ✅ 完整 | ✅ 正常 | ⚠️ 基础 | **可用** |
| **商品管理(CRUD)** | ✅ 完整 | ✅ 完整 | ✅ 有数据(6条) | ⚠️ 基础 | **可用** |
| **分类管理(CRUD)** | ✅ 完整 | ✅ 完整 | ✅ 有数据(10个) | ⚠️ 基础 | **可用** |
| **用户管理(列表)** | ✅ 完整 | ✅ 列表页 | ✅ 有admin | ❌ 未测 | **基本可用** |
| **订单列表** | ✅ 完整 | ✅ 列表页 | ✅ 待确认 | ❌ 未测 | **基本可用** |
| **健康检查** | ✅ 完整 | N/A | N/A | ✅ 通过 | **正常** |
| **搜索功能** | ✅ 基础版 | ⚠️ 部分实现 | ✅ 可用 | ❌ 未测 | **部分可用** |

### ⚠️ 需要完善的功能

| 模块 | 当前问题 | 优先级 | 预估工时 |
|------|---------|--------|----------|
| **仪表盘(Dashboard)** | 数据显示可能为0（需验证） | P0 | 2h |
| **订单详情** | 前端详情页可能缺失 | P1 | 3h |
| **购物车功能** | 前端未实现 | P2 | 8h |
| **内容管理** | 前后端都缺失 | P3 | 12h |

### ❌ 未开发的功能

| 功能模块 | 描述 | 业务价值 | 复杂度 | 建议 |
|----------|------|----------|--------|------|
| 用户注册页 | 前端注册表单 | 高 | 低 | **立即开发** |
| 个人中心 | 修改密码/头像/资料 | 中 | 中 | 本周完成 |
| 数据导出 | Excel/CSV导出 | 高 | 中 | 两周内 |
| 操作日志 | 记录管理员操作 | 中 | 中 | 两周内 |
| 消息通知 | 站内信/系统公告 | 低 | 高 | 月度规划 |
| 多语言支持 | i18n国际化 | 低 | 高 | 长期规划 |

---

## 🎯 Phase 1: 紧急修复 (已完成 ✓)

### 1.1 JWT认证问题修复 ✅
- **问题**: 方案B更换密钥导致旧Token失效
- **解决**: 增强401错误处理，自动跳转登录
- **影响文件**: `qiguanqianduan/src/utils/request.js`
- **部署状态**: ✅ 已上线 (Commit: 628e159f)

### 1.2 用户操作指引
**请立即执行以下步骤**:

1. **清除浏览器缓存**
   ```
   Windows: Ctrl + Shift + Delete → 清除缓存
   Mac: Cmd + Shift + Delete → 清除缓存
   ```

2. **清除LocalStorage** (或直接使用无痕模式)
   ```
   打开 https://qimengzhiyue.cn
   按 F12 → Application → Local Storage → 删除所有项
   ```

3. **重新登录**
   ```
   URL: https://qimengzhiyue.cn/login
   账号: admin
   密码: admin123
   ```

4. **验证数据显示**
   - 商品管理: 应显示6条商品记录
   - 分类管理: 应显示10个分类
   - 仪表盘: 统计数字应非零

---

## 🚀 Phase 2: 核心完善 (本周目标)

### 2.1 Dashboard数据验证与修复 [P0]
**预估**: 2小时

**待检查项**:
- [ ] `GET /api/v1/dashboard/stats` 返回正确的统计数据
- [ ] ECharts图表渲染无JavaScript错误
- [ ] 统计卡片显示真实数据（非硬编码0）

**可能的问题**:
- SQL聚合查询返回NULL（数据库无订单时）
- 前端未处理空数据场景
- 图表组件期望的数据格式不匹配

**修复方案**:
```javascript
// Dashboard.vue 中添加默认值处理
const stats = ref({
  totalProducts: 0,
  totalOrders: 0,
  totalUsers: 0,
  totalRevenue: 0
})

// API调用后合并数据
const res = await dashboardApi.getOverview()
if (res.data) {
  Object.assign(stats.value, res.data, {
    // 确保数值字段不为null/undefined
    totalProducts: res.data.totalProducts ?? 0,
    totalOrders: res.data.totalOrders ?? 0,
    // ...
  })
}
```

---

### 2.2 用户注册前端页面 [P0]
**预估**: 3小时

**后端API已就绪** (`POST /api/v1/auth/register`):
```json
Request Body:
{
  "username": "newuser",
  "email": "user@example.com",
  "password": "password123",
  "role": "user"  // 可选，默认"user"
}

Response (201 Created):
{
  "success": true,
  "data": {
    "token": "eyJ...",
    "user": { "id": 2, "username": "newuser", ... }
  }
}
```

**需要创建的文件**:
```
qiguanqianduan/src/views/Register.vue  (新建)
qiguanqianduan/src/api/auth.js           (添加register方法)
qiguanqianduan/src/router/index.js      (添加/register路由)
```

**Register.vue 关键功能**:
- 用户名输入 (必填, 3-20字符)
- 邮箱输入 (必填, 格式验证)
- 密码输入 (必填, ≥6字符)
- 确认密码 (必填, 与密码一致)
- 注册按钮 + 表单验证
- 成功后自动跳转到Login或Dashboard

---

### 2.3 订单管理完善 [P1]
**预估**: 4小时

**现有功能**:
- ✅ 订单列表 (分页、筛选)
- ✅ 后端CRUD API完整

**需要完善**:
- [ ] 订单详情页 (OrderDetail.vue)
  - 显示订单基本信息（订单号、金额、状态、时间）
  - 显示商品明细列表
  - 状态变更操作（确认发货、完成等）
  
- [ ] 订单搜索优化
  - 支持按订单号搜索
  - 支持按日期范围筛选
  
- [ ] 订单统计
  - 今日订单数
  - 本周销售额
  - 待处理订单数

---

## 📅 Phase 3: 功能扩展 (两周内)

### 3.1 购物车功能 [P2]
**预估**: 8小时 (较大功能)

**后端API已就绪**:
```
GET    /api/v1/cart              # 获取购物车
POST   /api/v1/cart              # 添加商品
PUT    /api/v1/cart/:id          # 更新数量
DELETE /api/v1/cart/:id          # 删除商品
DELETE /api/v1/cart              # 清空购物车
```

**需要创建的前端页面**:
- Cart.vue (购物车主页)
- 购物车组件 (CartItem.vue)

**核心功能**:
- 商品列表展示（图片、名称、价格、数量）
- 数量增减控制
- 小计金额计算
- 全选/取消全选
- 结算按钮（跳转下单）

---

### 3.2 数据导出功能 [P1]
**预估**: 4小时

**导出格式**:
- Excel (.xlsx) - 使用xlsx库
- CSV (.csv) - 简单格式

**导出范围**:
- 商品列表导出
- 订单列表导出
- 用户列表导出
- 自定义日期范围导出

**实现方案**:
```javascript
// 安装依赖: npm install xlsx file-saver

import * as XLSX from 'xlsx'
import { saveAs } from 'file-saver'

export function exportToExcel(data, filename) {
  const worksheet = XLSX.utils.json_to_sheet(data)
  const workbook = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(workbook, 'Data')
  const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' })
  saveAs(new Blob([excelBuffer], { type: 'application/octet-stream' }), `${filename}.xlsx`)
}
```

---

### 3.3 操作审计日志 [P1]
**预估**: 5小时

**需要记录的操作**:
- 用户登录/登出
- 商品添加/修改/删除
- 分类添加/修改/删除
- 订单状态变更
- 用户角色变更

**实现方式**:
```sql
-- 新建表
CREATE TABLE audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  action VARCHAR(50) NOT NULL,  -- LOGIN/CREATE/UPDATE/DELETE
  target_type VARCHAR(50),     -- product/category/order/user
  target_id INT,
  details JSON,                -- 变更前后数据对比
  ip_address VARCHAR(45),
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_id (user_id),
  INDEX idx_action (action),
  INDEX idx_created_at (created_at)
);
```

**前端查看页面**:
- AuditLog.vue (仅admin可见)
- 日志列表（分页、筛选）
- 详情展开（变更前后对比）

---

## 🔮 Phase 4: 长期规划 (月度/季度)

### 4.1 性能优化
- [ ] Redis缓存层 (热门商品、Dashboard统计数据)
- [ ] 数据库索引优化 (慢查询分析)
- [ ] 图片CDN加速 (OSS对象存储)
- [ ] API响应压缩 (Gzip/Brotli)

### 4.2 安全加固
- [ ] API限流 (rate-limiting中间件)
- [ ] 二次验证 (敏感操作需重新输入密码)
- [ ] IP黑名单 (暴力破解防护)
- [ ] 安全扫描自动化 (Dependabot/Snyk)

### 4.3 监控运维
- [ ] Sentry错误追踪集成
- [ ] Prometheus指标采集
- [ ] Grafana监控面板
- [ ] 自动化备份策略

### 4.4 用户体验提升
- [ ] 暗色模式支持
- [ ] 响应式设计优化 (平板/移动端适配)
- [ ] 键盘快捷键
- [ ] 批量操作 (批量删除/批量修改状态)

---

## 📈 技术债务清单

### 高优先级 (影响稳定性)
1. **ECharts内存泄漏** - Dashboard.vue中实例未dispose()
   ```javascript
   // 修复: 在onUnmounted中销毁实例
   import { onUnmounted } from 'vue'
   let chartInstance = null
   
   onUnmounted(() => {
     if (chartInstance) {
       chartInstance.dispose()
       chartInstance = null
     }
   })
   ```

2. **Blob URL未释放** - Products.vue中创建的Object URL未revoke()
   ```javascript
   // 修复: 及时释放URL
   URL.revokeObjectURL(url)
   ```

3. **SQL注入防护审查** - 虽然使用了参数化查询，但建议全面审计

### 中优先级 (影响可维护性)
4. **TypeScript迁移** - JavaScript→TS提高代码质量
5. **单元测试覆盖** - Vitest/Jest测试框架
6. **API文档** - Swagger/OpenAPI规范
7. **代码规范化** - ESLint + Prettier配置

### 低优先级 (锦上添花)
8. **i18n国际化** - vue-i18n多语言支持
9. **主题定制** - CSS变量主题系统
10. **PWA支持** - Service Worker离线访问

---

## 🛠️ 开发环境建议

### 推荐工具链
```json
{
  "IDE": "VS Code + Volar插件",
  "包管理": "pnpm (比npm更快)",
  "代码规范": "ESLint + Prettier",
  "Git工作流": "Git Flow (feature/release/hotfix)",
  "CI/CD": "GitHub Actions"
}
```

### 分支策略
```
main (生产环境, 受保护)
  └── develop (开发集成分支)
       ├── feature/dashboard-fix
       ├── feature/cart-module
       └── feature/user-registration

hotfix/jwt-expiry-fix (紧急修复, 直接合入main)
```

---

## 📝 下一步行动

### 立即执行 (今天)
- [x] ~~根因诊断~~ ✅
- [x] ~~401错误处理修复~~ ✅
- [x] ~~部署到生产环境~~ ✅
- [ ] **用户验证**: 请刷新浏览器并重新登录，确认数据显示正常

### 本周完成 (Phase 2)
- [ ] Dashboard数据显示验证与修复
- [ ] 用户注册前端页面开发
- [ ] 订单详情页实现

### 两周内 (Phase 3)
- [ ] 购物车功能开发
- [ ] 数据导出功能
- [ ] 操作审计日志

---

## 📞 联系与支持

**问题反馈**: 如遇到任何问题，请提供：
1. 浏览器控制台截图 (F12 → Console)
2. Network面板中的失败请求详情
3. 复现步骤描述
4. 当时的操作行为

**文档位置**:
- 项目根目录: `e:\1\绮管后台\`
- Spec文档: `.trae/specs/data-display-fix/`
- 部署手册: `SERVER_DEPLOYMENT_MANUAL.md`
- 诊断报告: `ROOT_CAUSE_REPORT.md`

---

**路线图版本**: 1.0
**最后更新**: 2026-04-09
**维护者**: AI Assistant (Trae IDE)
**下次评审**: 2026-04-16 (一周后)
