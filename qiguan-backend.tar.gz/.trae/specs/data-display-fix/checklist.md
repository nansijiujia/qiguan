# 数据显示异常与功能完善 - 验证检查清单

## 任务 1: 根因诊断与问题定位
### 1.1 API端点测试
- [ ] `GET /api/v1/products` 直接访问后端返回401（无Token时）
- [ ] `GET /api/v1/products` 通过Nginx代理返回相同状态码
- [ ] `GET /api/v1/categories` 返回预期状态码
- [ ] `GET /api/v1/users` 返回预期状态码
- [ ] `GET /api/v1/dashboard/stats` 返回预期状态码
- [ ] 所有API响应包含正确的Content-Type头

### 1.2 前端请求分析
- [ ] 浏览器Network面板显示请求URL正确（/api/v1/products等）
- [ ] 请求头包含Authorization: Bearer <token>（登录后）
- [ ] localStorage中存在有效的token和user键值
- [ ] axios baseURL配置为空或'/api'（匹配后端路由）
- [ ] 控制台无CORS相关错误

### 1.3 数据库连接验证
- [ ] MySQL/TDSQL-C连接正常（PM2日志无连接错误）
- [ ] products表存在且可查询
- [ ] categories表存在且可查询
- [ ] users表存在且包含admin账号
- [ ] SQL查询执行无语法错误

### 1.4 JWT Token有效性
- [ ] .env.production中的JWT_SECRET是64字节强密钥
- [ ] 后端middleware/auth.js正确读取JWT_SECRET环境变量
- [ ] 旧Token（更换前签发）验证失败并返回401
- [ ] 新Token（更换后签发）验证成功并返回200

---

## 任务 2: API认证流程修复
### 2.1 前端axios拦截器优化
- [ ] request.js的response拦截器正确识别401状态码
- [ ] 401错误时清除localStorage中的token和user
- [ ] 401错误时显示"登录已过期"提示（非"请求地址不存在"）
- [ ] 401错误时自动跳转到/login页面
- [ ] 其他状态码(400/403/404/500)显示对应的错误消息
- [ ] 开发环境下记录详细的请求/响应日志

### 2.2 登录流程验证
- [ ] Login.vue提交用户名密码到 `/api/v1/auth/login`
- [ ] 登录成功响应格式: `{ success: true, data: { token: "...", user: {...} } }`
- [ ] Token正确存储到localStorage.setItem('token', res.data.token)
- [ ] 用户信息正确存储到localStorage.setItem('user', JSON.stringify(res.data.user))
- [ ] 登录成功后跳转到/dashboard页面
- [ ] 登录失败时显示后端返回的具体错误消息

### 2.3 后端认证中间件调试
- [ ] verifyToken中间件从Authorization头提取Bearer Token
- [ ] 无Token时返回 `{ success: false, error: { code: 'UNAUTHORIZED', message: '...' } }`
- [ ] 有效Token时req.user包含解码后的payload(id, username, role)
- [ ] 过期Token返回TOKEN_EXPIRED错误码
- [ ] CORS预检请求(OPTIONS)不受认证限制

### 2.4 Nginx代理配置验证
- [ ] location /api/ 正确匹配所有API请求
- [ ] proxy_pass指向 http://127.0.0.1:3000
- [ ] Authorization头通过proxy_set_header传递
- [ ] Nginx不修改后端返回的状态码
- [ ] 错误页面不拦截API响应

---

## 任务 3: 数据库初始化与种子数据
### 3.1 数据库结构验证
- [ ] users表结构正确（id, username, email, password, role, status, created_at）
- [ ] products表结构正确（id, name, description, price, stock, category_id, status, image, created_at）
- [ ] categories表结构正确（id, name, description, sort_order, status, created_at）
- [ ] orders表结构正确（id, user_id, total_amount, status, created_at）
- [ ] 所有外键约束正确定义

### 3.2 初始化脚本创建
- [ ] SQL脚本包含CREATE TABLE语句（如需要）
- [ ] 脚本包含管理员账号插入语句（bcrypt密码hash）
- [ ] 脚本包含示例分类数据（至少3个分类）
- [ ] 脚本包含示例商品数据（每个分类至少1个商品）
- [ ] 脚本支持幂等执行（IF NOT EXISTS / INSERT IGNORE）

### 3.3 数据初始化执行
- [ ] 脚本在服务器上执行成功（exit code 0）
- [ ] users表包含admin账号
- [ ] categories表包含示例数据
- [ ] products表包含示例数据
- [ ] 数据可通过SQL SELECT查询确认

### 3.4 CRUD操作验证
- [ ] GET /api/v1/products 返回商品列表（非空）
- [ ] POST /api/v1/products 可创建新商品
- [ ] PUT /api/v1/products/:id 可更新商品
- [ ] DELETE /api/v1/products/:id 可删除商品
- [ ] 分类和用户的CRUD同样可用

---

## 任务 4: Dashboard功能完善
### 4.1 Dashboard API端点检查
- [ ] GET /api/v1/dashboard/stats 返回统计数据
  - totalProducts (总商品数)
  - totalOrders (总订单数)
  - totalUsers (总用户数)
  - totalRevenue (总销售额)
- [ ] GET /api/v1/dashboard/sales 返回销售趋势数组
- [ ] API响应格式符合前端期望
- [ ] 无数据时返回合理的默认值（非null/undefined）

### 4.2 前端Dashboard组件修复
- [ ] Dashboard.vue正确调用dashboardApi.getOverview()
- [ ] 响应数据正确解析并绑定到统计卡片
- [ ] ECharts图表接收正确的数据格式
- [ ] 图表渲染无JavaScript错误（控制台无红字）
- [ ] 加载状态有spinner或skeleton提示
- [ ] 空数据状态有友好提示（非显示0）

### 4.3 实时更新（可选）
- [ ] 页面加载时自动获取最新数据
- [ ] 数据刷新间隔配置合理（5分钟或手动）

---

## 任务 5: 功能模块实施计划
### 5.1 功能完整性审计
- [ ] 用户注册功能：后端API ✅ / 前端页面 ❌ → 记录差距
- [ ] 订单详情功能：后端API ✅ / 前端页面 ⚠️ → 验证完成度
- [ ] 购物车功能：后端API ✅ / 前端页面 ❌ → 规划开发
- [ ] 搜索功能：基础实现 ⚠️ / 高级优化 ❌ → 记录待优化项
- [ ] 内容管理：完全未开发 ❌ → 规划新功能

### 5.2 实施路线图文档
- [ ] P0任务清单明确（本周必须完成）
- [ ] P1任务清单明确（两周内完成）
- [ ] P2/P3任务清单明确（长期规划）
- [ ] 每个任务包含预估工时和依赖关系
- [ ] 技术债务清单已记录

---

## 任务 6: 系统集成测试
### 6.1 用户流程测试
- [ ] 新用户注册流程完整可用
- [ ] 用户登录→查看商品列表→查看商品详情
- [ ] 管理员登录→Dashboard显示统计→添加商品→管理订单
- [ ] 分页、搜索、筛选功能正常工作
- [ ] 错误提示友好且准确

### 6.2 性能基准
- [ ] 首次页面加载 < 3秒（含资源下载）
- [ ] API平均响应时间 < 200ms
- [ ] 并发10用户无明显的性能下降
- [ ] 无内存泄漏（长时间运行稳定）

### 6.3 安全性验证
- [ ] 未登录访问/api/v1/* 返回401
- [ ] 使用过期Token访问返回401
- [ ] SQL注入测试通过（特殊字符转义）
- [ ] XSS防护有效（HTML实体编码）
- [ ] 密码使用bcrypt存储（非明文）

### 6.4 生产部署验证
- [ ] 服务器代码已同步到最新版本
- [ ] 前端构建产物已更新（dist/目录）
- [ ] PM2进程正常运行（status: online）
- [ ] Nginx服务正常运行（status: active）
- [ ] HTTPS访问正常（SSL证书有效）
- [ ] 全功能验收测试通过

---

## 📊 总体进度跟踪

| 阶段 | 任务 | 状态 | 通过项 | 总项 | 完成率 |
|------|------|------|--------|------|--------|
| **诊断** | 任务1: 根因定位 | ⏳ | 0 | ~16 | 0% |
| **修复** | 任务2: 认证修复 | ⏳ | 0 | ~20 | 0% |
| **数据** | 任务3: 数据初始化 | ⏳ | 0 | ~16 | 0% |
| **完善** | 任务4: Dashboard | ⏳ | 0 | ~12 | 0% |
| **规划** | 任务5: 功能路线图 | ⏳ | 0 | ~8 | 0% |
| **验证** | 任务6: 集成测试 | ⏳ | 0 | ~18 | 0% |
| **总计** | | | **0** | **~90** | **0%** |

---

## ⚠️ 关键检查点

在进入下一阶段前，**必须**满足以下条件：

- [ ] **Gate 1**: 任务1完成 → 确认根因（401 vs 404 vs 数据库为空）
- [ ] **Gate 2**: 任务2完成 → 用户可正常登录并访问所有页面
- [ ] **Gate 3**: 任务3完成 → 数据库有初始数据，前端能显示列表
- [ ] **Gate 4**: 任务4+6完成 → 系统完整可用，所有核心功能正常

---

## 🎯 成功标准

最终交付时，系统应满足：

1. ✅ **数据显示正常**: Products/Categories/Users/Orders列表有数据展示
2. ✅ **认证流程完整**: 登录→Token存储→API调用→数据展示 全链路通畅
3. ✅ **Dashboard有用**: 统计数字反映真实数据，图表正常渲染
4. ✅ **CRUD可用**: 增删改查操作全部正常，数据持久化
5. ✅ **错误处理友好**: 所有异常情况有明确的用户提示
6. ✅ **实施计划清晰**: 未开发功能有优先级排序和时间规划
