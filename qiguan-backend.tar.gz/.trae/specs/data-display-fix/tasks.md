# 数据显示异常与功能完善 - 任务计划

## [x] 任务 1: 根因诊断与问题定位（紧急）
- **Priority**: P0 (关键路径)
- **Depends On**: None
- **Status**: ✅ **已完成** (2026-04-09)
- **Root Cause**: JWT密钥更换导致旧Token失效，前端未正确处理401错误
- **Key Findings**:
  - API返回401 (非404)，认证中间件正常
  - 登录API正常 (200, 返回有效Token)
  - 数据库有数据 (Products: 6条, Categories: 10个)
  - 使用新Token访问API全部成功 (200 + 数据返回)
- **Deliverable**: [ROOT_CAUSE_REPORT.md](ROOT_CAUSE_REPORT.md)
  全面排查列表数据不显示的根本原因，包括：
  
  ### 1.1 API端点测试
  - 测试所有API端点的HTTP状态码：
    - `GET /api/v1/products` (期望: 401无Token / 200有Token)
    - `GET /api/v1/categories` (期望: 401/200)
    - `GET /api/v1/users` (期望: 401/200)
    - `GET /api/v1/dashboard/*` (期望: 401/200)
  - 对比直接访问后端 vs 通过Nginx代理访问的结果
  - 记录完整的请求/响应头信息

  ### 1.2 前端请求分析
  - 检查浏览器Network面板中的实际请求：
    - Request URL是否正确
    - Authorization头是否存在且格式正确
    - 响应状态码和响应体内容
  - 检查localStorage中是否存储了有效Token
  - 验证axios baseURL配置 (`VITE_API_BASE_URL`)

  ### 1.3 数据库连接验证
  - 检查数据库连接状态（MySQL/TDSQL-C）
  - 验证数据表是否存在且有数据：
    - `products` 表记录数
    - `categories` 表记录数
    - `users` 表记录数
    - `orders` 表记录数
  - 检查SQL查询是否正确执行（查看PM2日志）

  ### 1.4 JWT Token有效性检查
  - 确认当前.env.production中的JWT_SECRET值
  - 验证前端存储的Token是否使用新密钥签发
  - 测试用旧Token和新Token分别访问API的结果
  
- **Deliverable**: 根因诊断报告 (ROOT_CAUSE_REPORT.md)
- **Test Requirements**:
  - `verification` TR-1.1: 所有API端点返回预期的状态码
  - `verification` TR-1.2: 前端请求携带正确的认证头
  - `verification` TR-1.3: 数据库连接正常且表存在
  - `verification` TR-1.4: JWT Token验证逻辑正确

---

## [ ] 任务 2: API认证流程修复（紧急）
- **Priority**: P0
- **Depends On**: 任务 1
- **Description**:
  修复API认证相关的所有问题：

  ### 2.1 前端axios拦截器优化
  - **文件**: `qiguanqianduan/src/utils/request.js`
  - 增强401错误处理：
    - 清除localStorage中的token和user
    - 显示明确的"登录已过期"提示
    - 自动跳转到/login页面
    - 避免将401误报为其他错误
  - 添加请求日志（开发环境）：
    - 记录每个API请求的URL、方法、状态码
    - 记录响应时间（用于性能监控）
  - 优化错误消息显示：
    - 区分网络错误 vs HTTP错误
    - 显示后端返回的具体错误信息

  ### 2.2 登录流程验证与修复
  - **文件**: `qiguanqianduan/src/views/Login.vue`
  - 验证登录成功后的处理逻辑：
    - 检查响应数据结构是否匹配前端期望
    - 确保Token正确存储到localStorage
    - 确保用户信息正确解析和存储
  - 修复可能的格式不匹配问题：
    - 后端返回: `{ success: true, data: { token: "...", user: {...} } }`
    - 前端期望: `res.data.token` 和 `res.data.user`

  ### 2.3 后端认证中间件调试
  - **文件**: `middleware/auth.js`, `index.js`
  - 验证verifyToken中间件的行为：
    - 无Token时返回401 + 正确的错误格式
    - 有效Token时正确解码并设置req.user
    - 过期Token时返回TOKEN_EXPIRED错误
  - 检查CORS配置是否影响预检请求(OPTIONS)

  ### 2.4 Nginx代理配置验证
  - **文件**: `/etc/nginx/conf.d/qiguan.conf` (服务器)
  - 确认API代理规则正确：
    - `/api/` 路径正确转发到 `http://127.0.0.1:3000`
    - Authorization头正确传递
    - 错误状态码不被Nginx拦截或修改

- **Acceptance Criteria**:
  - AC-1: 用户登录后可正常访问所有受保护API
  - AC-2: Token过期时自动跳转登录页
  - AC-3: 所有HTTP状态码被正确识别和处理
- **Test Requirements**:
  - `programmatic` TR-2.1: axios拦截器单元测试通过
  - `manual` TR-2.2: 登录→访问Dashboard完整流程正常
  - `programmatic` TR-2.3: 后端中间件返回正确的错误格式
  - `verification` TR-2.4: Nginx代理不修改API响应状态码

---

## [ ] 任务 3: 数据库初始化与种子数据（重要）
- **Priority**: P1
- **Depends On**: 任务 2
- **Description**:
  确保数据库有必要的初始数据：

  ### 3.1 数据库结构验证
  - 检查所有必要的数据表是否存在：
    - users, products, categories, orders, order_items, cart
  - 验证表结构是否与代码中的SQL查询匹配
  - 检查外键约束和索引

  ### 3.2 创建初始化脚本
  - **新文件**: `scripts/init_database.sql` 或 `scripts/init_mysql_database.js`
  - 包含以下内容：
    ```sql
    -- 管理员账号（bcrypt密码）
    INSERT INTO users (username, email, password, role, status) 
    VALUES ('admin', 'admin@qimengzhiyue.cn', '<bcrypt_hash>', 'admin', 'active');
    
    -- 示例分类
    INSERT INTO categories (name, description, sort_order) VALUES
    ('电子产品', '手机、电脑等电子设备', 1),
    ('服装鞋帽', '男女装、鞋子、帽子', 2),
    ('食品饮料', '零食、饮料、生鲜', 3),
    ('家居用品', '家具、厨具、装饰', 4);
    
    -- 示例商品
    INSERT INTO products (name, description, price, stock, category_id, status, image) VALUES
    ('iPhone 15 Pro', '最新款苹果手机', 8999.00, 100, 1, 'active', ''),
    ('MacBook Pro 14', 'M3芯片笔记本电脑', 14999.00, 50, 1, 'active', ''),
    ('运动休闲套装', '舒适透气的运动服装', 299.00, 200, 2, 'active', ''),
    ('有机绿茶', '高山有机茶叶500g', 128.00, 500, 3, 'active', '');
    ```

  ### 3.3 执行数据初始化
  - 在服务器上执行初始化脚本
  - 验证数据插入成功
  - 测试CRUD操作是否正常工作

  ### 3.4 创建种子数据管理API（可选）
  - 添加管理员专用的数据管理接口：
    - `POST /api/v1/init/seed` - 填充示例数据
    - `DELETE /api/v1/init/seed` - 清空示例数据
  - 仅限admin角色访问
  - 生产环境禁用

- **Deliverable**: 数据库初始化脚本 + 种子数据文档
- **Test Requirements**:
  - `programmatic` TR-3.1: 脚本执行无错误
  - `verification` TR-3.2: 数据库包含初始数据
  - `manual` TR-3.3: 前端页面能显示示例数据
  - `verification` TR-3.4: CRUD操作正常

---

## [ ] 任务 4: Dashboard功能完善（重要）
- **Priority**: P1
- **Depends On**: 任务 3
- **Description**:
  完善仪表盘的数据展示功能：

  ### 4.1 Dashboard API端点检查
  - **文件**: `routes/dashboard.js`
  - 验证现有API端点：
    - `GET /api/v1/dashboard/stats` - 统计概览（总商品/总订单/总用户/总销售额）
    - `GET /api/v1/dashboard/sales` - 销售趋势数据
    - `GET /api/v1/dashboard/recent-orders` - 最近订单
  - 检查SQL查询是否正确（特别是JOIN和聚合函数）

  ### 4.2 前端Dashboard组件修复
  - **文件**: `qiguanqianduan/src/views/Dashboard.vue`
  - 验证数据获取逻辑：
    - API调用参数是否正确
    - 响应数据结构是否匹配组件期望
    - ECharts图表渲染是否依赖特定数据格式
  - 修复数据显示为0的问题：
    - 检查是否有默认值处理
    - 添加加载状态和空状态提示

  ### 4.3 实时数据更新（可选）
  - 添加定时刷新机制（每5分钟）
  - 或使用WebSocket推送实时数据

- **Test Requirements**:
  - `verification` TR-4.1: Dashboard统计数字非零（有数据时）
  - `verification` TR-4.2: 图表正常渲染无报错
  - `manual` TR-4.3: 刷新页面数据保持一致

---

## [ ] 任务 5: 未开发功能模块实施计划
- **Priority**: P2
- **Depends On**: 任务 4
- **Description**:
  制定剩余功能的详细实施计划：

  ### 5.1 功能完整性审计
  逐个检查每个功能模块的完成度：
  
  | 功能 | 后端API | 前端页面 | 数据库 | 测试 | 状态 |
  |------|--------|----------|--------|------|------|
  | 用户登录 | ✅ | ✅ | ✅ | ⚠️ | 基本完成 |
  | 用户注册 | ✅ | ❌ | ✅ | ❌ | 待完善 |
  | 商品CRUD | ✅ | ✅ | ✅ | ⚠️ | 基本完成 |
  | 分类CRUD | ✅ | ✅ | ✅ | ⚠️ | 基本完成 |
  | 订单列表 | ✅ | ✅ | ✅ | ❌ | 待验证 |
  | 订单详情 | ✅ | ⚠️ | ✅ | ❌ | 待完善 |
  | 用户管理 | ✅ | ✅ | ✅ | ❌ | 待验证 |
  | 购物车 | ✅ | ❌ | ✅ | ❌ | 待开发 |
  | 搜索功能 | ✅ | ⚠️ | ✅ | ❌ | 待优化 |
  | 内容管理 | ✅ | ❌ | ❌ | ❌ | 待开发 |

  ### 5.2 优先级排序与时间规划
  根据业务价值和技术复杂度排序：
  
  **P0 - 本周必须完成**:
  - 登录/注册流程完善
  - 商品/分类CRUD完全可用
  - Dashboard数据显示正确
  
  **P1 - 两周内完成**:
  - 订单管理完善（列表/详情/状态变更）
  - 用户管理完善（角色/权限）
  - 搜索功能优化
  
  **P2 - 一个月内**:
  - 购物车功能开发
  - 内容管理系统
  - 数据导出功能
  
  **P3 - 长期规划**:
  - 消息通知系统
  - 数据分析报表
  - 多语言支持

  ### 5.3 技术债务清单
  记录需要重构或优化的代码：
  - ECharts内存泄漏问题（Dashboard.vue）
  - Blob URL未释放（Products.vue）
  - SQL注入防护审查
  - API限流机制缺失

- **Deliverable**: 功能实施路线图 (ROADMAP.md)

---

## [ ] 任务 6: 系统集成测试与部署验证
- **Priority**: P1
- **Depends On**: 任务 2, 3, 4
- **Description**:
  完整的功能回归测试：

  ### 6.1 完整用户流程测试
  - 注册新用户 → 登录 → 浏览商品 → 模拟下单
  - 管理员登录 → 添加商品 → 管理订单 → 查看Dashboard

  ### 6.2 性能基准测试
  - 页面加载时间 < 3秒
  - API响应时间 < 500ms (P95)
  - 并发用户支持 > 50

  ### 6.3 安全性验证
  - 未授权访问返回401
  - SQL注入防护有效
  - XSS攻击防护检查
  - CSRF token验证（如适用）

  ### 6.4 部署最终验证
  - 服务器代码同步
  - 前端重新构建
  - 服务重启无报错
  - 全功能验收测试

- **Test Requirements**:
  - `manual` TR-6.1: 用户流程测试全部通过
  - `programmatic` TR-6.2: 性能指标达标
  - `security` TR-6.3: 安全扫描无高危漏洞
  - `verification` TR-6.4: 生产环境稳定运行

---

## Task Dependencies
```
任务 1 (根因诊断)
  ↓
任务 2 (认证修复) ──┬──→ 任务 3 (数据初始化)
                      │         ↓
                      └──→ 任务 4 (Dashboard完善)
                                 ↓
                           任务 5 (功能规划) ← 可并行
                                 ↓
                           任务 6 (集成测试)
```

## Notes
- **P0任务**（1-2）：必须立即执行，解决数据显示问题
- **P1任务**（3-4, 6）：重要，确保核心功能可用
- **P2任务**（5）：规划性质，为后续迭代做准备
- **预计总耗时**: 2-3小时（诊断+修复）+ 1-2天（完善+测试）

## 关键风险
1. **JWT密钥更换影响**: 所有旧Token失效，用户需重新登录
2. **数据库为空**: 可能需要初始化种子数据才能看到效果
3. **前后端数据格式不一致**: 需要仔细对齐API契约
