# 数据显示异常与功能完善 Spec

## Why
方案B安全加固实施完成后，系统出现两个关键问题：
1. **列表数据不显示**: Products/Categories/Users等页面全部显示"No Data, Total: 0"，控制台报404错误
2. **功能模块不完整**: 多个规划中的功能尚未开发完成，影响系统可用性

初步诊断表明：JWT密钥更换导致旧Token失效（401被前端误报为404），且数据库可能缺少初始数据。

## What Changes
- **BREAKING**: JWT密钥已更换，所有用户需重新登录
- 修复API认证流程，确保401正确处理而非误报为404
- 数据库初始化与种子数据填充
- 未开发功能模块的实施计划制定与优先级排序
- 前端错误处理优化（区分401/404/500）

## Impact
- Affected specs: option-b-cleanup-implementation (后续), comprehensive-system-audit-redeploy (参考)
- Affected code:
  - `qiguanqianduan/src/views/*.vue` (Products, Categories, Users, Orders, Dashboard)
  - `qiguanqianduan/src/utils/request.js` (axios拦截器)
  - `routes/*.js` (后端API路由)
  - `db_mysql.js` / `db.js` (数据库连接)
  - `.env.production` (环境变量)

## ADDED Requirements

### Requirement: API认证错误正确处理
系统 SHALL 正确区分并处理不同的HTTP错误状态码：

#### Scenario: 未授权访问(401)
- **WHEN** 用户Token无效或过期时访问受保护API
- **THEN** 前端应显示"登录已过期"提示并自动跳转到登录页
- **AND** 不应将401误报为404

#### Scenario: 资源不存在(404)
- **WHEN** 请求的API路径不存在
- **THEN** 显示"请求地址不存在"错误信息

#### Scenario: 服务器错误(500)
- **WHEN** 后端发生内部错误
- **THEN** 显示友好的错误提示并记录日志

### Requirement: 数据库初始化与种子数据
系统 SHALL 提供数据库初始化机制：

#### Scenario: 首次部署
- **WHEN** 系统首次部署或数据库为空时
- **THEN** 自动创建必要的数据表结构
- **AND** 插入默认管理员账号和示例数据（可选）

#### Scenario: 种子数据填充
- **WHEN** 管理员需要测试数据时
- **THEN** 可通过脚本或API插入示例商品、分类、订单数据

### Requirement: 功能模块完整性检查
系统 SHALL 具备以下核心功能模块：

| 模块 | 当前状态 | 优先级 |
|------|----------|--------|
| 用户认证(登录/注册) | ✅ 已完成 | P0 |
| 仪表盘(Dashboard) | ⚠️ 部分完成 | P0 |
| 商品管理(CRUD) | ✅ 后端完成 | P0 |
| 分类管理(CRUD) | ✅ 后端完成 | P0 |
| 订单管理 | ⚠️ 部分完成 | P1 |
| 用户管理 | ✅ 后端完成 | P1 |
| 购物车功能 | ⚠️ 待验证 | P2 |
| 搜索功能 | ✅ 基础完成 | P2 |
| 内容管理 | ⚠️ 待验证 | P3 |

## MODIFIED Requirements

### Requirement: 前端错误拦截器增强
当前的`request.js`拦截器需要优化：
- 添加更详细的日志记录（便于调试）
- 区分网络错误和HTTP状态码错误
- 401错误时应清除本地存储并跳转，而非仅显示消息
- 添加重试机制（对于临时性错误）

### Requirement: 登录流程优化
Login.vue需要确保：
- 登录成功后正确存储Token到localStorage
- Token格式符合后端期望（Bearer scheme）
- 登录失败时显示后端返回的具体错误信息

## REMOVED Requirements
无

## Implementation Phases

### Phase A: 紧急修复（立即执行）
1. **诊断根因**: 确认404 vs 401的实际原因
2. **修复认证流程**: 确保Token正确传递和处理
3. **数据库检查**: 确认数据库连接和数据存在性
4. **前端缓存清理**: 强制用户重新登录获取新Token

### Phase B: 数据初始化（短期）
5. **创建数据库初始化脚本**
6. **添加种子数据（示例商品/分类/用户）**
7. **验证CRUD操作完整性**

### Phase C: 功能完善（中期）
8. **Dashboard数据接口完善**
9. **订单管理功能补全**
10. **购物车功能验证与修复**

### Phase D: 长期优化（持续）
11. **性能优化（索引、缓存）**
12. **监控告警集成**
13. **自动化测试覆盖**
