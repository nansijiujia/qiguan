# 生产部署检查清单 v4.0.0

## 📋 部署前必查项 (Pre-Deployment)

> **重要提示**: 在执行 `bash deploy.sh` 之前，必须逐项确认以下所有检查项！
> 
> **部署时间窗口建议**: 选择低峰期（如凌晨2:00-6:00），预计耗时15-30分钟

---

### ✅ 代码准备

- [ ] **C1**: 所有代码变更已提交到Git main分支
  - **验证命令**:
    ```bash
    cd /www/wwwroot/qiguan-backend
    git status
    # 期望输出: "nothing to commit, working tree clean"
    git log --oneline -3
    # 确认最新提交包含本次部署内容
    ```
  - **通过标准**: `git status` 显示工作区干净，无未提交的更改

- [ ] **C2**: 无未提交的本地修改 (`git status` clean)
  - **验证方法**: 运行 `git status --porcelain`
  - **通过标准**: 无任何输出（空结果）

- [ ] **C3**: 无敏感信息泄露 (.env, 密码等不在代码中)
  - **检查项**:
    - [ ] `.env` 文件不在 Git 跟踪列表中
    - [ ] 代码中无硬编码的密码或密钥
    - [ ] 数据库连接字符串使用环境变量
    - [ ] JWT_SECRET 不在代码库中
  - **验证命令**:
    ```bash
    git ls-files | grep -E '\.env$|\.env\.local$'
    grep -r "password\s*=\s*['\"][^'\"]+['\"]" --include="*.js" | grep -v node_modules
    ```

- [ ] **C4**: 通过本地测试 (`npm test` 或手动测试)
  - **测试范围**:
    - [ ] 后端单元测试通过
    - [ ] API接口测试通过
    - [ ] 前端构建成功 (npm run build)
  - **验证命令**:
    ```bash
    npm test  # 如果配置了测试框架
    cd qiguanqianduan && npm run build && echo "✅ 前端构建成功"
    ```

---

### 🗄️ 数据库准备

- [ ] **D1**: production_schema.sql 可在测试环境成功执行
  - **测试步骤**:
    1. 在测试数据库执行:
       ```bash
       mysql -h <test-db-host> -u QMZYXCX -p qmzyxcx_test < database/production_schema.sql
       ```
    2. 检查是否有ERROR输出
    3. 验证表数量 >= 12
  - **通过标准**: 无SQL语法错误，所有表创建成功

- [ ] **D2**: 已备份数据库 (mysqldump)
  - **备份命令**:
    ```bash
    mysqldump -h 10.0.0.16 -u QMZYXCX -p'LJN040821.' \
      --single-transaction --routines --triggers \
      qmzyxcx > backups/db-backup-${TIMESTAMP}.sql
    ```
  - **验证**: 备份文件大小合理 (>100KB)

- [ ] **D3**: 确认数据库连接配置正确 (.env.production)
  - **检查项**:
    ```
    DB_TYPE=mysql                    ✅ 必须是mysql
    DB_HOST=10.0.0.16                ✅ TDSQL-C内网地址
    DB_PORT=3306                     ✅ 标准MySQL端口
    DB_USER=QMZYXCX                 ✅ 数据库用户名
    DB_PASSWORD=LJN040821.           ✅ 数据库密码
    DB_NAME=qmzyxcx                  ✅ 数据库名称
    NODE_ENV=production              ✅ 生产环境标识
    ```
  - **验证命令**: `cat .env.production | grep -E "^DB_|^NODE_ENV"`

---

### 🖥️ 服务器准备

- [ ] **S1**: SSH连接正常
  - **测试**: `ssh root@your-server-ip 'echo "SSH OK"'`
  - **通过标准**: 能正常登录并执行命令

- [ ] **S2**: 磁盘空间充足 (> 2GB可用)
  - **检查命令**:
    ```bash
    df -h /www/wwwroot/qiguan-backend
    # 期望: Available 列显示 >= 2G
    ```
  - **警告阈值**: 可用空间 < 5G 时应清理旧备份和日志

- [ ] **S3**: PM2已安装且配置正确
  - **检查命令**:
    ```bash
    pm2 list
    pm2 show qiguan-backend  # 或你的应用名
    ```
  - **通过标准**: PM2进程存在，ecosystem.config.js路径正确

- [ ] **S4**: Nginx配置已更新 (如有变更)
  - **检查项**:
    - [ ] SSL证书未过期 (检查有效期 > 30天)
    - [ ] 反向代理指向正确的后端端口
    - [ ] CORS配置允许小程序域名
    - [ ] 静态资源路径指向 dist/ 目录
  - **验证命令**:
    ```bash
    nginx -t  # 配置语法检查
    systemctl status nginx  # 服务状态
    ```

---

### 🔄 回滚准备

- [ ] **R1**: 回滚脚本 rollback.sh 已就绪
  - **位置**: `/www/wwwroot/qiguan-backend/rollback.sh`
  - **权限**: `chmod +x rollback.sh`
  - **测试**: `./rollback.sh --help` (如有帮助信息)

- [ ] **R2**: 最近的备份文件存在且完整
  - **检查命令**:
    ```bash
    ls -lht backups/*.tar.gz | head -3
    tar -tzf backups/pre-deploy-latest.tar.gz | head -10
    ```
  - **通过标准**: 至少有1个最近24小时内的完整备份

- [ ] **R3**: 回滚步骤已文档化并测试过
  - **文档**: 本文件的"紧急回滚流程"章节
  - **演练**: 最近一次回滚演练时间: _________
  - **联系人**: 运维负责人电话: ___________

---

## 🚀 部署后验证 (Post-Deployment)

> **部署完成后，必须按顺序执行以下验证！**

---

### 🔐 基础功能验证

#### 1️⃣ 后台管理系统访问

- [ ] **P1**: 后台登录页面可访问 (https://qimengzhiyue.cn)
  - **测试方法**: 浏览器打开URL，页面加载时间 < 5秒
  - **预期结果**: 显示登录表单，无白屏/500错误

- [ ] **P2**: admin/admin123 可以成功登录
  - **操作步骤**:
    1. 输入用户名: admin
    2. 输入密码: admin123
    3. 点击登录按钮
  - **预期结果**:
    - ✅ 显示"登录成功!"提示
    - ✅ 自动跳转到 Dashboard 页面
    - ✅ 左侧菜单完整显示

- [ ] **P3**: Dashboard页面正常显示数据
  - **检查项**:
    - [ ] 8个统计卡片都有数值 (不为0/NaN/undefined)
    - [ ] 收入趋势图渲染正常 (有数据点)
    - [ ] 订单状态环形图显示各状态占比
    - [ ] 最近订单列表自动滚动更新
  - **性能要求**: 完全加载时间 < 5秒

- [ ] **P4**: 所有菜单导航正常工作
  - **测试菜单项**:
    - [ ] 商品管理 → 商品列表页加载
    - [ ] 分类管理 → 分类列表页加载
    - [ ] 订单管理 → 订单列表页加载
    - [ ] 用户管理 → 用户列表页加载
    - [ ] 购物车管理 → 统计卡片+表格显示
    - [ ] 优惠券管理 → 优惠券列表显示
    - [ ] 内容管理 → Banner/推荐/公告三个Tab可切换

---

### 📡 API接口验证

- [ ] **A1**: GET /api/v1/products 返回商品列表
  - **测试命令**:
    ```bash
    curl -s https://qimengzhiyue.cn/api/v1/products?page=1&pageSize=10 | python3 -c "
    import sys, json
    data = json.load(sys.stdin)
    assert data['success'] == True, f'success字段错误: {data}'
    assert 'list' in data['data'], f'缺少list字段'
    print(f'✅ 成功返回 {len(data[\"data\"][\"list\"])} 个商品')
    "
    ```
  - **预期**: 返回JSON包含 success=true 和 data.list 数组

- [ ] **A2**: GET /api/v1/categories 返回分类列表 (含 /products/category 别名)
  - **测试命令**:
    ```bash
    curl -s https://qimengzhiyue.cn/api/v1/categories | head -20
    curl -s https://qimengzhiyue.cn/api/v1/products/category | head -20
    ```

- [ ] **A3**: GET /api/v1/users/me 返回用户信息 (普通用户token)
  - **前置条件**: 需要先获取有效token
  - **测试命令**:
    ```bash
    TOKEN=$(curl -s -X POST https://qimengzhiyue.cn/api/v1/auth/login \
      -H "Content-Type: application/json" \
      -d '{"username":"admin","password":"admin123"}' | python3 -c "import sys,json; print(json.load(sys.stdin)['data']['token'])")
    
    curl -s -H "Authorization: Bearer $TOKEN" https://qimengzhiyue.cn/api/v1/users/me
    ```

- [ ] **A4**: GET /api/v1/coupons 返回优惠券列表 (普通用户token)
  - **测试命令**: 同A3，替换URL为 /api/v1/coupons

- [ ] **A5**: POST /api/v1/auth/login 返回token
  - **测试命令**:
    ```bash
    curl -s -X POST https://qimengzhiyue.cn/api/v1/auth/login \
      -H "Content-Type: application/json" \
      -d '{"username":"admin","password":"admin123"}'
    ```
  - **预期**: 返回 `{"success":true,"data":{"token":"eyJ...","user":{...}}}`

---

### 📱 小程序集成验证

- [ ] **M1**: 小程序首页加载正常 (Banner + 推荐 + 分类)
  - **测试工具**: 微信开发者工具
  - **检查项**:
    - [ ] Banner轮播组件显示 (至少3张图片)
    - [ ] 推荐商品区域加载 (网格布局)
    - [ ] 分类入口图标显示 (横向滚动)
  - **性能**: 首屏渲染时间 < 3秒 (WiFi环境)

- [ ] **M2**: 商品详情页可打开
  - **操作**: 点击任意商品进入详情页
  - **验证**:
    - [ ] 商品图片轮播正常
    - [ ] 价格、库存、描述信息完整
    - [ ] "加入购物车"按钮可点击

- [ ] **M3**: 购物车功能可用
  - **测试流程**:
    1. 添加商品到购物车
    2. 进入购物车页面
    3. 修改数量 (+/-)
    4. 删除商品
  - **预期**: 所有操作响应正常，数据持久化

- [ ] **M4**: 个人中心可访问
  - **测试入口**: 底部Tab栏 → "我的"
  - **验证项**:
    - [ ] 用户头像和昵称显示
    - [ ] 订单入口可见 (全部/待付款/待发货/待收货)
    - [ ] 功能菜单完整 (地址/收藏/优惠券/足迹)

---

### ⚡ 性能指标验证

- [ ] **V1**: 首页加载时间 < 3秒
  - **测量工具**: Chrome DevTools Network面板 或 Lighthouse
  - **测量点**: 从输入URL到DOM Content Loaded事件
  - **通过标准**: FCP (First Contentful Paint) < 1.5秒, LCP (Largest Contentful Paint) < 3秒

- [ ] **V2**: API平均响应时间 < 500ms
  - **测量方法**:
    ```bash
    time curl -s https://qimengzhiyue.cn/api/v1/products?page=1&pageSize=10 > /dev/null
    # 重复5次取平均值
    ```
  - **通过标准**: P50 < 200ms, P95 < 500ms, P99 < 1000ms

- [ ] **V3**: PM2进程稳定运行 (无频繁重启)
  - **检查命令**:
    ```bash
    pm2 show qiguan-backend | grep -E "restart|status|uptime"
    pm2 logs --lines 20 --nostream | grep -i error | wc -l
    ```
  - **通过标准**:
    - restart次数 = 0 (或 < 3次/小时)
    - uptime > 10分钟 (刚重启后)
    - 最近日志中FATAL错误数 = 0

- [ ] **V4**: 无JavaScript控制台错误
  - **检查方法**: 浏览器F12 → Console标签
  - **关注错误类型**:
    - [ ] 无红色Error消息
    - [ ] 无404资源加载失败
    - [ ] 无网络请求超时
  - **工具推荐**: Sentry错误监控 (如已集成)

---

## 🆘 紧急回滚流程

> **触发条件**: 部署后出现以下任一情况时立即执行回滚：
> - 健康检查返回非200状态码
> - 登录功能完全不可用
> - PM2进程持续崩溃 (restart > 5次/分钟)
> - 数据库连接失败
> - 关键业务流程中断 (下单/支付)

### 回滚步骤

```bash
# 1. SSH到服务器
ssh root@your-server-ip

# 2. 进入项目目录
cd /www/wwwroot/qiguan-backend

# 3. 执行回滚脚本 (选择最近的备份)
# 方式A: 自动选择最新备份
bash rollback.sh

# 方式B: 指定备份文件
bash rollback.sh backups/pre-deploy-20260409-023000.tar.gz

# 4. 按照提示确认回滚 (需要输入两次确认)

# 5. 验证回滚成功
pm2 status  # 所有进程应为 online
curl -I https://qimengzhiyue.cn/health  # 应返回 HTTP/1.1 200
```

### 回滚后验证清单

- [ ] 后台管理系统可以登录 (admin/admin123)
- [ ] Dashboard数据显示正常
- [ ] 小程序首页能加载
- [ ] 核心API接口返回正确数据
- [ ] PM2进程稳定运行 (无频繁重启)

---

## 📞 紧急联系人

| 角色 | 姓名 | 电话 | 微信 | 备注 |
|------|------|------|------|------|
| **开发负责人** | [填写] | [填写] | [填写] | 技术问题第一联系人 |
| **运维负责人** | [填写] | [填写] | [填写] | 服务器/数据库问题 |
| **产品负责人** | [填写] | [填写] | [填写] | 业务决策 |
| **DBA** | [填写] | [填写] | [填写] | 数据库紧急恢复 |

**7×24值班电话**: _________________________

---

## ✍️ 部署签名

### 部署前审批

- **执行人**: _______________ 日期: _______ 时间: _______
- **技术审核人**: _______________ 日期: _______ 时间: _______
- **产品批准人**: _______________ 日期: _______ 时间: _______

### 部署后验收

- **部署完成确认**: _______________ 日期: _______ 时间: _______
- **冒烟测试通过**: _______________ 日期: _______ 时间: _______
- **业务验收通过**: _______________ 日期: _______ 时间: _______
- **最终上线批准**: _______________ 日期: _______ 时间: _______

---

## 📊 部署记录模板

```
部署编号: DEPLOY-YYYYMMDD-HHMMSS
部署版本: v4.0.0 (commit: xxxxxxx)
部署人员: [姓名]
开始时间: YYYY-MM-DD HH:MM:SS
结束时间: YYYY-MM-DD HH:MM:SS
总耗时: XX分钟XX秒

部署前检查:
  ✅ 代码准备: 通过 (commit abc1234)
  ✅ 数据库准备: 通过 (备份文件: db-backup-xxx.sql)
  ✅ 服务器准备: 通过 (磁盘剩余: X.X GB)
  ✅ 回滚准备: 通过 (最近备份: pre-deploy-xxx.tar.gz)

部署过程:
  Step 1 环境检查: ✅ 通过 (耗时: XXs)
  Step 2 备份当前版本: ✅ 完成 (大小: XXX MB)
  Step 3 拉取最新代码: ✅ 完成 (commit: def5678)
  Step 4 安装依赖: ✅ 完成 (新增包: multer)
  Step 5 构建前端: ✅ 完成 (dist大小: X.X MB)
  Step 6 更新数据库: ✅ 完成 (表数量: 14)
  Step 7 重启服务: ✅ 完成 (PM2进程: online)
  Step 8 清理缓存: ✅ 完成
  Step 9 冒烟测试: ✅ 通过 (3/3)

部署后验证:
  ✅ 健康检查: HTTP 200
  ✅ 登录功能: 正常
  ✅ Dashboard: 数据正常
  ✅ API接口: 全部通过
  ✅ 小程序集成: 正常
  ✅ 性能指标: 达标

问题记录:
  [如有异常情况在此记录]

备注:
  [其他说明]

签名: _______________
```

---

## 📚 相关文档链接

- [部署脚本使用指南](../deploy.sh) - deploy.sh 详细说明
- [回滚操作手册](../rollback.sh) - rollback.sh 使用方法
- [任务清单](tasks.md) - Phase 3 完整任务分解
- [验证清单](checklist.md) - 技术验证详细项
- [API对比矩阵](API_COMPARISON_MATRIX.md) - 小程序与后台接口对照
- [生产Schema](../../database/production_schema.sql) - 数据库结构定义

---

**文档版本**: v4.0.0  
**最后更新**: 2026-04-09  
**维护者**: DevOps团队  
**下次审查日期**: 2026-05-09