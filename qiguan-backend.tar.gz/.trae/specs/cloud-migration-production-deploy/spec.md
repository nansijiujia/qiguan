# 全面系统优化与云端集成部署 Spec

## Why
当前系统存在数据库连接混合配置（本地SQLite + 云MySQL fallback机制），需要统一迁移至腾讯云TDSQL-C数据库，实现小程序与后台系统的数据实时同步。同时需完成代码部署、功能测试、安全检查和质量优化，确保整个电商生态系统达到生产级上线标准。

## What Changes

### 🔴 Phase 1: 云数据库全面迁移 (Critical)
- **移除所有本地数据库依赖**
  - 删除 SQLite fallback 逻辑 (index.js:23-28)
  - 移除 db.js 本地数据库模块引用
  - 强制使用 db_mysql.js 作为唯一数据源
  - 配置错误时直接报错而非降级

- **统一数据库连接配置**
  - 所有组件通过 TDSQL-C (10.0.0.16:3306) 连接
  - 数据库名: qmzyxcx
  - 用户名: QMZYXCX
  - 优化连接池参数 (生产级)

- **数据库初始化脚本整合**
  - 合并 mysql_init.sql + coupons_init.sql + content_init.sql
  - 创建完整的 production_schema.sql
  - 包含所有表结构、索引、初始数据

### 🟡 Phase 2: 小程序云端集成 (High)
- **小程序API端点统一**
  - 验证小程序使用的API_BASE_URL指向正确的后端服务
  - 确保请求路径与后台路由完全匹配 (/api/v1/*)
  - 统一认证机制 (JWT token)

- **数据模型一致性检查**
  - 对比小程序api.js定义的接口与后台实际路由
  - 检查请求/响应格式是否兼容
  - 修复字段名不匹配问题

- **共享数据库验证**
  - 确认小程序和后台操作同一数据库实例
  - 测试数据实时同步 (后台添加商品 → 小程序可见)
  - 验证事务隔离级别

### 🟢 Phase 3: 生产环境部署 (High)
- **完整代码部署流程**
  - Git仓库整理 (清理未跟踪文件)
  - 后端代码打包推送至服务器
  - 前端构建产物上传 (qiguanqianduan/dist/)
  - PM2进程管理配置优化

- **环境清理**
  - 删除服务器上旧版本文件
  - 清理临时文件、日志、缓存
  - 确保无冗余代码残留
  - Nginx配置更新并reload

- **依赖安装与构建**
  - 服务端 npm install --production
  - 前端 npm run build (生成dist目录)
  - 安装新依赖 (multer, echarts等)

### 🔵 Phase 4: 功能与性能测试 (Medium)
- **小程序全功能测试矩阵**
  - 用户模块: 注册/登录/个人信息/地址管理
  - 商品模块: 首页/分类/搜索/详情/收藏
  - 购物车模块: 添加/删除/修改数量/清空
  - 订单模块: 下单/支付(模拟)/列表/详情/取消
  - 优惠券模块: 领取/使用/查看
  - 其他: 客服/FAQ/售后/足迹

- **网络环境测试**
  - WiFi环境下响应时间 (<2s)
  - 4G网络下加载性能 (<3s)
  - 弱网模式 (2G/3G) 降级策略
  - 断网重连机制验证

- **安全性评估**
  - 接口权限验证 (未登录访问受保护资源)
  - SQL注入测试 (特殊字符输入)
  - XSS攻击防护 (商品名称、评论等)
  - 敏感数据传输 (HTTPS强制)
  - Token存储安全 (wx.setStorageSync加密)

### 🟣 Phase 5: 后台功能验证 (Medium)
- **新增功能测试**
  - 登录功能 (admin/admin123)
  - Dashboard数据显示 (8卡片+4图表)
  - 购物车管理 (列表/统计/删除)
  - 优惠券CRUD (创建/编辑/删除/统计)
  - 内容管理 (Banner上传/排序/预览)

- **数据上传完整性测试**
  - 通过后台添加商品 → 小程序刷新可见
  - 上传Banner图片 → 首页轮播显示
  - 创建优惠券 → 小程序可领取使用
  - 修改公告 → 小程序公告栏更新

- **测试数据清理**
  - 编写cleanup_test_data.sql脚本
  - 清除所有测试订单、购物车、优惠券领取记录
  - 重置自增ID (可选, 生产环境慎用)
  - 验证数据纯净度

### ⚪ Phase 6: 代码质量优化 (Low)
- **小程序代码审查**
  - 检查所有console.log/debugger (移除或改为wx.logger)
  - 识别硬编码的URL/IP地址 (改用配置文件)
  - 检查内存泄漏风险 (定时器清除、事件解绑)
  - 优化图片懒加载策略

- **冲突解决**
  - 检查Git合并冲突标记 (<<<<<< ==== >>>>>)
  - 统一代码风格 (2空格缩进、单引号/双引号)
  - 移除死代码 (注释掉的函数、未使用的变量)
  - 优化import顺序

- **性能优化**
  - 减少setData调用频率 (批量更新)
  - 图片压缩与CDN加速
  - 分包加载优化 (subPackages配置)
  - 启动速度优化 (首屏渲染<1.5s)

## Impact

### Affected specs:
- `fix-login-and-enhance-system` (之前的登录修复和功能拓展)

### Affected code:
**后台系统**:
- [index.js](file:///e:/1/绮管后台/index.js) - 移除SQLite fallback, 强制MySQL
- [db.js](file:///e:/1/绮管后台/db.js) - 标记为deprecated或删除引用
- [db_mysql.js](file:///e:/1/绮管后台/db_mysql.js) - 优化连接池参数
- [.env.production](file:///e:/1/绮管后台/.env.production) - 确认云数据库配置
- [routes/*.js] - 所有路由文件 (无需修改, 但需验证)
- 新增: database/production_schema.sql (整合脚本)

**小程序系统**:
- [config/production.js](file:///e:/1/绮梦之约小程序电商平台/config/production.js) - 验证API_BASE_URL
- [utils/request.js](file:///e:/1/绮梦之约小程序电商平台/utils/request.js) - 检查超时/重试逻辑
- [utils/api.js](file:///e:/1/绮梦之约小程序电商平台/utils/api.js) - 验证接口路径匹配
- [app.js](file:///e:/1/绮梦之约小程序电商平台/app.js) - 全局错误处理
- [pages/**/*.js] - 各页面业务逻辑 (抽样检查)

## ADDED Requirements

### Requirement: 云数据库强制连接
The system SHALL exclusively use cloud-based MySQL/TDSQL-C database for all data operations. Local SQLite database connections SHALL be completely removed.

#### Scenario: Database connection on startup
- **WHEN** the backend server starts
- **THEN** it SHALL attempt to connect to TDSQL-C only (host: 10.0.0.16, port: 3306)
- **AND** if connection fails, it SHALL terminate with error code 1 (not fallback to SQLite)
- **AND** log detailed connection error information for debugging

#### Scenario: Database health verification
- **WHEN** any API endpoint is accessed
- **AND** the database connection is lost or unhealthy
- **THEN** the system SHALL return 503 Service Unavailable with error code 'DB_UNAVAILABLE'
- **AND** attempt automatic reconnection with exponential backoff (1s, 2s, 4s, max 30s)

### Requirement: 小程序后台数据实时同步
The mini-program and backend management system SHALL share the same cloud database instance to ensure data consistency and real-time synchronization.

#### Scenario: Product added via backend visible in mini-program
- **WHEN** an administrator creates a new product through the backend CMS
- **AND** sets its status to 'active'
- **THEN** the mini-program SHALL display this product within 5 seconds (or next API call)
- **AND** all product details (name, price, image, description) match exactly

#### Scenario: Order placed in mini-program visible in backend
- **WHEN** a user places an order through the mini-program
- **THEN** the backend order management page SHALL show this order immediately after refresh
- **AND** order status changes are bidirectionally consistent

### Requirement: Production-ready deployment
The deployment process SHALL ensure clean installation without legacy code conflicts, optimized performance, and comprehensive testing validation.

#### Scenario: Clean deployment
- **WHEN** deploying new version to production server
- **THEN** the process SHALL:
  1. Backup current running version
  2. Remove all files in deployment directory
  3. Extract new codebase from Git repository
  4. Install dependencies (npm install --production)
  5. Build frontend assets (npm run build)
  6. Initialize/update database schema
  7. Restart services (PM2 restart all)
  8. Clear CDN/Nginx cache
  9. Run smoke tests (health check, login test)
  10. Rollback automatically if smoke tests fail

#### Scenario: Zero-downtime verification
- **AFTER** deployment completes
- **THEN** the following checks MUST pass:
  - HTTP status 200 on homepage
  - Login API responds within 500ms
  - All static resources load without 404 errors
  - No JavaScript console errors
  - Database queries complete < 200ms (p95)

### Requirement: Comprehensive security audit
The system SHALL pass security vulnerability scanning covering authentication, authorization, injection attacks, and data protection.

#### Scenario: Authentication security test
- **GIVEN** a user is not logged in
- **WHEN** they attempt to access protected API endpoints (cart, orders, profile)
- **THEN** the system SHALL return 401 Unauthorized
- **AND** not leak sensitive information in error messages

#### Scenario: Input sanitization test
- **WHEN** user submits form data containing special characters (' OR 1=1 --, <script>alert('xss')</script>, etc.)
- **THEN** the system SHALL sanitize or escape the input
- **AND** prevent SQL injection and XSS attacks
- **AND** log suspicious attempts for security monitoring

## MODIFIED Requirements

### Requirement: Error handling enhancement
All error responses SHALL include correlation IDs for debugging, and client-side errors SHALL be user-friendly while server-side errors SHALL be generic for security.

**Modification**: 
- Add `X-Request-ID` header to all HTTP responses
- Implement structured logging with request tracing
- Frontend error messages: localized Chinese text
- Backend error logs: full stack trace (development mode only)

### Requirement: Performance baseline
System response times SHALL meet the following SLAs across different network conditions:

**Modification**:
- API average response time: < 300ms (WiFi), < 800ms (4G), < 1500ms (3G)
- Mini-program cold start: < 3 seconds
- Image loading: < 2 seconds (with lazy loading)
- Page transition animation: smooth 60fps

## REMOVED Requirements

### Requirement: Local SQLite database support
**Reason**: Cloud migration requires single source of truth; local databases cause data inconsistency
**Migration**: 
1. Export existing SQLite data (if any important)
2. Import to cloud MySQL using migration scripts
3. Delete db.js file or mark as @deprecated
4. Update all require('./db') references to require('./db_mysql')

---

## Implementation Strategy

### Execution Order (Sequential Phases):

```
Phase 1: 云数据库迁移 (2-3 hours)
  ↓ (必须先完成，后续阶段依赖)
Phase 2: 小程序集成 (2-3 hours)
  ↓ (可并行部分任务)
Phase 3: 生产部署 (2-3 hours)
  ↓
Phase 4: 功能测试 (3-4 hours)
  ↓ (可与Phase 5并行)
Phase 5: 后台验证 (2-3 hours)
  ↓
Phase 6: 代码优化 (2-3 hours)
```

**Total Estimated Time**: 13-19 hours (可并行缩短至10-14小时)

---

## Risk Assessment

| Risk | Probability | Impact | Mitigation |
|------|------------|--------|------------|
| Database migration data loss | Low | Critical | Full backup before migration, test on staging first |
| Mini-program API incompatibility | Medium | High | Interface comparison matrix, mock testing |
| Deployment downtime | Medium | Medium | Blue-green deployment, instant rollback |
| Performance regression | Low | Medium | Baseline measurement before/after |
| Security vulnerabilities exposed | Medium | High | Automated security scanning (Snyk/Semgrep) |

---

## Success Criteria

### Critical (Must Pass):
- [ ] 100% cloud database connectivity (zero local DB usage)
- [ ] Mini-program successfully connects to backend APIs
- [ ] Data synchronization verified (backend ↔ mini-program)
- [ ] Production deployment successful with zero errors
- [ ] No security vulnerabilities (HIGH/CRITICAL severity)

### Important (Should Pass):
- [ ] All core user flows tested and working (register→browse→cart→order)
- [ ] Response times meet SLA requirements (>95% of requests)
- [ ] Code quality score > 8/10 (linting, no console.log, no conflicts)
- [ ] Test data fully cleaned after verification

### Nice to Have (Bonus):
- [ ] Automated CI/CD pipeline configured
- [ ] Monitoring dashboard operational (PM2+, Grafana)
- [ ] Load test passed (100 concurrent users)
- [ ] Documentation updated (deployment guide, API docs)

---

## Deliverables

### Code Artifacts:
1. **database/production_schema.sql** - Complete unified schema script
2. **index.js** (modified) - Cloud-only database configuration
3. **Mini-program config updates** (if needed)
4. **Deployment scripts** - automate.sh/deploy.bat
5. **Test reports** - functional/security/performance results

### Documentation:
1. **MIGRATION_GUIDE.md** - Step-by-step cloud migration process
2. **DEPLOYMENT_CHECKLIST.md** - Pre/post-deployment verification
3. **TEST_REPORT.md** - Comprehensive test results
4. **ROLLBACK_PROCEDURE.md** - Emergency rollback steps

---

## Post-Deployment Monitoring Checklist:

- [ ] Database connection pool healthy (active connections < 80% of max)
- [ ] PM2 processes running (0 restarts in last hour)
- [ ] Error rate < 0.1% (4xx/5xx responses)
- [ ] P95 response time < 500ms
- [ ] Disk usage < 80%
- [ ] Memory usage < 75%
- [ ] SSL certificate valid (if HTTPS enabled)
- [ ] Cron jobs executing correctly (backups, cleanup)
