# API 对比矩阵 - 小程序端 vs 后台端

**生成时间**: 2026-04-09
**版本**: Phase 2 - 小程序云端集成
**状态**: ✅ 已完成初步对比

---

## 1. 完整 API 路径对比表

### 1.1 商品模块 (Products)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 1 | `/api/v1/products` | GET | `/products` | ✅ 匹配 | 商品列表（支持分页） |
| 2 | `/api/v1/products/:id` | GET | `/products/:id` | ✅ 匹配 | 商品详情 |
| 3 | `/api/v1/products/search` | GET | `/products/search` | ⚠️ 待验证 | 搜索功能需确认参数格式 |
| 4 | `/api/v1/products/recommended` | GET | `/products/recommended` | ⚠️ 可能不存在 | 后台可能未实现此端点 |
| 5 | `/api/v1/products/hot` | GET | `/products/hot` | ⚠️ 可能不存在 | 后台可能未实现此端点 |
| 6 | `/api/v1/products/suggestions` | GET | `/products/suggestions` | ⚠️ 可能不存在 | 搜索建议功能 |

### 1.2 分类模块 (Categories)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 7 | `/api/v1/products/category` | GET | `/categories` | ❌ **不匹配** | ⚠️ 路径不一致！小程序用 products/category，后台用 categories |
| 8 | `/api/v1/products/category/:id` | GET | `/categories/:id` | ❌ **不匹配** | 同上，路径需要统一 |

### 1.3 购物车模块 (Cart)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 9 | `/api/v1/cart` | GET | `/cart` | ✅ 匹配 | 获取购物车列表 |
| 10 | `/api/v1/cart` | POST | `/cart` | ✅ 匹配 | 添加商品到购物车 |
| 11 | `/api/v1/cart/:id` | PUT | `/cart/:id` | ✅ 匹配 | 更新购物车项 |
| 12 | `/api/v1/cart/batch` | PUT | `/cart/batch` | ⚠️ 待验证 | 批量更新功能 |
| 13 | `/api/v1/cart/:id` | DELETE | `/cart/:id` | ✅ 匹配 | 删除购物车项 |
| 14 | `/api/v1/cart/batch` | DELETE | `/cart/batch` | ⚠️ 待验证 | 批量删除功能 |
| 15 | `/api/v1/cart` | DELETE | `/cart` | ✅ 匹配 | 清空购物车 |
| 16 | `/api/v1/cart/select/all` | PUT | `/cart/select/all` | ⚠️ 待验证 | 全选/取消全选 |

### 1.4 订单模块 (Orders)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 17 | `/api/v1/orders` | POST | `/orders` | ✅ 匹配 | 创建订单 |
| 18 | `/api/v1/orders` | GET | `/orders` | ✅ 匹配 | 订单列表（支持分页） |
| 19 | `/api/v1/orders/:id` | GET | `/orders/:id` | ✅ 匹配 | 订单详情 |
| 20 | `/api/v1/orders/:id/cancel` | PUT | `/orders/:id/cancel` | ⚠️ 待验证 | 取消订单 |
| 21 | `/api/v1/orders/:id/pay` | POST | `/orders/:id/pay` | ⚠️ 待验证 | 支付订单 |
| 22 | `/api/v1/orders/:id/ship` | POST | `/orders/:id/ship` | ⚠️ 待验证 | 发货（可能仅后台使用） |
| 23 | `/api/v1/orders/:id/logistics` | GET | `/orders/:id/logistics` | ⚠️ 待验证 | 物流信息 |
| 24 | `/api/v1/orders/:id/logistics/tracking` | GET | `/orders/:id/logistics/tracking` | ⚠️ 可能不存在 | 物流追踪详情 |
| 25 | `/api/v1/orders/:id/confirm` | PUT | `/orders/:id/confirm` | ⚠️ 待验证 | 确认收货 |

### 1.5 收藏模块 (Favorites)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 26 | `/api/v1/users/favorite/check` | GET | `/users/favorite/check` | ⚠️ 待验证 | 检查收藏状态 |
| 27 | `/api/v1/users/favorite` | POST | `/users/favorite` | ✅ 匹配 | 添加收藏 |
| 28 | `/api/v1/users/favorite/:productId` | DELETE | `/users/favorite/:productId` | ✅ 匹配 | 取消收藏 |

### 1.6 首页/内容模块 (Content/Homepage)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 29 | `/api/v1/content/homepage` | GET | `/content/homepage` | ✅ 匹配 | 首页数据聚合 |
| 30 | `/api/v1/content/homepage/banners` | GET | `/content/homepage/banners` | ⚠️ 待验证 | Banner列表 |
| 31 | `/api/v1/content/homepage/recommendations` | GET | `/content/homepage/recommendations` | ⚠️ 待验证 | 推荐商品 |
| 32 | `/api/v1/content/homepage/promotions` | GET | `/content/homepage/promotions` | ⚠️ 待验证 | 促销活动 |
| 33 | `/api/v1/content/homepage/hot-products` | GET | `/content/homepage/hot-products` | ⚠️ 待验证 | 热门商品 |

### 1.7 用户模块 (Users)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 34 | `/api/v1/users/me` | GET | `/users/me` | ⚠️ 待验证 | 当前用户信息（可能是 /profile） |
| 35 | `/api/v1/users/me` | PUT | `/users/me` | ⚠️ 待验证 | 更新用户资料 |
| 36 | `/api/v1/users/order-stats` | GET | `/users/order-stats` | ⚠️ 待验证 | 订单统计 |
| 37 | `/api/v1/users/favorites` | GET | `/users/favorites` | ⚠️ 待验证 | 收藏列表 |
| 38 | `/api/v1/users/footprints` | GET/POST/DELETE | `/users/footprints` | ⚠️ 待验证 | 浏览足迹 |

### 1.8 优惠券模块 (Coupons)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 39 | `/api/v1/users/coupons` | GET | `/users/coupons` | ⚠️ 权限问题 | ⚠️ 后台路由有 requireRole('admin') 限制！用户无法访问 |
| 40 | `/api/v1/users/coupons/receive` | POST | `/users/coupons/receive` | ⚠️ 权限问题 | 同上 |
| 41 | `/api/v1/users/coupons/available` | GET | `/users/coupons/available` | ⚠️ 权限问题 | 同上 |

### 1.9 搜索模块 (Search)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 42 | `/api/v1/search/hot-keywords` | GET | `/search/hot-keywords` | ✅ 匹配 | 热门搜索关键词 |
| 43 | `/api/v1/search/suggestions` | GET | `/search/suggestions` | ✅ 匹配 | 搜索建议 |

### 1.10 认证模块 (Auth)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 44 | `/api/v1/auth/login` | POST | `/auth/login` | ✅ 匹配 | 用户登录 |
| 45 | `/api/v1/auth/register` | POST | `/auth/register` | ⚠️ 待验证 | 用户注册（如果存在） |

### 1.11 健康检查 (Health)

| # | 小程序路径 | HTTP方法 | 后台路由 | 匹配状态 | 备注 |
|---|-----------|----------|---------|---------|------|
| 46 | `/health` | GET | `/health` | ✅ 匹配 | 基础健康检查 |
| 47 | `/health/db-test` | GET | `/health/db-test` | ✅ 匹配 | 数据库连接测试 |

---

## 2. 统计摘要

| 类别 | 总数 | ✅ 已匹配 | ⚠️ 待验证 | ❌ 不匹配 | 匹配率 |
|------|------|-----------|-----------|-----------|--------|
| 商品模块 | 6 | 2 | 3 | 0 | 33% |
| 分类模块 | 2 | 0 | 0 | 2 | **0%** ⚠️ |
| 购物车模块 | 8 | 5 | 3 | 0 | 63% |
| 订单模块 | 9 | 3 | 6 | 0 | 33% |
| 收藏模块 | 3 | 2 | 1 | 0 | 67% |
| 内容模块 | 5 | 1 | 4 | 0 | 20% |
| 用户模块 | 5 | 0 | 5 | 0 | 0% |
| 优惠券模块 | 3 | 0 | 3 | 0 | **0%** 🔴 |
| 搜索模块 | 2 | 2 | 0 | 0 | 100% |
| 认证模块 | 2 | 1 | 1 | 0 | 50% |
| 健康检查 | 2 | 2 | 0 | 0 | 100% |
| **总计** | **47** | **18** | **26** | **2** | **38%** |

---

## 3. 认证机制对比

### 3.1 Token 存储方式

| 项目 | 小程序端 | 后台端 | 一致性 |
|------|---------|--------|--------|
| **存储位置** | `wx.setStorageSync('token')` | 从 `Authorization` 头读取 | ✅ 一致 |
| **Token Key** | `'token'` | 解析 `Bearer <token>` 格式 | ✅ 一致 |
| **Header格式** | `Authorization: Bearer ${token}` | 中间件解析 Bearer token | ✅ 一致 |

### 3.2 JWT 配置一致性

| 配置项 | 小程序期望 | 后台配置 | 状态 |
|--------|-----------|---------|------|
| **JWT_SECRET** | 需与后台一致 | 在 `.env` 或代码中定义 | ⚠️ **需手动验证** |
| **Token过期时间** | 建议 24h | 需查看 middleware/auth.js | ⚠️ **待确认** |
| **算法** | HS256 (标准) | 通常为 HS256 | ✅ 可能一致 |

**⚠️ 关键发现**: 
- 小程序在 [request.js:130](file:///e:/1/绮梦之约小程序电商平台/utils/request.js#L130) 中从 `wx.getStorageSync('token')` 读取 token
- 后台需要在 `middleware/auth.js` 中使用相同的 JWT_SECRET 验证 token
- **必须确保两端 JWT_SECRET 完全相同**

### 3.3 权限中间件应用情况

| 后台路由 | 中间件 | 问题 |
|---------|--------|------|
| `/categories` | `[verifyToken]` | ✅ 正常 |
| `/products` | `[verifyToken]` | ✅ 正常 |
| `/cart` | `[verifyToken]` | ✅ 正常 |
| `/orders` | `[verifyToken]` | ✅ 正常 |
| `/users` | `[verifyToken, requireRole('admin')]` | 🔴 **严重问题!** 用户端API被限制为admin角色 |
| `/content` | `[verifyToken]` | ✅ 正常 |
| `/coupons` | `[verifyToken, requireRole('admin')]` | 🔴 **严重问题!** 用户优惠券API不可访问 |

---

## 4. 数据格式兼容性说明

### 4.1 请求格式

| 方面 | 小程序发送 | 后台接收 | 兼容性 |
|------|-----------|---------|--------|
| **Content-Type** | `application/json` | Express JSON parser | ✅ 兼容 |
| **认证头** | `Authorization: Bearer <token>` | auth middleware | ✅ 兼容 |
| **查询参数** | URL query string | `req.query` | ✅ 兼容 |
| **请求体** | JSON object | `req.body` | ✅ 兼容 |
| **签名参数** | timestamp, nonce, signature (可选) | 可选验证 | ⚠️ 需确认后台是否验证 |

### 4.2 响应格式

| 场景 | 小程序期望格式 | 后台实际返回 | 兼容性 |
|------|---------------|-------------|--------|
| **成功响应** | `{ success: true, data: {...} }` | 需验证 | ⚠️ **关键!** 必须统一 |
| **错误响应** | `{ code: xxx, message: '...' }` | 需验证 | ⚠️ **关键!** 必须统一 |
| **分页数据** | `{ list: [...], pagination: { page, pageSize, total } }` | 需验证 | ⚠️ 需确认结构 |
| **列表数据** | 数组或包含list字段的对象 | 需验证 | ⚠️ 需确认结构 |

### 4.3 特殊场景处理

| 场景 | 小程序处理逻辑 | 后台应返回 | 备注 |
|------|--------------|-----------|------|
| **401 未授权** | 跳转登录页 | `{ code: 401, message: '...' }` | ✅ api.js已处理 |
| **403 无权限** | Toast提示 | `{ code: 403, message: '...' }` | ✅ api.js已处理 |
| **404 不存在** | Toast提示 | `{ code: 404, message: '...' }` | ✅ api.js已处理 |
| **500 服务器错误** | Toast提示 | `{ code: 500, message: '...' }` | ✅ api.js已处理 |
| **网络异常** | 分类提示 (TIMEOUT/NETWORK/SERVER/CLIENT) | N/A | ✅ request.js已增强 |

---

## 5. 发现的问题及修复建议

### 🔴 P0 - 严重问题 (必须立即修复)

#### 问题 1: 分类路径不一致
- **现象**: 小程序调用 `/api/v1/products/category`，但后台注册的是 `/api/v1/categories`
- **影响**: 分类功能完全不可用
- **修复方案**:
  ```javascript
  // 方案A (推荐): 修改小程序 api.js
  category: {
    getList: () => request(`${API_BASE_PATH}/categories`),  // 改为 /categories
    getProducts: (id, params) => request(`${API_BASE_PATH}/categories/${id}?${objectToQueryString(params)}`)
  }
  
  // 方案B: 在后台添加别名路由
  app.use('/api/v1/products/category', categoriesRouter);
  ```

#### 问题 2: 优惠券 API 权限错误
- **现象**: 后台 `/coupons` 路由使用了 `requireRole('admin')` 中间件
- **影响**: 普通用户无法访问任何优惠券相关功能（领取、查看、使用）
- **修复方案**:
  ```javascript
  // 在 index.js 中修改 coupons 路由注册:
  { path: '/coupons', module: './routes/coupons' },  // 移除 requireRole('admin')
  // 或者拆分为两个路由:
  { path: '/coupons/user', module: './routes/coupons_user', middleware: [verifyToken] },
  { path: '/coupons/admin', module: './routes/coupons_admin', middleware: [verifyToken, requireRole('admin')] }
  ```

#### 问题 3: 用户 API 权限过严
- **现象**: `/users` 路由同样有 admin 角色限制
- **影响**: 用户个人信息、订单统计、收藏列表等均无法访问
- **修复方案**: 同问题2，将用户端和管理端路由分离

### 🟡 P1 - 重要问题 (尽快修复)

#### 问题 4: 多个端点可能不存在
- **涉及端点**: 
  - `/products/recommended` (推荐商品)
  - `/products/hot` (热门商品)
  - `/products/suggestions` (搜索建议)
  - `/orders/:id/logistics/tracking` (物流追踪)
  - `/content/homepage/*` 子路由 (Banner/推荐/促销/热品)
- **影响**: 相关功能显示空数据或报错
- **修复方案**: 
  1. 在对应的后台 router 文件中添加这些路由处理函数
  2. 或在小程序中添加 fallback 逻辑（显示默认数据）

#### 问题 5: 响应格式未标准化
- **风险**: 不同路由可能返回不同的数据结构
- **影响**: 小程序解析失败或数据显示异常
- **修复方案**: 
  ```javascript
  // 统一响应格式中间件
  const responseFormatter = (req, res, next) => {
    const originalJson = res.json;
    res.json = function(data) {
      if (!data.hasOwnProperty('success')) {
        data = { success: true, data };
      }
      originalJson.call(res, data);
    };
    next();
  };
  ```

### 🟢 P2 - 优化建议 (可选改进)

#### 建议 1: 添加 API 版本控制
- 当前所有API都在 `/api/v1/` 下，这是好的实践
- 建议未来升级时使用 `/api/v2/` 保持向后兼容

#### 建议 2: 实现请求日志
- 在后台添加 morgan 或自定义 logger 记录所有API请求
- 有助于调试和性能监控

#### 建议 3: 添加速率限制
- 使用 express-rate-limit 防止恶意请求
- 特别是登录、注册等敏感接口

#### 建议 4: 统一错误码体系
```javascript
// 建议的错误码规范
const ERROR_CODES = {
  SUCCESS: 0,
  INVALID_PARAMS: 1001,
  UNAUTHORIZED: 1002,
  FORBIDDEN: 1003,
  NOT_FOUND: 1004,
  SERVER_ERROR: 5000,
  DATABASE_ERROR: 5001,
  NETWORK_ERROR: 5002
};
```

---

## 6. 下一步行动清单

### 立即执行 (今日必须完成)
- [ ] **修复分类路径**: 统一 `/products/category` 和 `/categories`
- [ ] **修复权限配置**: 移除 users/coupons 的 admin 限制（或拆分路由）
- [ ] **验证 JWT_SECRET**: 确保前后端使用相同的密钥
- [ ] **测试核心流程**: 登录 → 浏览商品 → 加入购物车 → 下单

### 短期优化 (本周完成)
- [ ] 补充缺失的路由端点 (recommended/hot/suggestions 等)
- [ ] 统一响应格式 (success/data 结构)
- [ ] 添加 API 文档 (Swagger/OpenAPI)
- [ ] 编写集成测试用例

### 长期规划 (下个迭代)
- [ ] 实现 API 版本控制 (/api/v2/)
- [ ] 添加监控和告警
- [ ] 性能优化 (缓存、CDN)
- [ ] 安全加固 (速率限制、输入校验增强)

---

## 附录 A: 技术细节

### A.1 小程序网络层配置 (已优化)
**文件**: [request.js](file:///e:/1/绮梦之约小程序电商平台/utils/request.js)

| 参数 | 旧值 | 新值 | 说明 |
|------|-----|------|------|
| timeout | 10000ms (10s) | **15000ms (15s)** | 更宽容的超时设置 |
| retry | 1次 | **2次** | 提高请求成功率 |
| cache.maxSize | 50条 | **100条** | 增大缓存容量 |
| errorHandling | 简单提示 | **分类处理** | 支持 TIMEOUT/NETWORK_ERROR/SERVER_ERROR/CLIENT_ERROR |

### A.2 后台路由注册代码
**文件**: [index.js:64-76](file:///e:/1/绮管后台/index.js#L64-L76)

```javascript
const routes = [
  { path: '/auth', module: './routes/auth' },
  { path: '/categories', module: './routes/categories', middleware: [verifyToken] },
  { path: '/products', module: './routes/products', middleware: [verifyToken] },
  { path: '/dashboard', module: './routes/dashboard', middleware: [verifyToken] },
  { path: '/orders', module: './routes/orders', middleware: [verifyToken] },
  { path: '/users', module: './routes/users', middleware: [verifyToken, requireRole('admin')] },  // ⚠️ 问题!
  { path: '/cart', module: './routes/cart', middleware: [verifyToken] },
  { path: '/content', module: './routes/content', middleware: [verifyToken] },
  { path: '/search', module: './routes/search' },
  { path: '/coupons', module: './routes/coupons', middleware: [verifyToken, requireRole('admin')] },  // ⚠️ 问题!
  { path: '/health', module: './routes/health' }
];
```

### A.3 小程序 API 定义代码
**文件**: [api.js](file:///e:/1/绮梦之约小程序电商平台/utils/api.js)

完整API列表已在上方表格中列出，共 **47 个端点**，覆盖 11 个业务模块。

---

## 附录 B: 参考链接

- 小程序 API 定义: [api.js](file:///e:/1/绮梦之约小程序电商平台/utils/api.js)
- 小程序请求工具: [request.js](file:///e:/1/绮梦之约小程序电商平台/utils/request.js)
- 后台路由注册: [index.js#L64-L76](file:///e:/1/绮管后台/index.js#L64-L76)
- 任务清单: [tasks.md](file:///e:/1/绮管后台/.trae/specs/cloud-migration-production-deploy/tasks.md)

---

**文档维护者**: AI Assistant  
**最后更新**: 2026-04-09  
**下次审查日期**: 2026-04-16 (一周后)
