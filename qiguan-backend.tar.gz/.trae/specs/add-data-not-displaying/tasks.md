# 添加数据不显示 - 任务计划

## [x] 任务 1: 深度诊断 - 确认响应数据结构不匹配
- **Priority**: P0 (关键路径)
- **Depends On**: None
- **Status**: ✅ **已完成** (2026-04-09)
- **Root Cause**: axios响应拦截器返回`response.data`(2层嵌套)而非`response`(3层)，导致Vue组件的`res.data?.data`访问路径得到undefined
- **Key Findings**:
  - 所有Vue组件统一使用 `res.data?.data.list` (期望3层)
  - 拦截器实际返回 `response.data` (只有2层)
  - 结果：条件判断失败 → tableData=[] → 显示"No Data"
- **Deliverable**: 诊断确认（见spec.md）

## [x] 任务 2: 修复axios拦截器 + 所有Vue组件
- **Priority**: P0
- **Depends On**: 任务 1
- **Status**: ✅ **已完成** (2026-04-09)
- **Fix Applied**: 
  - 文件: `qiguanqianduan/src/utils/request.js`
  - 改动: 第57行 `return res` → `return response`
  - 额外: 新增409 CONFLICT友好提示(橙色warning)
- **Impact**: 所有Vue组件无需改动，自动兼容现有代码

## [x] 任务 3: 本地构建与部署
- **Priority**: P0
- **Depends On**: 任务 2
- **Status**: ✅ **已完成** (2026-04-09)
- **Build**: 本地2260 modules, 6.74s + 服务器14.11s (exit code 0)
- **Commit**: `6b8682fc`
- **Deploy**: PM2 restarted, website HTTP 200 ✓

## [x] 任务 4: 功能验证测试
- **Priority**: P1
- **Depends On**: 任务 3
- **Status**: ✅ **待用户验证** (2026-04-09)
- **Next Step**: 用户需刷新浏览器并重新登录测试完整CRUD流程
  精确定位前端数据解析失败的根本原因：
  
  ### 1.1 对比axios原始响应 vs 拦截器返回值
  - 检查request.js拦截器到底返回什么（response vs response.data）
  - 对比后端API实际返回的JSON结构
  - 对比Vue组件期望的数据嵌套层级
  
  ### 1.2 检查所有受影响组件的数据访问方式
  - Products.vue: `res.data?.data` 还是 `res?.data`?
  - Categories.vue: 同上
  - Users.vue: 同上
  - Orders.vue: 同上
  - Dashboard.vue: 同上
  
  ### 1.3 验证假设
  创建测试代码验证：
  ```javascript
  // 假设后端返回: {success:true, data:{list:[...]}}
  // axios response.data = 上面的JSON
  // 拦截器返回: response.data (当前) 或 response (应该?)
  
  // 如果拦截器返回 response.data:
  const res = {success:true, data:{list:[1,2,3]}}
  console.log(res.data.data)  // → {list:[1,2,3]} ✅ 或 undefined?
  
  // 如果拦截器返回 response:
  const res = {data: {success:true, data:{list:[1,2,3]}}}
  console.log(res.data.data)  // → {list:[1,2,3]} ✅
  ```

- **Deliverable**: 诊断确认报告（明确bug位置）

---

## [ ] 任务 2: 修复axios拦截器 + 所有Vue组件
- **Priority**: P0
- **Depends On**: 任务 1
- **Description**:
  
  ### 2.1 方案选择（二选一）
  
  **方案A**: 修改拦截器，返回完整response对象
  ```javascript
  // request.js - 修改response拦截器
  service.interceptors.response.use(
    (response) => {
      const res = response.data  // 后端JSON
      
      if (res.success === false) {
        // 错误处理...
        return Promise.reject(...)
      }
      
      return response  // ← 改为返回完整response对象
      // 这样Vue组件可以用 res.data.data 访问业务数据
    }
  )
  ```
  
  **方案B**: 保持拦截器不变，修改所有Vue组件
  ```javascript
  // 所有Vue组件统一改为:
  const res = await productApi.getProducts(params)
  // res = {success:true, data:{list:[...], pagination:{...}}}
  
  if (res.success && res.data) {
    tableData.value = res.data.list || []
    pagination.total = res.data.pagination?.total || 0
  }
  ```
  
  **推荐**: 方案B（改动更可控，不影响其他可能依赖拦截器的代码）
  
  ### 2.2 修复文件清单
  
  | 文件 | 修改内容 |
  |------|----------|
  | `src/utils/request.js` | 可选：调整返回值或添加调试日志 |
  | `src/views/Products.vue` | fetchData()中的数据解析逻辑 |
  | `src/views/Categories.vue` | fetchData()中的数据解析逻辑 |
  | `src/views/Users.vue` | fetchData()中的数据解析逻辑 |
  | `src/views/Orders.vue` | fetchData()中的数据解析逻辑 |
  | `src/views/Dashboard.vue` | 数据获取逻辑 |

  ### 2.3 统一数据访问模式
  ```javascript
  // 所有组件使用统一的模式:
  const fetchXxx = async () => {
    loading.value = true
    try {
      const res = await xxxApi.getXxx(params)
      
      // 统一的数据提取逻辑
      if (res && res.success !== false) {
        const data = res.data || res  // 兼容两种结构
        if (Array.isArray(data)) {
          tableData.value = data
        } else if (data.list) {
          tableData.value = data.list
          pagination.total = data.pagination?.total || data.length
        } else if (data) {
          // 单个对象或统计数据
          Object.assign(formData, data)
        }
      }
    } catch (error) {
      console.error('获取数据失败:', error)
      ElMessage.error(error.message || '加载数据失败')
    } finally {
      loading.value = false
    }
  }
  ```

- **Acceptance Criteria**:
  - AC-1: 添加商品后列表立即显示新商品
  - AC-2: 添加分类后分类列表刷新显示新分类
  - AC-3: 编辑操作后数据更新正确
  - AC-4: 删除操作后条目从列表移除
  - AC-5: 409错误时显示"数据已存在"友好提示

---

## [ ] 任务 3: 本地构建与部署
- **Priority**: P0
- **Depends On**: 任务 2
- **Description**:
  - 执行 `npm run build` 确保无编译错误
  - 推送代码到生产服务器
  - 服务器端重新构建前端
  - 重启PM2服务
  - 验证Nginx正常服务新版本

---

## [ ] 任务 4: 功能验证测试
- **Priority**: P1
- **Depends On**: 任务 3
- **Description**:
  
  ### 4.1 完整CRUD流程测试
  - [ ] 商品: 添加→列表显示→编辑→更新→删除→列表移除
  - [ ] 分类: 添加→列表显示→编辑→更新→删除→列表移除
  - [ ] 用户: 添加→列表显示→角色变更→禁用/启用
  - [ ] 订单: 列表加载→详情查看→状态变更
  
  ### 4.2 边界情况测试
  - [ ] 空列表状态显示（No Data提示）
  - [ ] 大量数据分页（>100条）
  - [ ] 特殊字符（中文、emoji、<script>等）
  - [ ] 并发添加相同数据（409处理）
  - [ ] 网络超时/断开恢复
  
  ### 4.3 浏览器兼容性
  - [ ] Chrome 最新版
  - [ ] Firefox 最新版
  - [ ] Edge 最新版

---

## Task Dependencies
```
任务 1 (深度诊断)
  ↓
任务 2 (核心修复) 
  ↓
任务 3 (构建部署)
  ↓
任务 4 (功能验证)
```

## Notes
- **关键风险**: 数据结构修改可能影响所有API调用，需全面回归测试
- **回滚方案**: Git revert到上一个commit (628e159f)
- **预计耗时**: 诊断30min + 修复1h + 部署15min + 测试30min ≈ 2.5h
