# 数据添加成功但不显示 - 深度诊断与修复 Spec

## Why
用户报告：通过界面添加商品/分类/用户时，后端返回成功(200/201)，数据库也确实写入了数据，但前端列表仍然显示"No Data, Total: 0"。控制台可能显示409 Conflict或API Request Failed错误。

初步诊断发现：**axios响应拦截器返回的数据结构与Vue组件期望的数据结构不匹配**，导致数据解析失败。

## What Changes
- **BREAKING**: 修复axios拦截器的响应数据结构，确保与所有Vue组件兼容
- 修复所有Vue组件中的数据访问路径（统一为正确的嵌套层级）
- 添加操作成功后的自动列表刷新逻辑
- 增强错误提示信息（区分401/404/409/500）

## Impact
- Affected specs: data-display-fix (延续)
- Affected code:
  - `qiguanqianduan/src/utils/request.js` (axios拦截器 - 核心修复)
  - `qiguanqianduan/src/views/Products.vue` (数据解析)
  - `qiguanqianduan/src/views/Categories.vue` (数据解析)
  - `qiguanqianduan/src/views/Users.vue` (数据解析)
  - `qiguanqianduan/src/views/Orders.vue` (数据解析)
  - `qiguanqianduan/src/views/Dashboard.vue` (数据解析)

## ADDED Requirements

### Requirement: 统一响应数据结构
系统 SHALL 确保所有API调用的响应数据结构一致：

#### Scenario: 成功响应
- **WHEN** API返回 `{success: true, data: {...}}`
- **THEN** axios拦截器 SHALL 返回完整的response对象（非response.data）
- **AND** Vue组件可通过 `res.data.data` 访问业务数据

#### Scenario: 失败响应  
- **WHEN** API返回 `{success: false, error: {...}}`
- **THEN** axios拦截器 SHALL 正确识别并抛出错误
- **AND** Vue组件的catch块能捕获并显示友好提示

### Requirement: 操作成功后自动刷新
系统 SHALL 在CRUD操作成功后自动刷新列表数据：

#### Scenario: 添加商品成功
- **WHEN** 用户提交商品表单且后端返回201/200
- **THEN** 自动调用fetchData()刷新列表
- **AND** 新添加的商品应立即出现在列表中

### Requirement: 错误状态码友好提示
系统 SHALL 为不同的HTTP状态码提供明确的中文提示：

| 状态码 | 提示信息 |
|--------|----------|
| 400 | 请求参数错误 |
| 401 | 登录已过期，请重新登录 |
| 403 | 权限不足 |
| 404 | 请求的资源不存在 |
| 409 | 数据已存在（如分类名称重复） |
| 500 | 服务器内部错误 |

## MODIFIED Requirements

### Requirement: axios响应拦截器
当前的拦截器实现存在数据结构不匹配问题：

**当前行为（有bug）**:
```javascript
// 返回 response.data → Vue组件收到 {success, data: {list}}
// 但组件期望 res.data.data.list → undefined!
return res  // res = response.data
```

**修复后行为**:
```javascript
// 返回完整response对象 → Vue组件可正常使用 res.data.data.list
return response  // 保持axios原始结构
```

### Requirement: Vue组件数据访问路径
所有组件需要统一数据访问方式：

**当前（不一致）**:
```javascript
// 有些用 res.data.data.list
// 有些用 res.data.list  
// 导致部分页面能显示，部分不能
```

**修复后（统一）**:
```javascript
// 所有组件统一使用:
const apiData = res.data  // {success, data: {list, pagination}}
if (apiData.success && apiData.data) {
  tableData.value = apiData.data.list || []
  pagination.total = apiData.data.pagination?.total || 0
}
```

## Implementation Plan

### Phase A: 核心修复（立即执行）
1. **诊断确认**: 通过浏览器Network面板对比请求/响应
2. **修复拦截器**: 调整request.js返回值结构
3. **修复组件**: 统一所有Vue组件的数据访问路径
4. **本地构建验证**: npm run build确保无编译错误

### Phase B: 部署验证
5. 推送代码到服务器
6. 重新构建前端
7. 重启PM2服务
8. 浏览器测试完整流程

### Phase C: 功能完善
9. 验证添加→显示完整链路
10. 验证编辑→更新完整链路
11. 验证删除→移除完整链路
12. 边界情况测试（空数据、大量数据、特殊字符）
