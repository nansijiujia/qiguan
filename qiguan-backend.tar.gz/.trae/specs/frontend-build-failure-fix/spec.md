# 前端构建失败系统性诊断与修复方案 Spec

## Why
前端在云服务器构建过程中持续失败，错误信息为 `Dashboard.vue (258:1): Element is missing end tag`，同时伴随 Nginx 配置语法错误（`proxy_set_header` 参数无效），导致整个部署流程中断，无法成功上线。

## What Changes
- **修复 Dashboard.vue 第 258 行 HTML 标签闭合错误**（核心问题）
- **修正 vite.config.js 的 base 路径配置**（从 `'./'` 改为 `'/'`）
- **完善 .env.production 环境变量配置**
- **修复 Nginx 配置文件中的 proxy_set_header 语法错误**
- **评估并优化静态网站托管配置**（CloudBase vs Nginx 直接托管）
- **建立本地预验证机制**，确保代码推送前可正常构建

## Impact
- Affected specs: complete-deployment-solution, system-comprehensive-fix
- Affected code:
  - `qiguanqianduan/src/views/Dashboard.vue`（第 258 行标签错误）
  - `qiguanqianduan/vite.config.js`（base 路径配置）
  - `qiguanqianduan/.env.production`（环境变量不完整）
  - `/etc/nginx/conf.d/qiguan.conf`（Nginx 配置语法错误）
  - `qiguanqianduan/cloudbaserc.json`（CloudBase 静态托管配置）

## ADDED Requirements

### Requirement: 构建错误自动检测
系统 SHALL 在代码提交或部署前自动检测 Vue 组件的 HTML 标签闭合错误。

#### Scenario: Dashboard.vue 标签错误检测
- **WHEN** 开发者运行 `npm run build` 或执行部署脚本
- **THEN** 如果存在未闭合的 HTML 标签，构建过程 SHALL 明确报错并指出行号
- **THEN** 错误信息 SHALL 包含文件路径和具体位置（如 `Dashboard.vue:258:1`）

### Requirement: Nginx 配置语法验证
系统 SHALL 在重载 Nginx 前自动验证配置文件的语法正确性。

#### Scenario: Nginx 配置测试
- **WHEN** 执行 `sudo nginx -t` 或部署脚本中的 Nginx 配置步骤
- **THEN** 如果配置文件存在语法错误（如无效的指令参数），系统 SHALL 拒绝重载并输出详细错误信息
- **THEN** 错误信息 SHALL 指明具体的配置文件路径和行号

### Requirement: 本地构建预验证流程
开发者 SHALL 在推送到远程仓库前完成本地构建验证。

#### Scenario: 推送前验证
- **WHEN** 开发者准备推送代码到 Git 仓库
- **THEN** 必须先在本地执行 `npm run build` 并确认构建成功
- **THEN** 只有构建成功后才允许执行 `git push`

### Requirement: 静态网站托管方案评估
系统 SHALL 评估是否需要 CloudBase 静态托管，或完全迁移到 Nginx 直接托管方案。

#### Scenario: 托管方案决策
- **WHEN** 前后端一体化部署架构已确定（Nginx + PM2 + Node.js）
- **THEN** CloudBase 静态托管配置（cloudbaserc.json）可能冗余
- **THEN** 应评估删除或禁用 CloudBase 托管配置以避免混淆

## MODIFIED Requirements

### Requirement: 自动化部署脚本增强
原有的 `auto-deploy.sh` 脚本 SHALL 增加构建前置检查步骤：

#### Scenario: 部署前健康检查
- **WHEN** 执行 `./auto-deploy.sh`
- **THEN** 脚本 SHALL 先检查关键文件的语法正确性（Vue 组件、Nginx 配置）
- **THEN** 如果发现语法错误，脚本 SHALL 立即终止并提供修复建议
- **THEN** 不应继续执行后续的安装和构建步骤

### Requirement: 错误日志详细化
构建和部署过程中的错误日志 SHALL 提供足够的信息以便快速定位问题。

#### Scenario: 错误日志格式
- **WHEN** 发生构建失败或服务启动失败
- **THEN** 日志 SHALL 包含：时间戳、错误类型、文件路径、行号、堆栈跟踪
- **THEN** 日志 SHALL 同时输出到控制台和日志文件（`/var/log/qiguan/deploy-*.log`）

## REMOVED Requirements

### Requirement: CloudBase 静态托管依赖（待评估）
**Reason**: 当前已采用 Nginx 直接托管前端静态文件（`/var/www/qiguan/qiguanqianduan/dist/`），CloudBase 可能不再需要。
**Migration**: 
1. 保留 `cloudbaserc.json` 但注释说明其为历史遗留配置
2. 或者在确认 Nginx 方案稳定后删除该文件及其相关配置
3. 更新 DEPLOYMENT_GUIDE.md 移除 CloudBase 相关步骤
