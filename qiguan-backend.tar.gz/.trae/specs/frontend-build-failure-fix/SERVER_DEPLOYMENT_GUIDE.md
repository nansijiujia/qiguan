# 绮管后台 - 服务器端部署操作手册

> **版本**: v3.0.0  
> **更新日期**: 2026-04-09  
> **适用环境**: 生产服务器 (Linux)  
> **前置修复**: 前端构建失败问题已修复

---

## 📋 目录

1. [前置条件检查清单](#1-前置条件检查清单)
2. [分步部署流程](#2-分步部署流程)
3. [验证检查清单](#3-验证检查清单)
4. [故障排查快速参考](#4-故障排查快速参考)
5. [回滚方案](#5-回滚方案)
6. [附录：关键文件参考](#6-附录关键文件参考)

---

## 1. 前置条件检查清单

在开始部署前，请逐项确认以下条件：

### ✅ 系统访问权限
- [ ] SSH 访问权限（推荐使用密钥认证）
- [ ] root 权限或 sudo 权限（用于 Nginx 操作和系统服务管理）
- [ ] 能够访问 Git 仓库（GitHub/GitLab 私有仓库需配置 SSH key）

### ✅ 运行时环境
- [ ] Node.js 版本 >= 18.x（推荐 LTS 版本）
```bash
node --version
# 期望输出: v18.x.x 或更高
```
- [ ] npm 版本 >= 9.x
```bash
npm --version
# 期望输出: 9.x.x 或更高
```

### ✅ 必要工具
- [ ] Git 已安装并配置
```bash
git --version
git config --global user.name "Your Name"
git config --global user.email "your@email.com"
```
- [ ] PM2 进程管理器已安装（全局）
```bash
pm2 --version
# 如果未安装: npm install -g pm2
```
- [ ] Nginx 已安装
```bash
nginx -v
# 如果未安装: apt install nginx (Ubuntu/Debian)
#           yum install nginx (CentOS/RHEL)
```

### ✅ 数据库连接
- [ ] MySQL/MariaDB 服务运行正常
- [ ] 数据库 `qmzyxcx` 已创建
- [ ] 数据库用户权限已配置（参见 ecosystem.config.js）

### ✅ SSL 证书（HTTPS 必须）
- [ ] Let's Encrypt 证书已申请（域名: qimengzhiyue.cn）
- [ ] 证书路径正确：
  - `/etc/letsencrypt/live/qimengzhiyue.cn/fullchain.pem`
  - `/etc/letsencrypt/live/qimengzhiyue.cn/privkey.pem`

---

## 2. 分步部署流程

### ⚠️ 重要提示

**部署前必读**：
- 所有命令均在服务器上执行（非本地开发机）
- 项目根目录：`/var/www/qiguan`
- 前端目录：`/var/www/qiguan/qiguanqianduan`
- 后端目录：`/var/www/qiguan`（根目录即为后端）
- **建议在维护窗口期执行，避免高峰期影响用户**

---

### Step 1: 拉取最新代码

#### 1.1 进入项目目录
```bash
cd /var/www/qiguan
```

#### 1.2 检查当前分支
```bash
git branch
# 确认当前在 绮管 分支
```

#### 1.3 保存本地修改（如有）
```bash
git stash
# 输出: Saved working directory and index state WIP on 绮管: xxxxxxx
```

#### 1.4 拉取最新代码
```bash
git pull origin 绮管
# 期望输出:
#   Already up to date.
#   或
#   Updating xxxxxxx..yyyyyyy
#   Fast-forward
#    src/views/Dashboard.vue | 10 +++++-----
#    1 file changed, 5 insertions(+), 5 deletions(-)
```

#### 1.5 恢复本地修改（如有）
```bash
git stash pop
# 如果之前有 stash 的话
```

#### ✅ 验证点
```bash
git log -1 --oneline
# 确认提交时间是最新的
```

---

### Step 2: 验证 Dashboard.vue 文件完整性

**此步骤至关重要！** Dashboard.vue 是之前构建失败的根本原因。

#### 2.1 检查文件行数
```bash
wc -l qiguanqianduan/src/views/Dashboard.vue
# ✅ 期望输出: 345 qiguanqianduan/src/views/Dashboard.vue
```

**如果行数不是 345**：
```bash
# ❌ 错误情况处理
echo "⚠️  警告: Dashboard.vue 行数不正确！"
echo "期望: 345 行"
echo "实际: $(wc -l < qiguanqianduan/src/views/Dashboard.vue) 行"
echo ""
echo "可能原因:"
echo "  1. 代码未完全同步"
echo "  2. 存在本地修改"
echo ""
echo "解决方案:"
echo "  1. 执行 git status 检查修改"
echo "  2. 执行 git checkout -- qiguanqianduan/src/views/Dashboard.vue"
echo "  3. 重新执行 Step 1 拉取代码"
exit 1
```

#### 2.2 检查第 258 行内容（关键验证点）
```bash
sed -n '258p' qiguanqianduan/src/views/Dashboard.vue
# ✅ 期望输出: <style scoped>
```

**如果第 258 行不是 `<style scoped>`**：
```bash
# ❌ 严重错误：文件损坏或版本错误
echo "❌ 致命错误: Dashboard.vue 第 258 行格式错误！"
echo "期望: <style scoped>"
echo "实际: $(sed -n '258p' qiguanqianduan/src/views/Dashboard.vue)"
echo ""
echo "立即停止部署，联系开发团队！"
exit 1
```

#### 2.3 完整性校验（可选但推荐）
```bash
# 查看文件尾部确认结构完整
tail -20 qiguanqianduan/src/views/Dashboard.vue
# 应该包含 </style> 作为最后一行
```

---

### Step 3: 安装前端依赖

#### 3.1 进入前端目录
```bash
cd qiguanqianduan
```

#### 3.2 清理旧的依赖（可选但推荐）
```bash
rm -rf node_modules package-lock.json
# 注意：这会删除所有依赖，确保网络通畅
```

#### 3.3 安装依赖
```bash
npm install
```

**预期输出示例**：
```
added 1234 packages in 45.6s

123 packages are looking for funding
  run `npm fund` for details
```

#### ⚠️ 常见问题及解决方案

**问题 1**: `npm install` 失败或超时
```bash
# 解决方案：使用淘宝镜像源
npm install --registry=https://registry.npmmirror.com
```

**问题 2**: 权限错误（EACCES）
```bash
# 解决方案：不要使用 sudo，而是修复 npm 权限
# 或者使用 nvm 管理 Node.js
mkdir ~/.npm-global
npm config set prefix '~/.npm-global'
export PATH=~/.npm-global/bin:$PATH
source ~/.bashrc
npm install
```

**问题 3**: node-sass 或其他原生模块编译失败
```bash
# 解决方案：确保编译工具链完整
# Ubuntu/Debian:
sudo apt install build-essential python3
# CentOS/RHEL:
sudo yum groupinstall "Development Tools"
sudo yum install python3
npm install
```

#### ✅ 验证点
```bash
# 检查 node_modules 是否存在且不为空
ls node_modules | head -5
# 应该看到多个依赖包目录
```

---

### Step 4: 构建前端项目

**这是整个部署流程中最关键的步骤！**

#### 4.1 执行构建命令
```bash
npm run build
```

#### ✅ 成功的构建输出示例
```
vite v6.0.5 building for production...
✓ 2333 modules transformed.
dist/index.html                   0.45 kB │ gzip:  0.29 kB
dist/assets/vue-vendor-abc123.js   145 kB │ gzip:  48.2 kB
dist/assets/element-plus-def456.js 289 kB │ gzip: 89.1 kB
dist/assets/echarts-ghi789.js      512 kB │ gzip:156.7 kB
dist/assets/index-jkl012.css       15.2 kB │ gzip:  3.8 kB
dist/assets/index-mno345.js        85.6 kB │ gzip: 22.3 kB
✓ built in 12.34s
```

#### ❌ 构建失败的常见错误

**错误 1**: Dashboard.vue 解析错误
```
error during build:
[plugin:vite:vue] Vue parser error: Unexpected token (258:0)
```
**解决方案**：
```bash
# 回到 Step 2，重新验证 Dashboard.vue
# 确保文件行数为 345 且第 258 行为 <style scoped>
```

**错误 2**: 内存不足（OOM）
```
FATAL ERROR: Ineffective mark-compacts near heap limit Allocation failed
```
**解决方案**：
```bash
# 增加 Node.js 内存限制
export NODE_OPTIONS="--max-old-space-size=4096"
npm run build
```

**错误 3**: 依赖缺失
```
Cannot find module 'xxx'
```
**解决方案**：
```bash
# 重新安装依赖
rm -rf node_modules package-lock.json
npm install
npm run build
```

#### 4.2 检查构建产物
```bash
# 检查 dist 目录是否存在
ls -la dist/
# 应该包含:
#   index.html
#   assets/ (包含 js, css, 图片等)

# 检查构建产物大小
du -sh dist/
# 期望大小: 2-10 MB（取决于项目规模）
```

#### 4.3 检查退出码
```bash
echo $?
# ✅ 期望输出: 0（表示成功）
# ❌ 非 0 表示失败，查看上方错误信息
```

#### ⚠️ 如果构建失败

**立即停止部署流程！**

```bash
# 不要继续后续步骤
echo "❌ 构建失败，部署中止！"
echo "请检查上述错误信息并修复后重试"
exit 1
```

---

### Step 5: 修复 Nginx 配置

**这是本次部署的核心修复项！**

#### 5.1 备份现有配置
```bash
sudo cp /etc/nginx/conf.d/qiguan.conf /etc/nginx/conf.d/qiguan.conf.backup.$(date +%Y%m%d_%H%M%S)
echo "✅ 配置已备份"
```

#### 5.2 编辑 Nginx 配置文件
```bash
sudo nano /etc/nginx/conf.d/qiguan.conf
# 或使用 vim:
sudo vim /etc/nginx/conf.d/qiguan.conf
```

#### 5.3 完整的正确配置（直接复制粘贴）

**将以下完整内容替换原文件**：

```nginx
# ============================================================
# 绮管电商后台 - Nginx 生产配置
# 文件位置: /etc/nginx/conf.d/qiguan.conf
# 更新日期: 2026-04-09
# 用途: 反向代理 + 静态文件服务 + HTTPS
# ============================================================

# HTTP -> HTTPS 强制跳转
server {
    listen 80;
    server_name qimengzhiyue.cn www.qimengzhiyue.cn;
    
    # Let's Encrypt 证书续期验证
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }
    
    # 其他所有请求跳转到 HTTPS
    location / {
        return 301 https://$host$request_uri;
    }
}

# HTTPS 主配置
server {
    listen 443 ssl http2;
    server_name qimengzhiyue.cn www.qimengzhiyue.cn;

    # ==================== SSL 证书配置 ====================
    ssl_certificate /etc/letsencrypt/live/qimengzhiyue.cn/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/qimengzhiyue.cn/privkey.pem;

    # SSL 安全优化
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    ssl_stapling on;
    ssl_stapling_verify on;

    # ==================== 静态文件根目录 ====================
    root /var/www/qiguan/qiguanqianduan/dist;
    index index.html;

    # ==================== 安全响应头 ====================
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # ==================== 日志配置 ====================
    access_log /var/log/nginx/qiguan_access.log;
    error_log /var/log/nginx/qiguan_error.log;

    # ==================== 前端路由（Vue SPA 模式）====================
    location / {
        try_files $uri $uri/ /index.html;
        
        # 禁止缓存 HTML（确保更新生效）
        add_header Cache-Control "no-cache, no-store, must-revalidate";
        add_header Pragma "no-cache";
        add_header Expires "0";
    }

    # ==================== API 反向代理（核心修复）====================
    # ⚠️ 修复说明：
    #   原错误: proxy_set_header 参数格式无效
    #   修复方法: 使用标准的 Nginx 变量格式
    #
    location /api/ {
        # 后端服务地址
        proxy_pass http://127.0.0.1:3000;
        
        # HTTP 协议版本
        proxy_http_version 1.1;

        # ✅ 正确的 Header 设置格式（修复点）
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;

        # WebSocket 支持（如需实时功能）
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';

        # 缓存控制
        proxy_cache_bypass $http_upgrade;

        # 超时设置（根据业务需求调整）
        proxy_connect_timeout 60s;
        proxy_send_timeout 60s;
        proxy_read_timeout 60s;

        # 缓冲区设置
        proxy_buffering on;
        proxy_buffer_size 4k;
        proxy_buffers 8 4k;

        # 传递真实客户端 IP（日志分析用）
        proxy_set_header X-Original-URI $request_uri;
    }

    # ==================== 静态资源长期缓存 ====================
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|woff|woff2|ttf|eot)$ {
        expires 30d;
        add_header Cache-Control "public, immutable";
        access_log off;
        
        # 开启 Gzip 压缩传输
        gzip on;
        gzip_types application/javascript text/css image/svg+xml;
        gzip_min_length 1000;
    }

    # ==================== 安全限制 ====================
    # 禁止访问隐藏文件（.htaccess, .git 等）
    location ~ /\. {
        deny all;
        access_log off;
        log_not_found off;
    }
    
    # 禁止访问敏感文件
    location ~* \.(env|log|md|json|bak|sql|conf)$ {
        deny all;
        access_log off;
        log_not_found off;
    }
}
```

#### 🔑 关键修复点说明

**❌ 错误的写法（可能导致 Nginx 启动失败）**：
```nginx
proxy_set_header Host "$host";              # ❌ 多余引号
proxy_set_header X-Real-IP = $remote_addr;  # ❌ 多余等号
proxy_set_header X-Forwarded-For ($proxy);  # ❌ 错误括号
```

**✅ 正确的写法（必须严格遵守）**：
```nginx
proxy_set_header Host $host;
proxy_set_header X-Real-IP $remote_addr;
proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
proxy_set_header X-Forwarded-Proto $scheme;
```

#### 5.4 保存并退出编辑器

- **nano**: 按 `Ctrl + O` 保存 → `Enter` 确认 → `Ctrl + X` 退出
- **vim**: 按 `Esc` → 输入 `:wq` → `Enter` 保存退出

---

### Step 6: 测试 Nginx 配置

#### 6.1 语法检查
```bash
sudo nginx -t
```

**✅ 成功输出**：
```
nginx: configuration file /etc/nginx/nginx.conf test is successful
nginx: configuration file /etc/nginx/nginx.conf test is successful
```

**❌ 失败输出示例**：
```
nginx: [emerg] invalid parameter "X-Real-IP" in /etc/nginx/conf.d/qiguan.conf:60
nginx: configuration file /etc/nginx/nginx.conf test failed
```

#### 6.2 如果测试失败

**常见错误及修复**：

**错误 1**: `proxy_set_header` 格式错误
```
nginx: [emerg] directive is not allowed here
```
**解决**：检查 `location /api/ {}` 块内的指令是否都在正确的上下文中

**错误 2**: 缺少分号
```
nginx: [emerg] unexpected "}"
```
**解决**：检查每一行末尾是否有 `;`

**错误 3**: 变量名拼写错误
```
nginx: [emerg] unknown "remote_address" variable
```
**解决**：应该是 `$remote_addr` 不是 `$remote_address`

**调试步骤**：
```bash
# 1. 查看具体哪一行出错
sudo nginx -t 2>&1 | grep -A 5 "emerg"

# 2. 查看出错行的上下文
sudo sed -n '55,65p' /etc/nginx/conf.d/qiguan.conf

# 3. 对比上面的标准配置进行修正
```

#### 6.3 确认无误后继续
```bash
# 只有当 nginx -t 返回 successful 时才继续
echo "✅ Nginx 配置测试通过"
```

---

### Step 7: 重载服务

#### 7.1 重载 Nginx（无缝切换，不断连）
```bash
sudo systemctl reload nginx
# 或
sudo nginx -s reload
```

**✅ 成功标志**：无任何输出（静默成功）

**❌ 失败输出**：
```
Job for nginx.service failed because the control process exited with error code.
```

#### 7.2 检查 Nginx 状态
```bash
sudo systemctl status nginx
# 期望输出包含:
#   Active: active (running) since ...
```

#### 7.3 重启后端服务（PM2）
```bash
cd /var/www/qiguan
pm2 restart qiguan-backend
```

**✅ 成功输出**：
```
[PM2] Applying action restartProcessId on app [qiguan-backend](ids: 0)
[PM2] [qiguan-backend](0) ✓
┌────┬─────────────────────┬─────────────┬─────────┬─────────┬──────────┬──────────┐
│ id │ name                │ namespace   │ version  │ mode    │ status   │ restart │
├────┼─────────────────────┼─────────────┼─────────┼─────────┼──────────┼──────────┤
│ 0  │ qiguan-backend      │ default     │ 4.0.0    │ fork    │ online   │ 0       │
└────┴─────────────────────┴─────────────┴─────────┴─────────┴──────────┴──────────┘
```

#### 7.4 检查 PM2 进程状态
```bash
pm2 list
# 确保 status 为 online
```

#### 7.5 查看后端启动日志（首次重启时重要）
```bash
pm2 logs qiguan-backend --lines 50
# 检查是否有数据库连接错误或其他异常
```

#### 7.6 保存 PM2 进程列表（防止服务器重启丢失）
```bash
pm2 save
```

---

## 3. 验证检查清单

完成部署后，必须逐项验证以下内容：

### ✅ 3.1 构建验证
- [ ] 前端构建成功（`npm run build` 退出码为 0）
- [ ] `dist/` 目录存在且包含 `index.html`
- [ ] `dist/assets/` 目录包含打包后的 JS/CSS 文件
- [ ] Dashboard.vue 文件行数为 345 行

### ✅ 3.2 Nginx 验证
- [ ] `sudo nginx -t` 测试通过（syntax is ok）
- [ ] Nginx 服务状态为 `active (running)`
- [ ] 配置文件路径正确：`/etc/nginx/conf.d/qiguan.conf`

### ✅ 3.3 后端服务验证
- [ ] PM2 进程 `qiguan-backend` 状态为 `online`
- [ ] 后端监听端口 3000（`netstat -tlnp | grep 3000`）
- [ ] 无明显的启动错误日志

### ✅ 3.4 功能性验证（浏览器测试）

**基础访问测试**：
```bash
# 在本地浏览器访问（替换为实际域名/IP）
curl -I https://qimengzhiyue.cn
# 期望: HTTP/2 200
```

**API 连通性测试**：
```bash
# 测试 API 是否可达
curl https://qimengzhiyue.cn/api/v1/health
# 期望: {"status":"ok","timestamp":"..."}
```

**前端页面加载**：
- [ ] 主页可访问（https://qimengzhiyue.cn）
- [ ] 登录页面正常显示
- [ ] 登录后能跳转到 Dashboard
- [ ] Dashboard 图表数据正常渲染
- [ ] 各菜单页面可正常切换

**HTTPS 安全性**：
- [ ] 浏览器地址栏显示🔒锁图标
- [ ] 无混合内容警告（Mixed Content）

### ✅ 3.5 性能验证（可选）
```bash
# 页面加载时间
curl -o /dev/null -s -w "%{time_total}\n" https://qimengzhiyue.cn
# 期望: < 2秒（首次访问）
```

---

## 4. 故障排查快速参考

### 🔥 4.1 构建阶段问题

#### 问题：Dashboard.vue 解析错误
**症状**：
```
error during build:
[plugin:vite:vue] SFC compilation error
Unexpected token (258:0)
```

**原因**：文件不完整或版本错误

**解决方案**：
```bash
# 1. 确认文件行数
wc -l qiguanqianduan/src/views/Dashboard.vue
# 必须是 345 行

# 2. 如果不对，强制从 Git 恢复
git checkout HEAD -- qiguanqianduan/src/views/Dashboard.vue

# 3. 再次验证
sed -n '258p' qiguanqianduan/src/views/Dashboard.vue
# 必须输出: <style scoped>

# 4. 重新构建
npm run build
```

#### 问题：内存溢出 OOM
**症状**：
```
FATAL ERROR: CALL_AND_RETRY_LAST Allocation failed - JavaScript heap out of memory
```

**解决方案**：
```bash
export NODE_OPTIONS="--max-old-space-size=4096"
npm run build
```

#### 问题：依赖安装失败
**症状**：
```
npm ERR! code ELIFECYCLE
npm ERR! errno 1
```

**解决方案**：
```bash
# 清除缓存
npm cache clean --force

# 删除 node_modules
rm -rf node_modules package-lock.json

# 使用镜像源
npm install --registry=https://registry.npmmirror.com
```

---

### 🔥 4.2 Nginx 阶段问题

#### 问题：Nginx 配置语法错误
**症状**：
```
nginx: [emerg] invalid parameter in /etc/nginx/conf.d/qiguan.conf:XX
```

**排查步骤**：
```bash
# 1. 定位错误行
sudo nginx -t 2>&1 | grep -B 2 "emerg"

# 2. 查看该行内容
sudo sed -n 'XXp' /etc/nginx/conf.d/qiguan.conf

# 3. 对比本文档 Step 5.3 的标准配置

# 4. 修正后重新测试
sudo nano /etc/nginx/conf.d/qiguan.conf
sudo nginx -t
```

**常见语法错误对照表**：

| 错误类型 | 错误示例 | 正确写法 |
|---------|---------|---------|
| 多余引号 | `Host "$host"` | `Host $host` |
| 多余等号 | `X-Real-IP = $remote_addr` | `X-Real-IP $remote_addr` |
| 缺少分号 | `proxy_set_header Host $host` （末尾无 ;） | `proxy_set_header Host $host;` |
| 错误变量 | `$remote_address` | `$remote_addr` |
| 大小写错误 | `$Proxy_Add_X_Forwarded_For` | `$proxy_add_x_forwarded_for` |

#### 问题：Nginx 502 Bad Gateway
**症状**：浏览器显示 502 错误

**原因**：后端服务未启动或端口不通

**解决方案**：
```bash
# 1. 检查后端进程
pm2 list
# 确认 qiguan-backend 为 online

# 2. 检查端口监听
netstat -tlnp | grep 3000
# 应该看到: tcp 0 0 0.0.0.0:3000 LISTEN <PID>/node

# 3. 如果未启动，手动启动
cd /var/www/qiguan
pm2 start ecosystem.config.js

# 4. 查看后端错误日志
pm2 logs qiguan-backend --err --lines 20
```

#### 问题：Nginx 403 Forbidden
**症状**：访问网站返回 403

**原因**：文件权限不足或目录不存在

**解决方案**：
```bash
# 1. 检查 dist 目录是否存在
ls -la /var/www/qiguan/qiguanqianduan/dist/

# 2. 如果不存在，重新构建
cd /var/www/qiguan/qiguanqianduan
npm run build

# 3. 修正权限
chmod -R 755 /var/www/qiguan/qiguanqianduan/dist
chown -R www-data:www-data /var/www/qiguan/qiguanqianduan/dist  # Ubuntu/Debian
# 或
chown -R nginx:nginx /var/www/qiguan/qiguanqianduan/dist          # CentOS/RHEL

# 4. 重载 Nginx
sudo systemctl reload nginx
```

#### 问题：HTTPS 证书错误
**症状**：浏览器显示证书警告或 NET::ERR_CERT_*

**解决方案**：
```bash
# 1. 检查证书是否存在
ls -la /etc/letsencrypt/live/qimengzhiyue.cn/

# 2. 检查证书有效期
openssl x509 -in /etc/letsencrypt/live/qimengzhiyue.cn/fullchain.pem -noout -dates

# 3. 如果即将过期（< 30天），续期
sudo certbot renew --dry-run  # 测试续期
sudo certbot renew            # 正式续期

# 4. 重载 Nginx
sudo systemctl reload nginx
```

---

### 🔥 4.3 后端服务问题

#### 问题：PM2 进程反复重启
**症状**：
```
qiguan-backend  │ restarted         │ 15        │ 0
```

**解决方案**：
```bash
# 1. 查看错误日志
pm2 logs qiguan-backend --err --lines 50

# 2. 常见原因：数据库连接失败
# 检查 MySQL 是否运行
systemctl status mysql

# 3. 检查数据库配置
cat /var/www/qiguan/ecosystem.config.js | grep DB_

# 4. 手动测试数据库连接
mysql -h 10.0.0.16 -u QMZYXCX -p'LJN040821.' qmzyxcx -e "SELECT 1"

# 5. 如果是内存问题，调整 max_memory_restart
nano /var/www/qiguan/ecosystem.config.js
# 修改: max_memory_restart: '500M' -> '1024M'
pm2 restart qiguan-backend
```

#### 问题：API 返回 500 Internal Server Error
**症状**：前端可以访问，但接口报错

**解决方案**：
```bash
# 1. 查看 PM2 实时日志
pm2 logs qiguan-backend --lines 100

# 2. 查看详细的堆栈跟踪
pm2 show qiguan-backend

# 3. 检查数据库查询是否出错
# 常见原因：字段缺失、SQL 语法错误、数据类型不匹配

# 4. 检查环境变量是否正确加载
pm2 env 0  # 0 是进程 ID
```

---

### 🔥 4.4 前端页面问题

#### 问题：白屏或资源 404
**症状**：页面空白，F12 控制台显示资源加载失败

**解决方案**：
```bash
# 1. 检查 base 路径配置
cat qiguanqianduan/vite.config.js | grep "base:"
# 必须是: base: '/',

# 2. 检查 Nginx root 路径
grep "root " /etc/nginx/conf.d/qiguan.conf
# 必须指向 dist 目录

# 3. 检查构建产物
ls -la qiguanqianduan/dist/
# 确认 index.html 存在

# 4. 清除浏览器缓存后刷新（Ctrl+Shift+R）
```

#### 问题：API 请求跨域或路径错误
**症状**：F12 控制台显示 CORS 错误或 404

**解决方案**：
```bash
# 1. 检查前端 API 基础路径
cat qiguanqianduan/.env.production
# VITE_API_BASE_URL=/api

# 2. 检查 Nginx proxy_pass 配置
grep -A 5 "location /api/" /etc/nginx/conf.d/qiguan.conf
# 确认 proxy_pass http://127.0.0.1:3000;

# 3. 检查后端路由前缀
grep "app.use\(" /var/www/qiguan/index.js | head -5
# 确认路由挂载在 /api/v1 或类似前缀
```

---

## 5. 回滚方案

如果在部署过程中遇到无法解决的问题，可以按照以下步骤快速回滚：

### 🔄 5.1 快速回滚（5分钟内）

#### 场景 A：仅 Nginx 配置有问题
```bash
# 恢复备份的配置
sudo cp /etc/nginx/conf.d/qiguan.conf.backup.* /etc/nginx/conf.d/qiguan.conf

# 测试并重载
sudo nginx -t && sudo systemctl reload nginx

echo "✅ Nginx 配置已回滚"
```

#### 场景 B：前端构建有问题
```bash
# 回退到上一个稳定版本
cd /var/www/qiguan
git log --oneline -10  # 查看最近提交
git revert HEAD        # 撤销最后一次提交
# 或
git reset --hard HEAD~1  # 强制回退到上一版本（慎用）

# 重新构建
cd qiguanqianduan
npm run build

# 重载 Nginx
sudo systemctl reload nginx

echo "✅ 代码已回滚并重新部署"
```

#### 场景 C：全面回滚（最坏情况）
```bash
# 1. 停止当前服务
pm2 stop qiguan-backend
sudo systemctl stop nginx

# 2. 恢复到已知稳定的 Git 标签（如果有）
cd /var/www/qiguan
git tag -l  # 查看所有标签
git checkout v2.0.0-stable  # 切换到稳定版本标签

# 3. 重新构建和部署
cd qiguanqianduan
npm install
npm run build

# 4. 恢复 Nginx 配置
sudo cp /etc/nginx/conf.d/qiguan.conf.original /etc/nginx/conf.d/qiguan.conf
sudo nginx -t

# 5. 启动所有服务
sudo systemctl start nginx
cd /var/www/qiguan
pm2 start ecosystem.config.js

echo "✅ 全面回滚完成"
```

### 🔄 5.2 数据库回滚（谨慎操作）

**⚠️ 仅在数据被破坏时使用，会丢失最新数据！**

```bash
# 1. 停止应用（防止新数据写入）
pm2 stop qiguan-backend

# 2. 从备份恢复数据库（假设有定时备份）
# MySQL 示例:
mysql -u QMZYXCX -p'LJN040821.' qmzyxcx < /backup/qmzyxcx_20260409_010000.sql

# 3. 验证数据
mysql -u QMZYXCX -p'LJN040821.' qmzyxcx -e "SELECT COUNT(*) FROM users;"

# 4. 重启应用
pm2 start qiguan-backend

echo "⚠️  数据库已回滚，请通知用户可能的数据丢失"
```

### 🔄 5.3 紧急恢复检查清单

回滚完成后，必须验证：
- [ ] 网站可正常访问（HTTP 200）
- [ ] 用户可以登录
- [ ] 核心功能可用（商品列表、订单等）
- [ ] 无明显数据丢失
- [ ] 监控告警恢复正常

---

## 6. 附录：关键文件参考

### 6.1 项目结构速查

```
/var/www/qiguan/                    # 项目根目录
├── index.js                        # 后端入口文件
├── ecosystem.config.js             # PM2 配置
├── package.json                    # 后端依赖
├── routes/                         # 后端路由
│   ├── auth.js
│   ├── products.js
│   └── ...
└── qiguanqianduan/                 # 前端目录
    ├── src/
    │   └── views/
    │       └── Dashboard.vue       # ⚠️ 关键文件（345行）
    ├── vite.config.js              # Vite 配置（base: '/'）
    ├── .env.production             # 生产环境变量
    ├── dist/                       # 构建产物（部署目标）
    └── package.json                # 前端依赖
```

### 6.2 关键配置参数速查

| 配置项 | 值 | 位置 |
|-------|-----|------|
| Node.js 版本 | >= 18.x | 系统环境 |
| 后端端口 | 3000 | ecosystem.config.js |
| 前端 base 路径 | `/` | vite.config.js:24 |
| API 基础路径 | `/api` | .env.production:1 |
| Dashboard.vue 行数 | **345** | src/views/Dashboard.vue |
| Nginx 配置 | `/etc/nginx/conf.d/qiguan.conf` | 系统 |
| PM2 进程名 | `qiguan-backend` | ecosystem.config.js:3 |

### 6.3 常用命令速查表

```bash
# ========== 日常运维 ==========
pm2 list                              # 查看进程状态
pm2 logs qiguan-backend               # 查看实时日志
pm2 monit                             # 监控面板（交互式）
pm2 restart qiguan-backend            # 重启后端
sudo systemctl status nginx           # 查看 Nginx 状态
sudo tail -f /var/log/nginx/qiguan_access.log  # 访问日志

# ========== 部署相关 ==========
cd /var/www/qiguan/qiguanqianduan
npm run build                         # 构建前端
sudo nginx -t                         # 测试 Nginx 配置
sudo systemctl reload nginx           # 重载 Nginx

# ========== 故障排查 ==========
pm2 logs qiguan-backend --err --lines 100  # 错误日志
sudo journalctl -u nginx -f           # Nginx 系统日志
curl -I https://qimengzhiyue.cn       # 测试 HTTP 响应
netstat -tlnp | grep :3000            # 检查端口占用
```

### 6.4 监控与健康检查

建议配置以下监控项：

**系统级监控**：
- CPU 使用率 > 80% 持续 5 分钟
- 内存使用率 > 90%
- 磁盘空间 < 10%

**应用级监控**：
- PM2 进程状态（应始终为 online）
- Nginx 服务状态（应始终为 active）
- HTTPS 证书有效期（< 30天告警）

**业务级监控**：
- API 响应时间 > 3秒
- 错误率 > 5%
- 数据库连接池耗尽

**健康检查端点**：
```bash
# 后端健康检查
curl https://qimengzhiyue.cn/api/v1/health
# 期望: {"status":"ok","uptime":12345,"timestamp":"..."}

# 前端可访问性检查
curl -s -o /dev/null -w "%{http_code}" https://qimengzhiyue.cn
# 期望: 200
```

---

## 📞 紧急联系方式

如果在部署过程中遇到无法解决的问题：

1. **首先**：查看本手册的「故障排查」章节
2. **其次**：检查 PM2 和 Nginx 日志定位具体错误
3. **最后**：联系开发团队并提供以下信息：
   - 执行到哪个步骤失败
   - 完整的错误输出（截图或复制文本）
   - 当前 Git 提交哈希值 (`git rev-parse HEAD`)
   - 系统环境信息 (`uname -a`, `node --version`, `nginx -v`)

---

## 📝 变更记录

| 日期 | 版本 | 作者 | 变更内容 |
|-----|------|------|---------|
| 2026-04-09 | v3.0.0 | Deployment Team | 初始版本，包含完整部署流程、Nginx 修复、故障排查和回滚方案 |

---

**文档结束**

> 💡 **提示**：建议将此文档打印或在另一个终端保持打开，以便在部署过程中随时查阅。
